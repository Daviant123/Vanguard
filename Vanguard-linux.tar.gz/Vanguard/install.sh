#!/bin/sh
# Vanguard Control for Linux: install for this user (no sudo) and start it.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/.local/share/vanguard-control"
mkdir -p "$DEST" "$HOME/.local/share/applications"
cp "$HERE/vanguard-control-linux" "$DEST/vanguard-control-linux"
chmod +x "$DEST/vanguard-control-linux"
[ -f "$HERE/vanguard.png" ] && cp "$HERE/vanguard.png" "$DEST/vanguard.png"
cat > "$HOME/.local/share/applications/vanguard-control.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Vanguard Control
Comment=Multibox assistant for Final Fantasy XI (Windower in Wine)
Exec="$DEST/vanguard-control-linux"
Path=$DEST
Icon=$DEST/vanguard.png
Terminal=false
Categories=Game;
EOF
echo "Installed in $DEST - starting Vanguard Control (it's also in your applications menu now)."
cd "$DEST" && nohup ./vanguard-control-linux >/dev/null 2>&1 &
