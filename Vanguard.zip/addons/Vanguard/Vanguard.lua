_addon.name = 'Vanguard'
_addon.author = 'Daviant'
_addon.version = '1.3.0'
_addon.commands = {'vanguard', 'vg'}

--[[
Vanguard - multibox party assistant for Windower 4.

Load on every character:   //lua load vanguard
Turn on / off:             //vg on   |  //vg off
Help:                      //vg help

Modules (each can be toggled per character):
  follow, assist, heal, raise, cleanse, buffs, ws, sc, burst,
  songs, geo, debuff, dispel, triggers

Everything is configured in data/settings.xml (one section per character)
or live with //vg set <section>.<key> <value>, and can be driven from the
Vanguard Control desktop app.
]]

require('tables')
require('strings')
require('sets')
require('pack')
local config = require('config')
local res = require('resources')
local items = require('vg_items')
local cure = require('vg_cure')   -- which Cure / Curaga on whom (learned potencies, Curaga by who stands where)   -- item names etc. without loading the whole item list (memory)

local util = require('vg_util')
local triggers = require('vg_triggers')
local bridge = require('vg_bridge')
local jobs = require('vg_jobs')
local engine = require('vg_actions')
local menu = require('vg_menu')
local alts = require('vg_alts')
local party = require('vg_party')
local hud = require('vg_hud')
local travel = require('vg_travel')
local combat = require('vg_combat')
local team = require('vg_team')
local share = require('vg_share')
local safety = require('vg_safety')
local store = require('vg_store')
local mages = require('vg_mages')
local charm = require('vg_charm')    -- sleep a charmed party member
local sortie = require('vg_sortie')  -- Sortie: sector, boss procs and timers, the run
local support = require('vg_support')
local update = require('vg_update')
local link = require('vg_link')
local strat = require('vg_strat')
local bard = require('vg_bard')
local wschain = require('vg_wschain')
local scfollow = require('vg_scfollow')   -- reactive skillchains + learned skillchain window (1.2.0, audit 1.2 / 3.2)
local planner = require('vg_plan')        -- team planner assignments from Vanguard Control 2.0.0 (audit 3.1)
local blist = require('vg_blist')
local easyfarm = require('vg_easyfarm')
local bufftime = require('vg_bufftime')
local stats = require('vg_stats')
local crash = require('vg_crash')
local warp = require('vg_warp')
local finish = require('vg_finish')
local farm = require('vg_farm')
local trials = require('vg_trials')
crash.init(bridge)
-- Every event handler below runs guarded: an error becomes a crash report instead of red text (vg_crash).
do
    local raw_register = windower.register_event
    windower.register_event = function(ev, fn) return raw_register(ev, crash.guard('event ' .. ev, fn)) end
end
local quick = require('vg_quick')

------------------------------------------------------------------------
-- Settings
------------------------------------------------------------------------
local defaults = {
    enabled = false,
    autostart = false,
    resume_until = 0,       -- set when unloaded while running: a reload within 90 s carries on
    hotkeys = '',            -- quick-button hotkeys bound in this game window (vg_quick, set from the app)       -- start by itself when Vanguard loads (login / reload); off = wait for Start
    leader = '',
    tick = 0.25,
    modules = {
        follow = false, assist = false, heal = false, raise = false, cleanse = false,
        buffs = false, ws = false, sc = false, burst = false, songs = false,
        geo = false, debuff = false, dispel = false, triggers = false,
        rest = false, mana = false, trusts = false, farm = false, actions = false,
    },
    -- Saved per-job setup: role, weapon skill and ability on/off choices (managed automatically).
    profiles = {},
    -- Saved per-job menu choices from the panel (buff grid, songs, geo, enfeebles, modules).
    menus = {},
    wschains = {},           -- weapon skill chain per job (vg_wschain): "1|WS,WS,..." (1 = repeat)
    wschains_mine = {},      -- his own chains saved by name, per job: "name=1|WS,WS;name2=0|WS"
    customs = {},            -- the player's own abilities / spells per job (vg_jobs.custom): "kind#target#Name+..."
    blists = {},             -- EasyFarm-style battle lists per job (vg_blist): ["<job>_<list>"] = actions
    priorities = {},         -- what goes first, per job: ["<JOB>"] = "raise,cures,..." (empty = the default order)
    pause_on_zone = true,   -- stop the bot on a zone change (his request 2026-10-17: "when it changes zones i want you to stop the bot")
    stop_on_job = true,     -- ...and when the job or sub job changes (same request)
    -- formation: spread (fan behind the leader), line (single file) or off (plain follow)
    -- move_tick (Silmaril audit 1.1): seconds between movement / steering passes (following, formation, trail, closing
    -- in on the mob), between the 0.25 s decision passes. 0 (the default, as before 1.2.0; or as much as tick) =
    -- movement only with the decisions. 0.1 = steering 10 times a second (try it: //vg set follow.move_tick 0.1)
    follow = { distance = 2.5, max_distance = 40, formation = 'spread', trail = true, move_tick = 0 },
    party = { accept = true },          -- accept party invites from the leader / other Vanguard characters
    -- disengage: stop when the leader stops; defend: fight back when attacked while the leader is idle
    assist = { engage = true, approach = true, melee_range = 3.0, engage_range = 25, disengage = true, defend = true,
               autotarget = true,
               -- resync (1.2.0): the game shows us fighting but the server says we're not (2 s+): /attack <t> again
               resync = false,
               -- the Job tab's "Assist" box (0.99.3): switch = follow the leader's target changes; delay = seconds
               -- to wait after the leader starts on a mob; below_hp = only once the mob is at or under this HP %;
               -- on_claim = also when the leader isn't engaged but has a claimed mob targeted (pulls, a mage leader);
               -- approach_mode = role (melee roles walk up, casters don't) | on | off
               switch = true, delay = 0, below_hp = 100, on_claim = false, approach_mode = 'role',
               -- seek (1.2.0, Silmaril audit 2.6; vg_combat): an idle melee alt takes the nearest mob within
               -- seek_range (yalms) that the party claimed / that attacks the party, up to max_mobs mobs fought by the
               -- party; seek_unclaimed = also fresh unclaimed mobs. Never while farming, holding or retreating.
               seek = false, seek_range = 15, max_mobs = 2, seek_unclaimed = false,
               -- on_engage (1.2.0, audit 2.7; vg_combat): used once per new mob right after this character engages:
               -- a command ('input /ra <t>'), or a spell / ability name. Farming with a pull: farm.pull_cmd wins.
               on_engage = '',
               -- hate_spell (1.3.0, CurePlease audit 2.8; vg_support): once per new battle target, when the leader
               -- engages it, this spell on <bt> so a healer standing back is on the mob's hate list ('' = off);
               -- hate_on = a member name: the spell goes on that member instead (a buff, CurePlease's party mode)
               hate_spell = '', hate_on = '' },
    -- priority = names healed first at a higher threshold (tanks). wake_sleep = cure sleeping members.
    -- tiers: HP missing before each Cure tier is used (0 = never use it), like CurePlease's cure thresholds
    heal = { cure_at = 75, curaga_at = 70, curaga_count = 3, range = 20,
             tiers = 'Cure VI:1300,Cure V:1000,Cure IV:650,Cure III:350,Cure II:170,Cure:70',
             curagas = 'Curaga V,Curaga IV,Curaga III,Curaga II,Curaga',   -- Curaga tiers it may use
             priority = '', priority_at = 85, wake_sleep = true,
             ignore = '', curaga = true,
             -- auto: the Cure / Curaga is picked by how much each really heals, learned per job (vg_cure); false = the HP
             -- steps above. trust_at: trusts are only cured under this HP% (and after players at about the same HP)
             auto = true, trust_at = 60,
             watch = '',                  -- people outside the party to cure too (HealBot "watch", CurePlease has it): //vg watch
             -- alliance (his request 2026-11-21: "the curebot needs alliance options"): cure the other two parties'
             -- members under alliance_at (after my own party at the same HP; Curaga never reaches them), raise them
             alliance = false, alliance_at = 60, alliance_raise = false,
             -- 1.3.0 (CurePlease audit 2.4 / 2.5 / 3.2, vg_cure): priority_cover = how much of a priority member's
             -- missing HP his cure must cover (0.85 = like everyone, as before; 1.0+ = bigger cures for the tank);
             -- curaga_on = a member tried first as the Curaga centre ('' = off: the centre reaching the most);
             -- predict = predictive healing (off): a member whose HP keeps falling over predict_window seconds moves
             -- up the order and may get one tier more, by the HP% he loses in predict_lead seconds (at most predict_cap)
             priority_cover = 0.85, curaga_on = '',
             predict = false, predict_lead = 2, predict_cap = 20, predict_window = 3 },
    cure_learn = {},                      -- vg_cure: per job, "Cure IV=912;Cure V=1180" (what each healed in the game)
    charm = { on = false },               -- vg_charm: sleep a charmed party member (Enfeebles tab)
    charm_sleeps = {},                    -- vg_charm: per job, the sleeps to use in order, "Sleep II,Repose" ('-' = none)
    cure_off = {},                        -- vg_cure: per job, the Cure / Curaga tiers never to use, "Cure VI,Curaga"

    -- Statuses NOT to remove (comma list of status names).
    cleanse = { skip = '', items = true },
    -- temp_mp (1.3.0, audit 2.9): under this MP% use a temporary MP item (Lucid Ether, Dusty Ether, Megalixir ...) from
    -- the Temporary Items bag or the inventory (0 = off)
    items = { temp_mp = 0 },   -- items: Echo Drops / Holy Water / Remedy on myself (CurePlease, Silmaril)
    -- Rest (/heal) when idle and low; stand back up when recovered.
    rest = { hp_low = 40, hp_high = 95, mp_low = 25, mp_high = 95 },
    -- Sublimation upkeep and Convert.
    -- reserve: below this MP% only cures / Raise / status removal are cast (0 = off) - MP saved for healing
    -- 1.3.0 (CurePlease audit 2.3 / 2.7): devotion_to = only this member gets Devotion ('' = the first member under
    -- devotion_mpp, as before); devotion_engaged = Devotion only while the party fights; sub_skip_refresh = don't start
    -- charging Sublimation while my own Refresh is up, unless my MP is under sublimation_mpp (off = as before)
    mana = { sublimation = true, sublimation_mpp = 70, convert_mpp = 15, reserve = 0, devotion_mpp = 0,   -- devotion: WHM, 0 = off
             devotion_to = '', devotion_engaged = false, sub_skip_refresh = false },
    -- White Mage (1.3.0, audit 2.2): afflatus = the stance kept up, solace | misery (one at a time; solace = as before)
    whm = { afflatus = 'solace' },
    -- Summon trusts (spell names) until the party has party_size members.
    trusts = { list = '', party_size = 5 },
    -- Farming: target names (partial match), ignore list, claim filter (unclaimed|party|any),
    -- detection range/height, pull command after engaging, and a recorded route.
    -- farming (vg_farm): mode list|aggro|any; area camp|route; camp "x:y:z" in camp_zone; wait for the party before
    -- pulling (HP / MP %, within yalms); stop when the inventory is full / after stop_kills kills (0 = never)
    farm = { targets = '', ignore = '', claim = 'unclaimed', aggro_first = true, range = 20, stay = false, respawn = 0,
             f_unclaimed = true, f_party = true, f_claimed = false, detect = 0, pull_hp = 50,   -- (EasyFarm engine: no new mob under this HP%; 0 = off)
             gcd = 1000, engage = true,
             engine = 'easyfarm', approach_wait = 0, ef_jobs = true,   -- ef_jobs: the job's features in EasyFarm's gaps   -- approach_wait: seconds before walking to the mob (0-5)   -- 'easyfarm' (vg_easyfarm: EasyFarm's engine) or 'vanguard' (vg_farm's own)
             rest_hp = false, rest_hp_low = 50, rest_hp_high = 100, rest_mp = false, rest_mp_low = 50, rest_mp_high = 100,
             follow = '', follow_dist = 5,
             ws_use = 'list',   -- Battles: 'list' = the Weaponskill list, 'chain' = AutoSkillchain's chain wins while farming
             height = 5, approach = true, pull_cmd = '', route = '', loop = true,
             mode = 'list', area = 'camp', camp = '', camp_zone = 0, back_to_camp = true,
             wait_party = true, wait_hp = 70, wait_mp = 40, wait_near = 20, stop_full = true, stop_kills = 0,
             item = '', item_goal = 0,     -- farming for an item: stop when item_goal of it are in the inventory
             pull_back = false,           -- bring each mob back to camp before fighting (the others wait there)
             prefer_best = false,         -- prefer the mob kind that pays best per minute (the mob report)
             keep_chain = false,          -- XP / CP chains: while one runs, wait only for emergencies (HP 40%, MP 15%)
             stop_mins = 0, when_done = 'stay',   -- stop after N minutes (0 = no); then stay | warp | logout (everyone)
             skip_strong = true, strong = '',     -- mobs that nearly KO'd the farmer / took 3+ min twice: set aside
             preset = '',                         -- the last one-click preset (party | items | safe | clear)
             th = false,                          -- Treasure Hunter: GearSwap TreasureMode Tag while farming
             rotate = false,                      -- a spot dry for 3 min: move on to the next saved spot in the zone
             rest_idle = true,                    -- rest at camp while there's nothing to fight (up when a mob comes)
             check = false, skip_weak = false, skip_tough = false,  -- /check each new kind; skip Too Weak / Incredibly Tough + NMs
             make_room = false,                   -- bags nearly full: ask Steward to tidy them (//stw sort bags)
             stop_trial = true,                   -- a Magian trial it's farming for is done: stop
             rezone = false,                      -- zoned out while farming: back in the same zone within 15 min -> farm again
             time_alert = true,                   -- ring when the game says Abyssea (Visitant) time is running out
             stop_level = 0,                      -- stop when this character's main job reaches this level (0 = no)
             widen = 0,                           -- quiet spot: search 10 yalms further every 30 s, up to this (0 = off)
             polite = true,                       -- leave unclaimed mobs another player is standing next to
             hotkey = '',                         -- a key that starts / stops farming from the game window (^f9 ...)
             emergency = '', emergency_hp = 25,   -- under this HP % in a fight: this item / ability (from a menu)
             watch = '',                          -- rare drop alert: items that ring the app's Alarms when they drop
             packs = true, pack_range = 8, pack_strict = false },
    farmspots = { s0 = '' },
    trials = { t0 = '' }, trial_assist = '',   -- Magian trials (vg_trials): t1 = "kind|goal|ws|mobs|count"      -- saved farm spots (vg_farm): s1, s2, ... = "name|zone|field=value|..." 
    -- "Spell>target" pairs. target = me or a party member name. "ja:" prefix = job ability.
    buffs = { list = '', before = 0, times = '', learned = '' },   -- before / times: recast early (vg_bufftime)
    -- finish*: the weapon skill that lands the kill (vg_finish): at mob HP% finish_at, saving TP, others stop attacking
    ws = { name = '', tp = 1000, min_mob_hpp = 1, max_range = 6, am = 0, am_ws = '',
           mp_low = 0, mp_high = 100, mp_min = 0, mp_max = 0,   -- weapon skills only at this MP: %, and the number (0 = no limit)
           finish = '', finish_at = 0, learned = '', finish_trial_only = true, finish_save = true, finish_others = true, finish_wait = false },
    -- Ordered chain steps "Character:Weapon Skill". Each character only fires its own steps.
    sc = { steps = '', open_tp = 1000, window_min = 3, window_max = 8 },
    -- reactive skillchains (vg_scfollow, 1.2.0): on = the module (//vg scf on|off); tune_sc = sc.steps' window_max is
    -- also capped by the learned skillchain window; learned = what was learned (written by Vanguard)
    scf = { on = false, tune_sc = false, learned = '' },
    scf_rules = {},          -- per job: "who|trigger|ws|delay;..." (//vg scf add), up to 4
    -- "Element:Spell|Fallback|Fallback" pairs.
    burst = {
        spells = 'Fire:Fire V|Fire IV|Fire III,Ice:Blizzard V|Blizzard IV|Blizzard III,' ..
                 'Wind:Aero V|Aero IV|Aero III,Earth:Stone V|Stone IV|Stone III,' ..
                 'Lightning:Thunder V|Thunder IV|Thunder III,Water:Water V|Water IV|Water III,' ..
                 'Light:Banish III|Banish II,Dark:Aspir III|Aspir II|Drain',
        window = 8,
    },
    -- nitro: Nightingale + Troubadour (+ Marcato) then all songs; pianissimo = "Song>Name|Name,..." single-target songs
    -- Bard (vg_bard, after the Singer addon): slots 0 = from the instrument owned; dummy = up to 2 dummy songs;
    -- marcato_song / clarion_song ('' = first / next song); aoe_names = members that must be within 10'
    songs = { list = '', party_fix = true, duration = 240, refresh_before = 30, learned = '', when = 'always', nitro = true, nitro_when = 'fight', marcato = true, pianissimo = '',
              slots = 0, dummy = '', marcato_song = '', clarion_song = '', aoe_names = '' },
    -- entrust = 'Indi-Spell>Member'. full_circle_range = recall luopan when target is this far from it.
    -- entrust = 'auto' for Indi-Haste/Fury on the leader; hate_first = Dia before a Geo debuff;
    -- party_mp = Radial Arcana when 2+ members are under this MP%
    -- indi_engaged (1.3.0, audit 2.6): my own Indi only while the party fights (off = always, as before)
    geo = { indi = '', geo = '', geo_target = 'bt', entrust = '', full_circle_range = 15, hate_first = true, party_mp = 40,
            indi_engaged = false },
    debuff = { list = 'Dia II', retries = 1 },
    -- Enfeebler mode (vg_mages, 1.2.0, Silmaril audit 1.3; off by default): keep up to count mobs enfeebled. mobs =
    -- names it may take ('' = any mob fighting the party); pull = also unclaimed mobs within range (yalms) to fill the
    -- count; spells = in order ('' = debuff.list); stay = never walk (like DO NOT MOVE); wait_hp = no enfeebling while
    -- a party member is under this HP%. //vg enfeebler on|off|count N|mobs <list>|pull on|off|stay on|off
    enfeebler = { on = false, count = 1, mobs = '', pull = false, range = 20, spells = '', stay = false, wait_hp = 50 },
    triggers = { t1 = '' },
    bridge = { enabled = true, host = '127.0.0.1', port = 47000, interval = 1 },
    -- Playing alts (vg_alts): alerts on the leader's screen, mount sync, food & Reraise upkeep.
    -- Kept outside "modules" so presets don't switch them off.
    alts = { alerts = true, mount = true, upkeep = true, hud = true, stealth = true, restsync = true },
    -- alt overview box on the leader's screen; tp = the party TP / battle target HP box (1.2.0, Silmaril audit 2.8,
    -- off by default) at tp_x / tp_y
    hud = { x = 20, y = 320, tp = false, tp_x = 20, tp_y = 220 },
    keys = false,                         -- //vg keys on: Ctrl+F1..F6 hotkeys for alt orders
    setups = {},                          -- //vg setup save|load <name>: named team setups
    share = { emergency = 35 },           -- other healers still cure a member below this HP%
    -- GearSwap commands for //vg defense (Mote-style files) and auto-defense under 40% HP
    gear = { physical = 'gs c set DefenseMode Physical', magical = 'gs c set DefenseMode Magical',
             off = 'gs c reset DefenseMode', auto = false },
    away = { minutes = 20 },              -- alts pause when the leader hasn't moved for this long (0 = off)
    alerts = { hp = 30, mp = 10, far = 30, idle = 15, sound = '', ['repeat'] = 60 },
    mount = { name = 'Raptor' },
    upkeep = { food = '', reraise = '' },
    -- WHM / RDM / SCH know-how from the job guides (vg_mages): AoE -na, bar spells, Saboteur / Stymie,
    -- sleeping extra mobs (off until //vg sleep on), Scholar stratagems and Immanence skillchains.
    -- Corsair: risk = highest bust chance % to Double-Up into (0 = never bust), range = roll reach in yalms
    -- //vg update: GitHub page (owner/name) and folder that hold the newest Vanguard
    updater = { repo = 'Daviant123/Vanguard', path = 'Vanguard', branch = 'main', check = true },   -- //vg update (see take_old_update_section)
    -- crooked: Crooked Cards before this roll; quickdraw: the Shot after a party enfeeble of these elements lands on
    -- the battle target (1.2.0, Silmaril audit 2.1): 'light,dark' (Dia / Bio, Blind), 'all', or '' = none
    cor = { risk = 0, snake_eye = true, fold = true, range = 8, crooked = '', quickdraw = 'light,dark' },
    -- Ranger: hover_step = with Hover Shot up, a half-second side step after each ranged attack / ranged weapon skill
    -- (1.2.0, Silmaril audit 2.2; vg_support)
    -- (off by default: //vg set rng.hover_step true)
    rng = { hover_step = false },
    -- Reaction timing (1.3.0, CurePlease audit 1.2-1.4):
    -- ja.settle: seconds still kept busy after the game confirms (or refuses) a job ability Vanguard sent, instead of
    --   the fixed 1.5 s (still the fallback when no answer comes; pet commands / blood pacts always keep 1.5 s).
    --   1.5 = as before 1.3.0.
    ja = { settle = 0.3 },
    -- cast.tail: seconds added after a spell's cast time before the next action may go (cut short when the game says
    --   the cast finished). 3 = as before 1.3.0. cast.log_gap: also write every measured after-cast gap to the app's log
    --   (the numbers are always kept: //vg stats).
    cast = { tail = 3, log_gap = false },
    -- wake.on: an extra decision pass right when something important happens (a party member's HP falls under the
    --   cure line, our own action ends or the busy wait runs out) instead of up to 0.25 s later; at most one extra pass
    --   every wake.gap seconds.
    wake = { on = true, gap = 0.05 },
    -- Scholar stratagems, main or sub SCH (vg_strat): which spells get which stratagem, reserve, Arts upkeep
    strat = { enabled = true, arts = 'auto', reserve = 1, jp_gift = false,
              perpetuance = 'Regen V,Regen IV,Regen III,Adloquium,Embrava,Haste,Haste II,Refresh,Refresh II,Refresh III,Phalanx,Phalanx II,Flurry,Flurry II,Aquaveil',
              accession = 'Regen V,Regen IV,Regen III,Regen II,Regen,Protect V,Protect IV,Shell V,Shell IV,Stoneskin,Blink,Aquaveil,Phalanx,Adloquium,Embrava',
              accession_count = 3, accession_cure = 3,
              penury = '', penury_mp = 30, celerity = 'Raise,Raise II,Raise III,Arise', celerity_hp = 30,
              rapture = '', rapture_hp = 0, altruism = '', tranquility = '',
              parsimony = '', parsimony_mp = 30, alacrity = '', manifestation = '', ebullience = '',
              focalization = '', equanimity = '' },
    mages = { aoe_na = true, bar = '', bar_status = '', pld = false, saboteur = true, stymie = true,
              sleep = false, sleep_skip = '', accession = true, perpetuance = true, immanence = true,
              chain = 'liquefaction', chain_every = 40,
              -- Sortie round 2026-11-25: chain_steps 2-5, chain_healer (healer role makes chains too), helix_close / helix_tier
              -- (Helix as the last step, I or II), finish_hp (magic killing blow at this HP %, 0 off), elements
              -- ("Name:element,..." weak element by target), storm_auto + klimaform (Storm of that element, Klimaform)
              chain_steps = 2, chain_healer = false, helix_close = false, helix_tier = 1, finish_hp = 0, elements = '',
              storm_auto = false, klimaform = true,
              -- vg_sortie: sortie_auto (the Scholar changes with the sector; set by //vg sortie), sortie_procs (Degei /
              -- Aita: a quick nuke of the element their last TP move made them weak to)
              sortie_auto = false, sortie_procs = true },
}

-- The update settings are called "updater", not "update": Windower's config library calls its own table method
-- :update on a copy of the settings when it first writes settings.xml (libs/config.lua, config.save), and a setting
-- named "update" hid that method - a brand-new install crashed at once with "libs/config.lua:344: attempt to call
-- method 'update' (a table value)" (a friend's first try, 2026-10-18). Older settings files still carry an <update>
-- section: it's taken out of the file before loading (so it can never hide the method again) and its on / off and
-- page are kept.
local function take_old_update_section()
    local path = (windower.addon_path or '') .. 'data/settings.xml'
    local f = io.open(path, 'r')
    if not f then return nil end
    local text = f:read('*a')
    f:close()
    if not text:find('<update>', 1, true) then return nil end
    local old = {}
    for block in text:gmatch('<update>(.-)</update>') do
        local repo, check = block:match('<repo>([^<]*)</repo>'), block:match('<check>([^<]*)</check>')
        if repo and repo ~= '' then old.repo = repo end
        if check == 'false' then old.check = false end
    end
    text = text:gsub('%s*<update>.-</update>', '')
    local w = io.open(path, 'w')
    if w then w:write(text) w:close() end
    return old
end
-- A numbered entry (trials / triggers t1, t2 ...) saved as a one-item list "<t1><1>text</1></t1>" instead of plain text:
-- Windower warned "Mismatched setting types for key 't1': table / string" and "Could not safely merge values for
-- 'global/trials/t1'" at every load and save, and the trial in it couldn't be read (his screenshot 2026-10-20).
-- Put back to plain text (an empty list to nothing) before loading.
local function fix_listed_entries()
    local path = (windower.addon_path or '') .. 'data/settings.xml'
    local f = io.open(path, 'r')
    if not f then return end
    local text = f:read('*a')
    f:close()
    local fixed, n = text:gsub('<(t%d+)>%s*<1>([^<]*)</1>%s*</t%d+>', function(tag, v) return '<' .. tag .. '>' .. v .. '</' .. tag .. '>' end)
    fixed = fixed:gsub('<(t%d+)>%s*</t%d+>', '<%1 />')
    -- any other entry saved as a numbered list (a priority order or weapon skill chain split at its commas:
    -- CharA's save crash of 2026-11-09): back to the text it was, "a,b,c"
    local m
    fixed, m = fixed:gsub('<([%a_][%w_]*)>(%s*<1>.-)</%1>', function(tag, inner)
        local parts = {}
        local rest = inner:gsub('%s*<(%d+)>([^<]*)</%1>%s*', function(i, v) parts[#parts + 1] = { tonumber(i), v } return '' end)
        if rest ~= '' or #parts == 0 then return nil end
        table.sort(parts, function(a, b) return a[1] < b[1] end)
        local out = {}
        for i, p in ipairs(parts) do out[i] = p[2] end
        return '<' .. tag .. '>' .. table.concat(out, ',') .. '</' .. tag .. '>'
    end)
    n = n + m
    if n > 0 and fixed ~= text then
        local w = io.open(path, 'w')
        if w then w:write(fixed) w:close() end
    end
end
fix_listed_entries()
local old_update = take_old_update_section()
local settings = config.load(defaults)
store.tidy(settings)   -- no lists where text belongs (vg_store: they made every save crash)
if old_update then
    if old_update.repo then settings.updater.repo = old_update.repo end
    if old_update.check == false then settings.updater.check = false end
end
-- Running or not is decided now, not by whatever was saved last time: only Auto start starts it by itself.
-- Windower's config library re-reads settings.xml right after loading and again at login (bringing back a saved
-- <enabled>true</enabled> - why CharB kept showing "running" with Auto start off), so it's applied again then.
-- ...except right after a reload (an update, //lua r): a character that was running carries on (resume_until is set
-- when it unloads). His report: "when I start farming it only stays on for about 2 minutes" - every update reload
-- switched farming off.
local resuming = (tonumber(settings.resume_until) or 0) > os.time()
settings.enabled = settings.autostart == true or resuming
if type(config.register) == 'function' then
    config.register(settings, function() store.tidy(settings) settings.enabled = settings.autostart == true or resuming end)
end

------------------------------------------------------------------------
-- Runtime state
------------------------------------------------------------------------
local state = {
    last_tick = 0,
    busy_until = 0,
    running = false,
    party_buffs = {},     -- [player id] = {buff ids}
    attempts = {},        -- [key] = os.clock() of last attempt (anti-spam)
    raised = {},          -- [name] = os.clock()
    burst = nil,          -- {elements = {...}, expires = t, target = id}
    sc = { target = 0, step = 0, time = 0 },
    songs = {},           -- [song name] = os.clock() last sung
    debuffs = {},         -- [mob id] = {[spell name] = {tries=n, landed=bool}}
    dispel_until = 0,
    mob_buff = nil,       -- {id = mob id, name = buff, move = TP move, at = t}: the last buff the battle target gained
    srv_status = nil,     -- our status as the server last sent it (0x037: 0 idle, 1 fighting), and since when
    srv_status_at = nil,
    resting = false,
    entrust = nil,        -- {spell, target, expires}
    farm_pulled = {},     -- [mob id] = true
    route = nil,          -- parsed waypoints
    wp = 1, wp_dir = 1,
    recording = false,
    action_once = {},     -- [action id] = mob id
    profile = nil,        -- {job, role, ws, toggles}
    profile_sent = 0,
    unseen = {},          -- [lower name] = {name, untl}: "can't see" members (3.1, see cant_see)
}

local function now() return os.clock() end

local function log(msg)
    windower.add_to_chat(207, '[Vanguard] ' .. msg)
    bridge.log(msg)
end

------------------------------------------------------------------------
-- Action helpers
------------------------------------------------------------------------
local function busy() return now() < state.busy_until end

-- An extra decision pass (CurePlease audit 1.3): asks the prerender loop for a pass at time `at` (now when nil) instead
-- of the next 0.25 s one. Only ever set here, from event handlers; the pass itself always runs in prerender, never
-- inside a packet / action handler. The earliest request wins.
local function wake(at)
    at = at or now()
    if not state.wake or at < state.wake then state.wake = at end
end

local function stop_running()
    if state.running then
        windower.ffxi.run(false)
        state.running = false
    end
end

local function recently(key, secs)
    local t = state.attempts[key]
    return t and (now() - t) < secs
end

local function mark(key) state.attempts[key] = now() end

-- MP reserve (series 3 round 3): the healing kinds of spells that may still be cast below mana.reserve.
local KEEP_FOR = { Raise = true, ['Raise II'] = true, ['Raise III'] = true, Arise = true, Erase = true, Esuna = true,
                   Sacrifice = true }
local function healing_spell(spell)
    if KEEP_FOR[spell.en] then return true end
    if spell.en:find('^Cur') or spell.en:find('na$') then return true end        -- Cure / Curaga / Cura, the -na spells
    if cure.is_heal(spell.en) then return true end                               -- a Blue Mage's cures (Magic Fruit...)
    return false
end

-- "Can't see the target" (1.3.0, CurePlease audit 3.1): the game refused our spell with "Unable to see X" / "You
-- cannot see X" (action messages 5, 217, 219: a member behind a wall or up a ledge). That member is left out of
-- cures, raises, -na spells and buffs for UNSEEN_SECS, so the next member is tried instead of the same refused cast
-- again and again. One owner: state.unseen is written only by cant_see (the 'action message' handler) and read by
-- unseen(); it expires by itself. Distance stays out_of_reach's job; mobs are never marked here (a pull that can't
-- see its mob is vg_farm's give-up list).
local UNSEEN_SECS = 3
local CANT_SEE_MSGS = { [5] = true, [217] = true, [219] = true }
local function unseen(name)
    local u = name and state.unseen[name:lower()]
    return u ~= nil and now() < u.untl
end

local STAND_BEFORE_CAST = 0.5       -- seconds standing still before a spell is sent
local function cast(spell, target, why)
    -- (a name the game just said it can't see: not sent until UNSEEN_SECS have passed - "<t>", "<me>"... always go)
    if type(target) == 'string' and target:sub(1, 1) ~= '<' and unseen(target) then return false end
    local reserve = tonumber(settings.mana.reserve) or 0
    if reserve > 0 and (spell.mp_cost or 0) > 0 and not healing_spell(spell) then
        local p = windower.ffxi.get_player()
        if p and (p.vitals.mpp or 100) < reserve then
            if not recently('mp_reserve', 60) then
                mark('mp_reserve')
                log(('MP %d%% is under the %d%% kept for cures: %s waits'):format(p.vitals.mpp, reserve, spell.en))
            end
            return false
        end
    end
    -- Still moving (following, walking to a mob) or stopped under half a second ago: the game hasn't seen us standing
    -- yet, so the spell would run its whole cast time and then be interrupted (his log 2026-11-14: "Blink was
    -- interrupted" over and over, Cure VI interrupted 2 s after it was sent with CharB at 55 %). Stop, keep still, and
    -- cast on the next pass - about half a second instead of losing the cast time and starting over.
    if now() - (state.moved_at or 0) < STAND_BEFORE_CAST then
        stop_running()
        state.casting_until = math.max(state.casting_until or 0, now() + 0.8)     -- (no walking off again meanwhile)
        state.stand_wait = now()                       -- (callers: "not sent yet, I am stopping for it" - not a refusal)
        return false
    end
    if strat.before_cast(spell, target, why) then return true end      -- a stratagem first; the spell follows
    stop_running()
    windower.send_command(('input /ma "%s" %s'):format(spell.en, target))
    state.last_ja = nil                    -- (a refusal message from now on is this spell's, not an ability's)
    state.last_ma = { key = 'ma:' .. spell.en .. ':' .. target, at = now() }     -- (until the cast begins: a refusal gives the wait back, ma_refused)
    -- stand still until the game says the cast began (then for its cast time) - 1.5 s if it never does (refused)
    state.casting_until = math.max(state.casting_until or 0, now() + 1.5)
    state.busy_until = now() + (spell.cast_time or 2) + (tonumber(settings.cast.tail) or 3)   -- (cast.tail, audit 1.4)
    state.no_move_until = now() + (spell.cast_time or 2) + 1     -- casting: can't walk, not "stuck"
    mark('ma:' .. spell.en .. ':' .. target)
    if why then log(('%s -> %s (%s)'):format(spell.en, target, why)) end
    return true
end

local function use_ja(ja, target)
    -- pet commands and blood pacts are /pet in the game's own data (Fight, Assault, Deploy, maneuvers, Hastega II...)
    local pet = ja.prefix == '/pet'
    windower.send_command(('input %s "%s" %s'):format(pet and '/pet' or '/ja', ja.en, target))
    state.busy_until = now() + 1.5
    -- confirm-and-chain (CurePlease audit 1.2): remembered so the game's answer (our category 6 action, or its refusal
    -- message) can end the 1.5 s wait early - see ja_answered. Pet commands and blood pacts aren't tracked: their
    -- answer comes from the pet (and a pact's own lock is the game's), so they keep the full 1.5 s.
    state.last_ja = (not pet) and { id = ja.id, en = ja.en, at = now() } or nil
    state.last_ma = nil                    -- (a refusal from now on is this ability's, not the last spell's)
    mark('ja:' .. ja.en .. ':' .. target)
    return true
end

-- A weapon skill the weapon in hand can't use isn't sent, and says so once a minute.
local function ws_fits(ws_name)
    if util.ws_fits(ws_name) then return true end
    if util.ws_unfit_note(ws_name, 'ws') then
        log(ws_name .. " doesn't work with the weapon in your hand: skipped")
    end
    return false
end

-- owner: 'scf' when the reactive skillchain follow-up (vg_scfollow) sends it. Any other sender (do_ws, battle lists,
-- EasyFarm's Weaponskill list, the finisher) holds while a follow-up owns the TP (one owner per action).
local function use_ws(ws_name, owner)
    if owner ~= 'scf' then
        local p = windower.ffxi.get_player()
        if p and scfollow.owns_tp(p, windower.ffxi.get_mob_by_target('t')) then return false end
    end
    if not ws_fits(ws_name) then return false end
    windower.send_command(('input /ws "%s" <t>'):format(ws_name))
    state.last_ja = nil                    -- (a refusal from now on is the weapon skill's)
    state.busy_until = now() + 2
    state.no_move_until = now() + 4          -- the weapon skill's animation: not "stuck" (vg_safety)
    mark('ws:' .. ws_name)
    log('WS: ' .. ws_name)
    return true
end

-- Out of casting range (spell range 12 = about 20' from the mob's edge): not sent. Geo bubbles and the Dia before them
-- were sent from 25-30' every 4 s, the game said "too far away" each time and no bubble went down (2026-10-19 GEO round)
local CAST_REACH = 21.5
local function out_of_reach(spell, target)
    if spell.range ~= 12 or (target ~= '<bt>' and target ~= '<t>') then return false end
    local mob = windower.ffxi.get_mob_by_target(target == '<bt>' and 'bt' or 't')
    local d = mob and util.dist(mob)
    if not d or d <= CAST_REACH then return false end
    if not recently('reach:' .. spell.en, 20) then
        mark('reach:' .. spell.en)
        log(("%s: %s is %d' away - waiting until it is within 21'"):format(spell.en, mob.name, math.floor(d)))
    end
    return true
end

local function try_cast(name, target, why, player)
    local spell = util.spell(name)
    if not spell or not util.spell_ready(spell, player) then return false end
    if recently('ma:' .. spell.en .. ':' .. target, 4) then return false end
    if out_of_reach(spell, target) then return false end
    return cast(spell, target, why)
end

local function can_act(player)
    if player.status ~= 0 and player.status ~= 1 then return false end   -- dead, resting, event
    -- asleep / petrified / stunned / charmed / terrorized (CurePlease audit 1.1): nothing can be used, so nothing is
    -- sent. One gate for every module that asks can_act (cures, songs, Geo, abilities, EasyFarm's gaps); the alt's
    -- "disabled" alert (vg_alts) still goes to the leader.
    if util.incapacitated(player.buffs) then return false end
    return not busy()
end

local function silenced(player)
    return util.has_buff(player.buffs, 6) or util.has_buff(player.buffs, 29)  -- silence, mute
end

local function amnesia(player)
    return util.has_buff(player.buffs, 16)
end

------------------------------------------------------------------------
-- Party helpers
------------------------------------------------------------------------
-- the alliance's other two parties (a10-a15, a20-a25), same shape as party_members
local function alliance_members(range)
    local out = {}
    local party = windower.ffxi.get_party()
    if not party then return out end
    for _, key in ipairs(util.ALLIANCE_KEYS) do
        local m = party[key]
        if key:sub(1, 1) == 'a' and m and m.name and m.mob and m.mob.valid_target ~= false then
            if not range or util.dist(m.mob) <= range then out[#out + 1] = m end
        end
    end
    return out
end

local function party_members(range)
    local out = {}
    local party = windower.ffxi.get_party()
    if not party then return out end
    for _, key in ipairs({'p0', 'p1', 'p2', 'p3', 'p4', 'p5'}) do
        local m = party[key]
        if m and m.name and m.mob and m.mob.valid_target ~= false then
            if not range or util.dist(m.mob) <= range then
                out[#out + 1] = m
            end
        end
    end
    return out
end

local function buffs_of(member, player)
    if member.name == player.name then return player.buffs end
    return member.mob and state.party_buffs[member.mob.id]
end

local function leader_mob(player)
    if settings.leader == '' or settings.leader:lower() == player.name:lower() then return nil end
    return windower.ffxi.get_mob_by_name(settings.leader)
end

local function battle_target()
    local bt = windower.ffxi.get_mob_by_target('bt')
    if bt and bt.hpp > 0 and bt.valid_target then return bt end
    return nil
end

------------------------------------------------------------------------
-- Movement: follow and combat positioning
------------------------------------------------------------------------
-- Casting or singing right now? From the game's own "casting begins / finished / interrupted" messages (and the moment
-- Vanguard sends a spell), so spells cast by hand or by GearSwap count too. Moving cancels a spell or song (his question
-- 2026-10-27: "does vanguard know, if the bard is singing songs or casting is happening, not to move the character").
local function casting() return now() < (state.casting_until or 0) end

-- Who started the running now going on (Silmaril audit 1.1, one owner per action): 'move' = the movement step
-- (do_movement: follow, formation, trail, camp, closing in, unstick), 'other' = anything else (farming walks, travel,
-- Corsair roll walk, EasyFarm...). The fast movement passes between decision passes only steer or stop running that
-- the movement step started; anything else's walking is left to the 0.25 s decision pass, as before.
local in_move, fast_pass = false, false

local function run_toward(me, mob)
    -- DO NOT MOVE (his request 2026-10-19: "a DO NOT MOVE button ... that overrides all the other movements"): every
    -- walk Vanguard makes - farming, back to camp, follow, closing in, formation, travel - comes through here
    -- (the enfeebler's "stay put", enfeebler.stay, is the same: it casts from where it stands)
    if settings.farm.stay or (settings.enfeebler.on and settings.enfeebler.stay) then stop_running() return false end
    if casting() then stop_running() return false end                 -- (a spell / song in progress: stand still)
    local dx, dy = mob.x - me.x, mob.y - me.y
    local len = math.sqrt(dx * dx + dy * dy)
    if len < 0.01 then return end
    local ux, uy = dx / len, dy / len
    state.run_by = in_move and 'move' or 'other'
    -- fast passes: the same way as already running (under ~2 degrees off) is not sent again - at least once a decision
    -- pass (tick) it still is, as before, so a run the game dropped is picked up again
    local rd = state.run_dir
    if fast_pass and state.running and rd and rd[1] * ux + rd[2] * uy > 0.9994 and now() - (state.run_sent or 0) < settings.tick then
        return true
    end
    windower.ffxi.run(ux, uy)
    state.running = true
    state.run_dir = { ux, uy }
    state.run_sent = now()
    return true
end

local function face(me, mob)
    local a = -(math.atan2 or math.atan)(mob.y - me.y, mob.x - me.x)
    -- fast passes: already facing it (within ~3 degrees): no turn sent
    if fast_pass and me.facing then
        local d = (a - me.facing + math.pi) % (2 * math.pi) - math.pi
        if math.abs(d) < 0.05 then return end
    end
    windower.ffxi.turn(a)
end

local function do_movement(player)
    local me = windower.ffxi.get_mob_by_target('me')
    if not me then return end
    if support.hover_tick() then return end          -- a Ranger's Hover Shot side step (vg_support): it owns the walk
    -- bringing a mob back to camp comes first (abilities wait until it's there)
    state.farm_bringing = nil
    if player.status == 1 and settings.modules.farm and settings.farm.pull_back and not state.hold then
        local t = windower.ffxi.get_mob_by_target('t')
        if t and t.hpp > 0 and party.pull_to_camp(player, me, t) then state.farm_bringing = t.id return end
    end
    if busy() then stop_running() return end
    if state.hold then stop_running() return end
    if safety.unstick() then state.run_by = 'move' return end

    -- Engaged melee: close to melee range on our target.
    -- farming decides by its own "Then: walk up to it / let it come to me" - the role's "close in" (melee roles have
    -- it on) made a farmer that pulled and should wait walk to every mob anyway (his BLU, 2026-10-19)
    local approach
    if settings.modules.farm then approach = settings.farm.approach ~= false
    else approach = settings.modules.assist and settings.assist.approach end
    if player.status == 1 and approach then
        local t = windower.ffxi.get_mob_by_target('t')
        if t and t.hpp > 0 then
            if party.pull_to_camp(player, me, t) then return end   -- puller: back to camp, let it come
            local d = util.dist(t)
            -- farming: close in on its own mob from any distance (assist keeps the engage_range limit)
            if d > settings.assist.melee_range and (d < settings.assist.engage_range or (settings.modules.farm and settings.farm.approach)) then
                run_toward(me, t)
            else
                stop_running()
                face(me, t)
            end
            return
        end
    end
    -- farming with "let it come to me": no chasing - but once the mob has come (within 8') close the last yalms to
    -- melee range, or the weapon skills are refused from just out of reach (his BLU: Expiacion every 3 s, 2026-10-19)
    if player.status == 1 and settings.modules.farm and settings.farm.approach == false then
        local t = windower.ffxi.get_mob_by_target('t')
        if t and t.hpp > 0 then
            local d = util.dist(t)
            -- still coming: wait; stopped short of melee range for 1.5 s (a hovering bat): step in
            local w = state.stay_watch
            if not w or w.id ~= t.id then w = { id = t.id, d = d, t = now() } state.stay_watch = w end
            if d < w.d - 0.3 then w.d, w.t = d, now() end
            local stalled = now() - w.t >= 1.5
            if d > settings.assist.melee_range and d <= 8 and stalled then
                run_toward(me, t)
            else
                stop_running()
                face(me, t)
            end
            return
        end
    end

    -- Engaged but not closing in (a healer, a mage, "close in" off): still turn to the mob - the game doesn't, and
    -- facing away blocks weapon skills and melee (his report 2026-10-22: "sometimes the vanguard will not face the
    -- monsters")
    if player.status == 1 then
        local t = windower.ffxi.get_mob_by_target('t')
        if t and (t.hpp or 0) > 0 and t.is_npc then face(me, t) end
    end
    -- Camp spot / formation behind the leader (vg_party), else plain follow - not for the farmer: it leads.
    if not settings.modules.farm and party.movement(player, me) then return end
    if settings.modules.follow and not settings.modules.farm then
        local l = leader_mob(player)
        if l then
            local d = util.dist(l)
            if d > settings.follow.distance and d < settings.follow.max_distance then
                run_toward(me, l)
                return
            end
        end
    end
    if settings.modules.farm and player.status == 0 and state.route_moving then return end
    stop_running()
end

-- The movement step as the decision pass runs it: remembers that it ran and whether it left us running, so the fast
-- passes know they may carry on steering (see fast_move_ok in the prerender handler).
local function run_movement(player)
    in_move = true
    do_movement(player)
    in_move = false
    state.move_ran = true
    state.move_wanted = state.running and state.run_by == 'move'
end

-- Seconds between movement passes (follow.move_tick), or nil when they are off (0, or not faster than the decisions).
local function move_interval()
    local mt = tonumber(settings.follow.move_tick) or 0
    if mt <= 0 then return nil end
    if mt < 0.05 then mt = 0.05 end
    if mt >= (tonumber(settings.tick) or 0.25) then return nil end
    return mt
end

-- A fast movement pass (Silmaril audit 1.1: steering 10 times a second, decisions 4 times a second). Light work only:
-- my own mob, the leader's, the movement step. No get_player (the decision pass's player, with today's status), no
-- casting, no abilities, no stuck check (safety.watch stays on the decision pass, its 2 s timing unchanged).
-- Who wins: the decision pass. A fast pass runs only when the last decision pass ran the movement step and left either
-- the movement step's own running, or no running it wanted (if a later step in that pass stopped the movement step's
-- run - a cast, a roll walk - the fast passes keep out of it until the next decision pass).
local function move_step()
    local p = state.tick_player
    if p then party.send_pos(p) end                      -- (the leader's position for the trail: 0.1 s while it moves)
    if not state.fast_move_ok or not p or not settings.enabled or state.away or state.resting then return end
    if state.running and state.run_by ~= 'move' then return end      -- someone else is walking us: not ours to steer
    local me = windower.ffxi.get_mob_by_target('me')
    if not me or (me.status ~= 0 and me.status ~= 1) then return end
    local view = setmetatable({ status = me.status }, { __index = p })
    in_move, fast_pass = true, true
    do_movement(view)
    in_move, fast_pass = false, false
end

------------------------------------------------------------------------
-- Assist / engage
------------------------------------------------------------------------
-- The mob the leader is fighting: engaged on it - or (assist.on_claim) not engaged but with a monster targeted that
-- the party has claimed (a leader who pulls with a spell or a ranged attack, a mage who never engages).
local function leader_target(player)
    local l = leader_mob(player)
    if not l or not l.target_index or l.target_index == 0 then return nil end
    if l.status ~= 1 and not (settings.assist.on_claim and l.status == 0) then return nil end
    local lt = windower.ffxi.get_mob_by_index(l.target_index)
    if not lt or (lt.hpp or 0) == 0 or lt.valid_target == false then return nil end
    if l.status ~= 1 then
        if not lt.is_npc or lt.spawn_type ~= 16 or not lt.claim_id or lt.claim_id == 0 then return nil end
        local mine = util.alliance_ids()[lt.claim_id] == true       -- (claimed by my party or the alliance)
        if not mine and lt.claim_id ~= l.id then return nil end
    end
    return lt
end

local function do_assist(player)
    if not settings.modules.assist or not settings.assist.engage or state.hold or state.retreat then return false end
    if settings.modules.farm then return false end              -- the farmer picks its own mobs
    local lt = leader_target(player)
    if not lt then state.assist_seen = nil return false end
    if util.dist(lt) > settings.assist.engage_range then return false end
    if player.status == 0 then
        -- "wait N seconds" / "only once it is at or under N % HP": let the leader get its attention first
        local seen = state.assist_seen
        if not seen or seen.id ~= lt.id then seen = { id = lt.id, t = now() } state.assist_seen = seen end
        if now() - seen.t < (tonumber(settings.assist.delay) or 0) then return false end
        if (lt.hpp or 100) > (tonumber(settings.assist.below_hp) or 100) then return false end
    end
    -- the leader is bringing it back to camp: wait there for it
    if player.status == 0 and party.mob_far_from_camp(lt) then return false end

    if player.status == 0 then
        if recently('engage', 4) then return false end
        mark('engage')
        windower.send_command(('input /assist %s; wait 1.2; input /attack <t>'):format(settings.leader))
        state.busy_until = now() + 2
        log('Engaging ' .. lt.name)
        return true
    elseif player.status == 1 then
        local t = windower.ffxi.get_mob_by_target('t')
        if settings.assist.switch ~= false and (not t or t.id ~= lt.id) and not recently('switch', 4) then
            mark('switch')
            windower.send_command(('input /assist %s'):format(settings.leader))
            state.busy_until = now() + 1.5
            log('Switching to ' .. lt.name)
            return true
        end
    end
    return false
end

------------------------------------------------------------------------
-- Healing, raising, status removal
------------------------------------------------------------------------
local cure_tiers = {
    {'Cure VI', 1300}, {'Cure V', 1000}, {'Cure IV', 650},
    {'Cure III', 350}, {'Cure II', 170}, {'Cure', 70},
}
local curaga_tiers = {'Curaga V', 'Curaga IV', 'Curaga III', 'Curaga II', 'Curaga'}
local raise_tiers = {'Arise', 'Raise III', 'Raise II', 'Raise'}

local status_cures = {
    {'petrification', 'Stona'}, {'doom', 'Cursna'}, {'paralysis', 'Paralyna'},
    {'silence', 'Silena'}, {'curse', 'Cursna'}, {'plague', 'Viruna'},
    {'disease', 'Viruna'}, {'blindness', 'Blindna'}, {'poison', 'Poisona'},
    {'slow', 'Erase'}, {'weight', 'Erase'}, {'bind', 'Erase'}, {'Addle', 'Erase'},
    {'Elegy', 'Erase'}, {'Requiem', 'Erase'}, {'Threnody', 'Erase'}, {'Helix', 'Erase'},
    {'Bio', 'Erase'}, {'Dia', 'Erase'}, {'Flash', 'Erase'}, {'Burn', 'Erase'}, {'Frost', 'Erase'},
    {'Choke', 'Erase'}, {'Rasp', 'Erase'}, {'Shock', 'Erase'}, {'Drown', 'Erase'},
    {'Attack Down', 'Erase'}, {'Defense Down', 'Erase'}, {'Accuracy Down', 'Erase'},
    {'Evasion Down', 'Erase'}, {'Magic Atk. Down', 'Erase'}, {'Magic Acc. Down', 'Erase'},
    {'Magic Def. Down', 'Erase'}, {'Max HP Down', 'Erase'}, {'Max MP Down', 'Erase'},
    {'STR Down', 'Erase'}, {'DEX Down', 'Erase'}, {'VIT Down', 'Erase'}, {'AGI Down', 'Erase'},
    {'INT Down', 'Erase'}, {'MND Down', 'Erase'}, {'CHR Down', 'Erase'},
    {'Amnesia', 'Esuna'},
}
local status_ids = {}
for _, pair in ipairs(status_cures) do
    local id = util.buff_id(pair[1])
    if id then status_ids[#status_ids + 1] = {id, pair[2], pair[1]} end
end

-- The cure tiers from settings.heal.tiers ("Cure IV:650,..."), biggest first; 0 leaves a tier out.
local function tiers()
    local out = {}
    for _, entry in ipairs(util.split(settings.heal.tiers or '', ',')) do
        local name, hp = entry:match('^(.-)%s*:%s*(%d+)$')
        if name and tonumber(hp) > 0 then out[#out + 1] = { name, tonumber(hp) } end
    end
    if #out == 0 then return cure_tiers end
    table.sort(out, function(a, b) return a[2] > b[2] end)
    return out
end

local function pick_cure(missing, player)
    local best
    local list = tiers()
    for i = #list, 1, -1 do                 -- smallest first
        local s = util.spell(list[i][1])
        if util.spell_ready(s, player) then
            best = s
            if list[i][2] >= missing then return s end
        end
    end
    return best                              -- biggest available
end

local sleep_ids = {2, 19}   -- sleep, lullaby/sleep II
local do_status             -- (defined below; do_heal lets a dangerous ailment go first)

local function do_heal(player)
    if not settings.modules.heal or silenced(player) then return false end
    local members = {}
    local ignore = {}
    for _, n in ipairs(util.split(settings.heal.ignore, ',')) do ignore[n:lower()] = true end
    local in_party, lowest = {}, 100
    for _, m in ipairs(party_members(settings.heal.range)) do
        in_party[m.name:lower()] = true
        if not ignore[m.name:lower()] and not unseen(m.name) then          -- (can't see: the others first, 3.1)
            members[#members + 1] = m
            if (m.hpp or 0) > 0 and m.hpp < lowest then lowest = m.hpp end
        end
    end
    -- the alliance's other two parties (heal.alliance): their real HP is in the party list; never in a Curaga
    if settings.heal.alliance then
        for _, m in ipairs(alliance_members(settings.heal.range)) do
            if not ignore[m.name:lower()] and not in_party[m.name:lower()] and not unseen(m.name) then
                in_party[m.name:lower()] = true
                members[#members + 1] = { name = m.name, hpp = m.hpp, hp = (m.hp and m.hp > 0) and m.hp or (m.hpp or 0) * 15,
                                          mob = m.mob, outsider = true, alliance = true }
            end
        end
    end
    -- people outside the party on the watch list: cured by their HP% (their HP isn't known: counted as 1500 at full,
    -- HealBot's guess). Curaga never counts them - it only reaches the party.
    for _, n in ipairs(util.split(settings.heal.watch or '', ',')) do
        if not in_party[n:lower()] and not unseen(n) then
            local mob = windower.ffxi.get_mob_by_name(n)
            if mob and not mob.is_npc and mob.valid_target ~= false and (mob.hpp or 0) > 0 and util.dist(mob) <= settings.heal.range then
                members[#members + 1] = { name = mob.name, hpp = mob.hpp, hp = mob.hpp * 15, mob = mob, outsider = true }
            end
        end
    end
    -- a dangerous ailment goes before a routine cure (HealBot: Paralyna on the healer first; CurePlease: "prioritise
    -- debuffs"): Doom or petrification on anyone, my own paralysis - unless someone is under 40 %
    if lowest >= 40 and settings.modules.cleanse and do_status(player, true) then return true end

    -- Wake sleeping members (CurePlease "wake sleep").
    if settings.heal.wake_sleep then
        for _, m in ipairs(members) do
            local bl = buffs_of(m, player)
            if m.name ~= player.name and m.hpp > 0 and bl
                and (util.has_buff(bl, sleep_ids[1]) or util.has_buff(bl, sleep_ids[2])) then
                for _, name in ipairs({'Cure', 'Cure II', 'Curaga'}) do
                    if try_cast(name, m.name, 'wake ' .. m.name, player) then return true end
                end
            end
        end
    end

    local priority = {}
    for _, n in ipairs(util.split(settings.heal.priority, ',')) do priority[n:lower()] = true end
    -- covered by someone else: another healer's cure is on its way (vg_share), or the app's team planner gave this
    -- member to another healer (vg_plan: only a fresh plan, never under share.emergency HP - then anyone cures)
    local function being_cured(m) return planner.cure_elsewhere(m, player) or share.being_cured(m) end

    -- AUTO (the default): vg_cure decides - learned potencies per job, triage, Curaga by who stands near whom
    if settings.heal.auto ~= false then
        -- (the planner's split only picks the single-cure target: everyone hurt still counts towards a Curaga)
        -- (predictive healing, 3.2: every pass adds a sample to the HP history; the party updates below add the rest)
        if settings.heal.predict then
            for _, m in ipairs(members) do cure.observe(cure.hkey(m), m.hpp, now()) end
        end
        local plan = cure.plan(members, player, priority, share.being_cured, function(m) return planner.cure_elsewhere(m, player) end)
        if not plan then return false end
        local who = plan.target.name
        if recently('ma:' .. plan.spell.en .. ':' .. who, 3) or out_of_reach(plan.spell, who) then return false end
        -- what everyone was missing when it was cast: a heal that fills someone up teaches only "at least this much"
        local miss = {}
        for _, m in ipairs(members) do if m.mob then miss[m.mob.id] = cure.missing(m) end end
        state.cure_cast = { spell = plan.spell.en, missing = miss, at = now() }
        share.cure(player, plan.curaga and '*' or who, plan.spell.cast_time or 3)
        return cast(plan.spell, who, plan.why)
    end

    local worst, worst_hpp, low_count = nil, 101, 0
    for _, m in ipairs(members) do
        if m.hpp > 0 then
            if m.hpp < settings.heal.curaga_at then low_count = low_count + 1 end
            local is_prio = priority[m.name:lower()]
            local threshold = is_prio and settings.heal.priority_at or settings.heal.cure_at
            if m.alliance then threshold = math.min(threshold, tonumber(settings.heal.alliance_at) or 60) end
            -- Priority members sort ahead of everyone else.
            local score = is_prio and (m.hpp - 100) or m.hpp
            if m.hpp < threshold and score < worst_hpp and not being_cured(m) then
                worst, worst_hpp = m, score
            end
        end
    end
    if not worst then return false end

    if settings.heal.curaga and low_count >= settings.heal.curaga_count then
        local allowed = {}
        for _, n in ipairs(util.split(settings.heal.curagas or '', ',')) do allowed[n:lower()] = true end
        for _, name in ipairs(curaga_tiers) do
            if allowed[name:lower()] and try_cast(name, worst.name, low_count .. ' members hurt', player) then
                local sp = util.spell(name)
                share.cure(player, '*', sp and sp.cast_time or 3)
                return true
            end
        end
    end
    local max_hp = worst.hpp > 0 and math.floor(worst.hp * 100 / worst.hpp) or worst.hp
    local spell = pick_cure(max_hp - worst.hp, player)
    if spell and not recently('ma:' .. spell.en .. ':' .. worst.name, 3) then
        share.cure(player, worst.name, spell.cast_time or 3)
        return cast(spell, worst.name, worst.name .. ' at ' .. worst.hpp .. '%')
    end
    return false
end

local function do_raise(player)
    if not settings.modules.raise or silenced(player) then return false end
    local list = party_members(20)
    if settings.heal.alliance_raise then                  -- (the alliance's other parties too, after my own)
        for _, m in ipairs(alliance_members(20)) do list[#list + 1] = m end
    end
    for _, m in ipairs(list) do
        if m.hpp == 0 and m.name ~= player.name and not unseen(m.name) then
            local t = state.raised[m.name]
            if not t or now() - t > 60 then
                for _, name in ipairs(raise_tiers) do
                    if try_cast(name, m.name, 'KO', player) then
                        state.raised[m.name] = now()
                        return true
                    end
                end
            end
        end
    end
    return false
end

-- Divine Caress (1.3.0, CurePlease audit 2.1): used right before a -na spell goes on someone, and only then (CurePlease
-- fires it whenever it's ready, debuff or not). Who owns it: do_status alone - the WHM action "divine_caress" is
-- reactive (never used from the action list), its Job-tab tick only says whether this may use it (off by default).
-- Returns true when Divine Caress was sent (the -na follows on the next pass, with the Caress up).
local DIVINE_CARESS = 453
local function caress_first(player, spell_name, target)
    if player.main_job ~= 'WHM' or not settings.modules.actions or not state.profile then return false end
    if not spell_name:find('na$') then return false end                   -- (Poisona ... Cursna, Esuna; not Erase)
    if util.has_buff(player.buffs, DIVINE_CARESS) or amnesia(player) then return false end
    local action
    for _, a in ipairs(jobs.WHM.actions) do if a.id == 'divine_caress' then action = a end end
    if not action or not engine.enabled(action, state.profile) then return false end
    local ja = util.ability('Divine Caress')
    if not ja or not util.ability_ready(ja) or recently('ja:Divine Caress:<me>', 5) then return false end
    -- only when the -na itself can go right now (else Caress would wait up unused)
    local spell = util.spell(spell_name)
    if not spell or not util.spell_ready(spell, player) or recently('ma:' .. spell.en .. ':' .. target, 4) then return false end
    log(('Divine Caress before %s on %s'):format(spell.en, target))
    return use_ja(ja, '<me>')
end

local URGENT = { doom = true, petrification = true }
do_status = function(player, urgent)
    if not settings.modules.cleanse or silenced(player) then return false end
    local ignore, skip = {}, {}
    for _, n in ipairs(util.split(settings.heal.ignore, ',')) do ignore[n:lower()] = true end
    for _, n in ipairs(util.split(settings.cleanse.skip, ',')) do skip[n:lower()] = true end
    local members, wanted = {}, {}
    for _, m in ipairs(party_members(settings.heal.range)) do
        if not ignore[m.name:lower()] and not unseen(m.name) then members[#members + 1] = m end
    end
    for _, entry in ipairs(status_ids) do
        if not skip[entry[3]:lower()] then wanted[#wanted + 1] = entry end
    end
    if not urgent and mages.aoe_na(player, wanted, members) then return true end
    for _, m in ipairs(members) do
        local bl = buffs_of(m, player)
        if bl and m.hpp > 0 then
            for _, entry in ipairs(status_ids) do
              if not urgent or URGENT[entry[3]] or (entry[3] == 'paralysis' and m.name == player.name) then
                -- Esuna only removes an ailment the caster has too (BG Wiki): on someone else's Amnesia it did nothing,
                -- six times in a row on Godbolt (his log 2026-11-14)
                local esuna_ok = entry[2] ~= 'Esuna' or util.has_buff(player.buffs, entry[1])
                -- Erase at low MP (under 40 %): only on myself; the mobs put Defense Down & co. back at once and
                -- the MP is needed for cures (his CharB 2026-11-21: 21 Erases, 10 on Zurii, MP at 1-9 %)
                if entry[2] == 'Erase' and m.name ~= player.name and ((player.vitals or {}).mpp or 100) < 40 then esuna_ok = false end
                if esuna_ok and not skip[entry[3]:lower()] and util.has_buff(bl, entry[1]) then
                    if caress_first(player, entry[2], m.name) then return true end
                    if try_cast(entry[2], m.name, entry[3], player) then return true end
                end
              end
            end
        end
    end
    return false
end

-- Items for my own ailments (CurePlease "use item for Doom / Silence", Silmaril "remove those nasty debuffs" -
-- compared 2026-10-28): any job, when the item is in the inventory and I can't fix it with my own spell.
local AILMENT_ITEMS = {
    { 'silence', { 'Echo Drops', 'Remedy' } }, { 'doom', { 'Holy Water', 'Hallowed Water' } },
    { 'curse', { 'Holy Water', 'Hallowed Water' } }, { 'paralysis', { 'Remedy' } }, { 'poison', { 'Remedy', 'Antidote' } },
    { 'blindness', { 'Remedy', 'Eye Drops' } }, { 'disease', { 'Remedy' } }, { 'plague', { 'Remedy' } },
}
-- In the inventory or the Temporary Items bag (bag 3, CurePlease audit 2.9): Abyssea / Sortie temporaries (Dusty /
-- Lucid items, Megalixir) live there and /item uses them from it.
local function have_item(name)
    local id = items.id(name)
    if not id then return false end
    for _, bag in ipairs({ 'inventory', 'temporary' }) do
        local list = windower.ffxi.get_items(bag)
        for _, it in ipairs(type(list) == 'table' and list or {}) do
            if type(it) == 'table' and it.id == id and (it.count or 1) > 0 then return true end
        end
    end
    return false
end
-- Temporary MP items (audit 2.9, CurePlease F51), weakest first, the ones that also restore HP after, Megalixir last.
-- items.temp_mp = under this MP% (0 = off). Owner: this is the only item use for MP (Sublimation / Convert / Devotion
-- in do_mana are spells and abilities). It runs right after do_mana in the 'abilities2' group, so when one of those
-- is ready it goes first, MP is back up and this stays quiet.
local TEMP_MP_ITEMS = { 'Dusty Ether', 'Lucid Ether I', 'Lucid Ether II', 'Lucid Ether III', 'Dusty Elixir',
                        'Lucid Elixir I', 'Lucid Elixir II', 'Megalixir' }
local function do_temp_mp(player)
    local at = tonumber((settings.items or {}).temp_mp) or 0
    if at <= 0 then return false end
    if player.status ~= 0 and player.status ~= 1 then return false end
    local v = player.vitals or {}
    if (v.max_mp or 0) <= 0 or (v.mpp or 100) >= at or recently('temp_mp', 10) then return false end
    for _, item in ipairs(TEMP_MP_ITEMS) do
        if have_item(item) then
            mark('temp_mp')
            windower.send_command(('input /item "%s" <me>'):format(item))
            state.busy_until = now() + 2
            log(('MP %d%%: %s'):format(v.mpp or 0, item))
            return true
        end
    end
    return false
end
local function do_items(player)
    if settings.cleanse.items == false then return false end
    if player.status ~= 0 and player.status ~= 1 then return false end
    for _, entry in ipairs(AILMENT_ITEMS) do
        local id = util.buff_id(entry[1])
        if id and util.has_buff(player.buffs, id) then
            -- my own -na spell first, when I can cast it (silence: never)
            local fix
            for _, pair in ipairs(status_cures) do if pair[1] == entry[1] then fix = util.spell(pair[2]) end end
            local own = fix and not silenced(player) and util.can_cast(fix, player)
            if not own then
                for _, item in ipairs(entry[2]) do
                    if have_item(item) and not recently('item:' .. item, 4) then
                        mark('item:' .. item)
                        windower.send_command(('input /item "%s" <me>'):format(item))
                        state.busy_until = now() + 2
                        log(('%s: %s'):format(entry[1]:gsub('^%l', string.upper), item))
                        return true
                    end
                end
            end
        end
    end
    return false
end

-- Doom or Silence on me can't wait behind the cures (0.99.2): with a member under 40 % the cures went first every pass,
-- so the Holy Water for my own Doom (a countdown to a KO) never got its turn; and a silenced healer can't cure at all
-- until the Echo Drops are used. Only these two, only with the item in the bag; everything else keeps its place.
local URGENT_ITEMS = { { 'doom', { 'Holy Water', 'Hallowed Water' } }, { 'silence', { 'Echo Drops', 'Remedy' } } }
local function do_urgent_items(player)
    if settings.cleanse.items == false then return false end
    if player.status ~= 0 and player.status ~= 1 then return false end
    for _, entry in ipairs(URGENT_ITEMS) do
        local id = util.buff_id(entry[1])
        if id and util.has_buff(player.buffs, id) then
            for _, item in ipairs(entry[2]) do
                if have_item(item) and not recently('item:' .. item, 4) then
                    mark('item:' .. item)
                    windower.send_command(('input /item "%s" <me>'):format(item))
                    state.busy_until = now() + 2
                    log(('%s: %s (first)'):format(entry[1]:gsub('^%l', string.upper), item))
                    return true
                end
            end
        end
    end
    return false
end

------------------------------------------------------------------------
-- What goes first (his request 2026-10-28: "Choose the order of priorities yourself" - Silmaril's Priority page).
-- Twelve groups in the order they're tried every tick; the first that acts wins. Saved per job as text
-- (settings.priorities["<JOB>"] = "raise,cures,..."); empty = this default, the order Vanguard always used.
------------------------------------------------------------------------
local PRIORITY_DEFAULT = { 'raise', 'cures', 'ailments', 'songs', 'fighting', 'abilities', 'ws', 'bursts', 'abilities2',
                           'enfeebles', 'geo', 'buffs' }
local PRIORITY_LABEL = { raise = 'Raise', cures = 'Cures', ailments = 'Remove ailments (-na, items)', songs = 'Songs',
    fighting = 'Fighting: engage, pull, battle lists', abilities = 'Job abilities before weapon skills',
    ws = 'Weapon skills and skillchains', bursts = 'Magic bursts', abilities2 = 'Other job abilities, rolls, MP',
    enfeebles = 'Dispel and enfeebles', geo = 'Geomancy', buffs = 'Buffs' }
local function priority_order(job)
    local raw = tostring(util.job_get(settings.priorities, job or '') or '')
    local out, seen = {}, {}
    for _, k in ipairs(util.split(raw, ',')) do
        k = util.trim(k):lower()
        if PRIORITY_LABEL[k] and not seen[k] then out[#out + 1] = k seen[k] = true end
    end
    for _, k in ipairs(PRIORITY_DEFAULT) do if not seen[k] then out[#out + 1] = k end end   -- (new / missing groups)
    return out
end

------------------------------------------------------------------------
-- Buff upkeep
------------------------------------------------------------------------
-- A buff that never shows up on its target (it doesn't take: a stronger one already there, out of reach...): after 3
-- casts in 90 s without it appearing, wait 3 minutes (his CharB 2026-11-21: Haste on Lilmagic 6 times in a minute at
-- 3-7 % MP, 52 Hastes in 52 minutes)
local function buff_backoff(spell, who)
    state.buff_fail = state.buff_fail or {}
    local f = state.buff_fail[spell .. '>' .. who:lower()]
    if not f then return false end
    if f.wait and now() < f.wait then return true end
    if f.n >= 3 and now() - f.first <= 90 then
        f.wait = now() + 180
        f.n, f.first = 0, now() + 180
        log(("%s on %s doesn't take (3 casts, never there): trying again in 3 minutes"):format(spell, who))
        return true
    end
    return false
end
local function buff_sent(spell, who)                 -- (only casts that really went out count)
    state.buff_fail = state.buff_fail or {}
    local k = spell .. '>' .. who:lower()
    local f = state.buff_fail[k]
    if not f or now() - f.first > 90 then f = { n = 0, first = now() } state.buff_fail[k] = f end
    f.n = f.n + 1
end
local function buff_took(spell, who)
    if state.buff_fail then state.buff_fail[spell .. '>' .. who:lower()] = nil end
end

local function do_buffs(player)
    if not settings.modules.buffs then return false end
    local members = {}
    for _, m in ipairs(party_members(20)) do members[m.name:lower()] = m end

    for _, entry in ipairs(util.split(settings.buffs.list, ',')) do
        local what, who = entry:match('^(.-)%s*>%s*(.+)$')
        what, who = what or entry, who or 'me'
        local is_ja = what:lower():sub(1, 3) == 'ja:'
        if is_ja then what = util.trim(what:sub(4)) end

        local target_name = (who:lower() == 'me') and player.name or who
        local m = members[target_name:lower()]
        if m and not unseen(m.name) then
            local bl = buffs_of(m, player)
            local action = is_ja and util.ability(what) or util.spell(what)
            if action and bl then
                local buff_id = action.status or util.buff_id(what:gsub('%s+[IVX]+$', ''))
                local present = buff_id and util.has_buff(bl, buff_id)
                if present then buff_took(action.en, target_name) end
                local due = buff_id and not present
                if buff_id and not is_ja then
                    if not present and target_name ~= player.name then bufftime.on_gone(action, target_name) end
                    -- "Recast this long before it wears off" (Buffs tab): due while it still has that long or less
                    if present then
                        local before = bufftime.before(action.en)
                        local left = before > 0 and bufftime.left(action, target_name, target_name == player.name)
                        if left and left <= before then due = true end
                    end
                end
                if due then
                    local tgt = (target_name == player.name) and '<me>' or target_name
                    if is_ja then
                        if not amnesia(player) and util.ability_ready(action)
                            and not recently('ja:' .. action.en .. ':' .. tgt, 5) then
                            return use_ja(action, tgt)
                        end
                    elseif not silenced(player) and util.spell_ready(action, player)
                        and not recently('ma:' .. action.en .. ':' .. tgt, 6) and not buff_backoff(action.en, target_name)
                        and engine.tools_ok(action.en, player, log) then   -- (Utsusemi: only with ninja tools)
                        local ok = cast(action, tgt, 'buff')
                        if ok and state.casting_until and now() < state.casting_until and recently('ma:' .. action.en .. ':' .. tgt, 0.1) then
                            buff_sent(action.en, target_name)
                        end
                        if ok then return true end
                    end
                end
            end
        end
    end
    return false
end

------------------------------------------------------------------------
-- Weapon skills, skillchains, magic bursts
------------------------------------------------------------------------
local function sc_steps()
    local steps = {}
    for _, s in ipairs(util.split(settings.sc.steps, ',')) do
        local who, ws = s:match('^(.-)%s*:%s*(.+)$')
        if who and ws then steps[#steps + 1] = {who = who:lower(), ws = ws} end
    end
    return steps
end

local function party_tp(name)
    for _, m in ipairs(party_members()) do
        if m.name:lower() == name then return m.tp or 0 end
    end
    return 0
end

local function ws_in_range(t)
    return t and t.hpp >= settings.ws.min_mob_hpp and util.dist(t) <= settings.ws.max_range
end

local function do_skillchain(player)
    if not settings.modules.sc or player.status ~= 1 or amnesia(player) then return false end
    local steps = sc_steps()
    if #steps == 0 then return false end
    local t = windower.ffxi.get_mob_by_target('t')
    if not ws_in_range(t) then return false end
    local me = player.name:lower()

    -- Expire an unfinished chain.
    local wmin, wmax = scfollow.sc_window()       -- (1.2.0: never under 2 s / over 10 s; scf.tune_sc: the learned window)
    if state.sc.step > 0 and (now() - state.sc.time > wmax or state.sc.target ~= t.id) then
        state.sc = { target = 0, step = 0, time = 0 }
    end

    local next_step = state.sc.step + 1
    local step = steps[next_step]
    if not step or step.who ~= me or player.vitals.tp < 1000 then return false end

    if next_step == 1 then
        -- Open only when every participant has enough TP to continue.
        if player.vitals.tp < settings.sc.open_tp then return false end
        for i = 2, #steps do
            if steps[i].who ~= me and party_tp(steps[i].who) < 1000 then return false end
        end
        return use_ws(step.ws)
    end
    local elapsed = now() - state.sc.time
    if elapsed >= wmin and elapsed <= wmax then
        return use_ws(step.ws)
    end
    return false
end

-- Aftermath upkeep (ws.am, his request 2026-10-19): the level wanted and its weapon skill when Aftermath is below it
-- (or under 8 s left), else nil. do_ws saves TP for it; vg_scfollow lets it win over a follow-up.
-- fits: do_ws passes ws_fits (says once why a weapon skill doesn't fit the weapon); others the quiet util.ws_fits.
local function am_need(player, fits)
    local am = tonumber(settings.ws.am) or 0
    local am_ws = settings.ws.am_ws ~= '' and settings.ws.am_ws or settings.ws.name
    if am <= 0 or not am_ws or am_ws == '' or not (fits or util.ws_fits)(am_ws) then return nil end
    local have, id = 0, nil
    if util.has_buff(player.buffs, 273) then have, id = 3, 273               -- relic Aftermath
    elseif util.has_buff(player.buffs, 272) then have, id = 3, 272
    elseif util.has_buff(player.buffs, 271) then have, id = 2, 271
    elseif util.has_buff(player.buffs, 270) then have, id = 1, 270 end
    local left = id and bard.buff_left(id)
    if have >= am and left and left < 8 then have = 0 end
    if have < am then return am, am_ws end
    return nil
end

local function do_ws(player)
    -- (AutoSkillchain picked in EasyFarm's Battles works like its Weaponskill list: without the Job tab's weapon skill)
    local chain_farm = settings.modules.farm and wschain.mode_on()
    if not (settings.modules.ws or chain_farm) or player.status ~= 1 or amnesia(player) then return false end
    local t = windower.ffxi.get_mob_by_target('t')
    -- a reactive skillchain follow-up (vg_scfollow) is waiting for its moment on this mob: it owns the TP until it's used
    -- or its window runs out - ahead of the finisher, Aftermath, battle lists, wschain and the normal weapon skill
    -- (sc.steps still wins: a character listed there never follows rules)
    if scfollow.owns_tp(player, t) then return false end
    local fin = finish.ws(player, t)                                  -- the finishing weapon skill comes first
    if fin == 'used' then return true elseif fin == 'block' then return false end
    if not wschain.mp_ok(player) then return false end                -- Weapon skill MP limit (his request 2026-10-30)
    -- (a Weaponskill battle list counts too: with no normal weapon skill set it was never reached)
    if settings.ws.name == '' and #wschain.list() == 0 and not blist.any('ws') then return false end
    if settings.modules.sc then
        for _, s in ipairs(sc_steps()) do
            if s.who == player.name:lower() then return false end   -- chain owns our TP
        end
    end
    -- Aftermath (his request 2026-10-19): keep Lv.1 / 2 / 3 up - without it (or with under 8 s left by the game's timer)
    -- TP is saved to 1000 / 2000 / 3000 and the Aftermath weapon skill used; with it up, the normal weapon skill
    -- (another weapon's Aftermath weapon skill: no saving TP for it, the chain goes on - am_need checks the weapon)
    local am, am_ws = am_need(player, ws_fits)
    if am then
        if player.vitals.tp < am * 1000 or recently('ws:' .. am_ws, 3) or not ws_in_range(t) then return false end
        log(('%s at %d TP for Aftermath Lv.%d'):format(am_ws, player.vitals.tp, am))
        return use_ws(am_ws)
    end
    -- farming with a Weaponskill battle list (EasyFarm): its weapon skills instead
    local ba, br = blist.ws(player, t)
    if ba == 'hold' then return false end
    if ba then
        if recently('ws:' .. br.en, 3) then return false end
        use_ws(br.en)
        blist.ws_used(ba, t)
        return true
    end
    -- a weapon skill chain for this character (AutoSkillchain, vg_wschain): its next weapon skill instead
    local nx = wschain.next(player, t)
    if nx == 'hold' then return false end
    if nx then
        if recently('ws:' .. nx, 3) or (t and t.hpp < settings.ws.min_mob_hpp) then return false end
        use_ws(nx)
        wschain.used()
        return true
    end
    if settings.ws.name == '' then return false end
    if player.vitals.tp < settings.ws.tp or recently('ws:' .. settings.ws.name, 3) then return false end
    if not ws_in_range(t) then return false end
    return use_ws(settings.ws.name)
end

local function burst_map()
    local map = {}
    for _, entry in ipairs(util.split(settings.burst.spells, ',')) do
        local el, list = entry:match('^(.-)%s*:%s*(.+)$')
        if el then map[el:lower()] = util.split(list, '|') end
    end
    return map
end

local function do_burst(player)
    if not settings.modules.burst or not state.burst or silenced(player) then return false end
    if now() > state.burst.expires then state.burst = nil return false end
    local map = burst_map()
    for _, element in ipairs(mages.burst_order(state.burst.elements, battle_target())) do
        for _, name in ipairs(map[element:lower()] or {}) do
            if try_cast(name, '<bt>', 'burst ' .. state.burst.chain, player) then
                state.burst = nil
                return true
            end
        end
    end
    return false
end

------------------------------------------------------------------------
-- Songs, Geomancy, enfeebles, dispel
------------------------------------------------------------------------
-- "In a fight": I'm engaged, the leader is, anyone in the party is, or the party has a claimed mob (<bt>). It used to
-- be only me or the leader - a bard set to "Nobody (I lead)" standing back never saw a fight, so NiTro, Clarion Call
-- and the other "in a fight" abilities never went off (2026-10-18)
local function party_engaged(player)
    if player.status == 1 then return true end
    local l = leader_mob(player)
    if l and l.status == 1 then return true end
    local pt = windower.ffxi.get_party() or {}
    for _, k in ipairs({ 'p1', 'p2', 'p3', 'p4', 'p5' }) do
        local m = pt[k] and pt[k].mob
        if m and m.status == 1 and (m.distance or 0) < 900 then return true end
    end
    return battle_target() ~= nil
end

local function do_songs(player)
    if not settings.modules.songs or settings.songs.list == '' or silenced(player) then return false end
    if settings.songs.when == 'engaged' and not party_engaged(player) then return false end
    return bard.sing(player)
end

local function do_geo(player)
    if not settings.modules.geo or silenced(player) then return false end
    -- Full Circle when the luopan isn't reaching anyone (vg_support.luopan_off); the bubble is put down again below
    local pet = windower.ffxi.get_mob_by_target('pet')
    local why = pet and support.luopan_off(player, pet, battle_target())
    if why then
        local fc = util.ability('Full Circle')
        if util.ability_ready(fc) and not amnesia(player) and not recently('ja:Full Circle:<me>', 15) then
            log('Full Circle (' .. why .. ')')
            return use_ja(fc, '<me>')
        end
    end
    -- Entrust: "Indi-Spell>Member" - kept up like our own Indi, in and out of fights (it was only done in a fight, so
    -- each fight started without it), and only with the member alive within 20' (Entrust used to go off for a member
    -- out of range and the Indi then failed - a 10-minute ability wasted; 2026-10-19 GEO round)
    local entrust = support.entrust_setting(player)
    if entrust ~= '' then
        local spell, who = entrust:match('^(.-)%s*>%s*(.+)$')
        if spell and who then
            if util.has_buff(player.buffs, util.buff_id('Entrust')) then
                if try_cast(spell, who, 'entrust', player) then return true end
            else
                local ent = util.ability('Entrust')
                local target_has, near = false, false
                for _, m in ipairs(party_members(20)) do
                    if m.name:lower() == who:lower() and (m.hpp or 0) > 0 then
                        near = true
                        target_has = util.has_buff(buffs_of(m, player) or {}, 612)
                        -- carrying another Indi than the one picked now: entrust the new one
                        local was = (state.indi_on or {})[m.name:lower()]
                        if target_has and was and was:lower() ~= spell:lower() then target_has = false end
                    end
                end
                if near and not target_has and util.ability_ready(ent) and util.spell_ready(util.spell(spell), player)
                    and not recently('ja:Entrust:<me>', 30) then
                    return use_ja(ent, '<me>')
                end
            end
        end
    end
    -- Indi: keep "Colure Active" on self - and the Indi picked in the app: another one picked replaces the one up
    -- (it used to wait for the old one to wear off, minutes; 2026-10-19 GEO round)
    local indi_on = state.indi_on or {}
    local mine = util.has_buff(player.buffs, 612) and indi_on.me
    -- (geo.indi_engaged: only while the party fights; an Indi already up is left to wear off by itself)
    if settings.geo.indi ~= '' and (not settings.geo.indi_engaged or party_engaged(player))
        and (not util.has_buff(player.buffs, 612) or (mine and mine:lower() ~= settings.geo.indi:lower())) then
        if try_cast(settings.geo.indi, '<me>', mine and ('indi: ' .. mine .. ' -> ' .. settings.geo.indi) or 'indi', player) then return true end
    end
    -- Geo: keep a luopan out.
    if settings.geo.geo ~= '' and not windower.ffxi.get_mob_by_target('pet') then
        local tgt = support.geo_place(player, util.spell(settings.geo.geo))
        if tgt == 'bt' then
            if party_engaged(player) and battle_target() then
                if support.geo_hate(player, util.spell(settings.geo.geo), battle_target()) then return true end
                return try_cast(settings.geo.geo, '<bt>', 'geo', player)
            end
        else
            return try_cast(settings.geo.geo, tgt == 'me' and '<me>' or tgt, 'geo', player)
        end
    end
    return false
end

local function do_debuff(player)
    if not settings.modules.debuff or silenced(player) then return false end
    if settings.enfeebler.on then return false end        -- (Enfeebler mode owns enfeebling: mages.enfeebler)
    local bt = battle_target()
    if not bt or util.dist(bt) > 21 then return false end
    state.debuffs[bt.id] = state.debuffs[bt.id] or {}
    local rec = state.debuffs[bt.id]
    for _, name in ipairs(util.split(settings.debuff.list, ',')) do
        local r = rec[name] or {tries = 0, landed = false}
        rec[name] = r
        if not share.debuff_blocked(r) and r.tries <= settings.debuff.retries then
            if mages.before_enfeeble(player, bt, name, r) then return true end
            if try_cast(name, '<bt>', 'debuff', player) then
                r.tries = r.tries + 1
                share.debuff(bt.id, name, 'cast')
                return true
            end
        end
    end
    return false
end

-- A Blue Mage's dispels (0.99.2; BG Wiki read 2026-11-14): Blank Gaze - one buff off one enemy within 14', a gaze,
-- so the mob must be looking at me; Geist Wall - one buff off the enemies within 6' of ME. Only when set.
local function blu_dispel(player)
    local bt = battle_target()
    if not bt then return false end
    local d = util.dist(bt)
    local me = windower.ffxi.get_mob_by_target('me')
    local on_me = not bt.target_index or bt.target_index == 0 or (me and bt.target_index == me.index)
    if d <= 12 and on_me and try_cast('Blank Gaze', '<bt>', 'mob buffed', player) then return true end
    if d <= 5 and try_cast('Geist Wall', '<bt>', 'mob buffed', player) then return true end
    return false
end
-- Desync recovery (1.2.0, Silmaril audit 2.5; read only, no packets sent). The game window shows us fighting
-- (status 1) but the server's own character update (0x037, read in 'incoming chunk') has said idle for 2 s or more:
-- swings never come. Send /attack <t> once (then not again for 10 s) when the target is alive and in reach.
-- Who owns what: engaging / switching / disengaging stay with combat.tick, assist and the farmer (they pick the
-- target and run first); this never picks a target, only repeats the fight the game already shows. Off by default
-- (assist.resync).
local function desync_check(player)
    if not settings.assist.resync or player.status ~= 1 then state.engaged_since = nil return false end
    state.engaged_since = state.engaged_since or now()
    if state.retreat or state.srv_status ~= 0 or not state.srv_status_at then return false end
    if now() - state.engaged_since < 2 or now() - state.srv_status_at < 2 or recently('resync', 10) then return false end
    local t = windower.ffxi.get_mob_by_target('t')
    if not t or not t.is_npc or (t.hpp or 0) <= 0 or t.valid_target == false then return false end
    if util.dist(t) > settings.assist.melee_range + 3 then return false end
    mark('resync')
    log(('Out of step with the server (it says I am not fighting %s): /attack again'):format(t.name or 'the mob'))
    windower.send_command('input /attack <t>')
    return true
end
local function do_dispel(player)
    if not settings.modules.dispel or now() > state.dispel_until or silenced(player) then return false end
    if try_cast('Dispelga', '<bt>', 'mob buffed', player) or try_cast('Dispel', '<bt>', 'mob buffed', player)
        or blu_dispel(player) then
        state.dispel_until = 0
        return true
    end
    return false
end


------------------------------------------------------------------------
-- Rest, MP management, trusts (CurePlease / EasyFarm style)
------------------------------------------------------------------------
-- Something attacking the party right now (a mob our party has claimed, alive, close by)? Then nobody sits down to rest.
-- (Found by the farming simulator: a mob hitting a low-HP farmer interrupted its rest, and it sat down again, and again.)
-- A mob is fighting us: claimed by the party, or going for one of us (a mob on us after /attackoff - waiting for TP to
-- finish it - still counts: his report 2026-10-17, "if in combat the bot should not try to summon trusts, or if under
-- attack")
local function under_attack(player)
    local ids, idx = {}, {}
    local p = windower.ffxi.get_party() or {}
    for _, k in ipairs({ 'p0', 'p1', 'p2', 'p3', 'p4', 'p5' }) do
        if p[k] and p[k].mob then ids[p[k].mob.id] = true if p[k].mob.index then idx[p[k].mob.index] = true end end
    end
    for _, m in pairs(windower.ffxi.get_mob_array() or {}) do
        if type(m) == 'table' and m.spawn_type == 16 and (m.hpp or 0) > 0 and util.dist(m) <= 20
            and ((m.claim_id and ids[m.claim_id]) or (m.status == 1 and m.target_index and idx[m.target_index])) then
            return true
        end
    end
    return false
end

local function do_rest(player)
    if not settings.modules.rest then return false end
    local v, r = player.vitals, settings.rest
    if player.status == 33 then
        -- Stand up when recovered (MP check only for jobs with MP).
        local mp_ok = (v.max_mp or 0) == 0 or v.mpp >= r.mp_high
        if v.hpp >= r.hp_high and mp_ok then
            windower.send_command('input /heal off')
            state.resting = false
            log('Done resting')
            return true
        end
        return false
    end
    if player.status ~= 0 or party_engaged(player) or state.running or under_attack(player) then return false end
    local low_mp = (v.max_mp or 0) > 0 and v.mpp < r.mp_low
    if (v.hpp < r.hp_low or low_mp) and not recently('rest', 6) then
        mark('rest')
        windower.send_command('input /heal on')
        state.resting = true
        log(('Resting (HP %d%%, MP %d%%)'):format(v.hpp, v.mpp))
        return true
    end
    return false
end

local function do_mana(player)
    if not settings.modules.mana or amnesia(player) then return false end
    local v = player.vitals
    -- Sublimation: start charging, then release when MP is low.
    if settings.mana.sublimation then
        local sub = util.ability('Sublimation')
        if sub and util.ability_ready(sub) and not recently('ja:Sublimation:<me>', 10) then
            local active = util.has_buff(player.buffs, util.buff_id('Sublimation: Activated'))
            local complete = util.has_buff(player.buffs, util.buff_id('Sublimation: Complete'))
            -- mana.sub_skip_refresh (audit 2.7, like CurePlease): no new charge while my own Refresh is up (buff 43 or
            -- 541), unless my MP is already under sublimation_mpp - the charge eats HP for MP Refresh already gives
            local start = not active and not complete
            if start and settings.mana.sub_skip_refresh and v.mpp >= settings.mana.sublimation_mpp
                and (util.has_buff(player.buffs, 43) or util.has_buff(player.buffs, 541)) then
                start = false
            end
            if start or (complete and v.mpp < settings.mana.sublimation_mpp) then
                return use_ja(sub, '<me>')
            end
        end
    end
    -- Devotion (White Mage; CurePlease / Silmaril): MP to a party member who runs low, while my HP is healthy
    local dv = tonumber(settings.mana.devotion_mpp) or 0
    -- (1.3.0, audit 2.3: mana.devotion_to = only that member; mana.devotion_engaged = only while the party fights)
    -- (an empty entry reads back from settings.xml as an empty table, see vg_store: text only, else '' = anyone)
    local dv_raw = settings.mana.devotion_to
    local dv_to = type(dv_raw) == 'string' and util.trim(dv_raw):lower() or ''
    if dv > 0 and player.main_job == 'WHM' and v.hpp >= 70
        and (not settings.mana.devotion_engaged or party_engaged(player)) then
        local ja = util.ability('Devotion')
        if ja and util.ability_ready(ja) and not recently('ja:Devotion', 10) then
            for _, m in ipairs(party_members(10)) do
                if m.name ~= player.name and (dv_to == '' or m.name:lower() == dv_to)
                    and (m.hpp or 0) > 0 and (m.mpp or 100) < dv and (m.mp or 0) + 1 > 0 then
                    mark('ja:Devotion')
                    log(('Devotion: %s at %d%% MP'):format(m.name, m.mpp))
                    return use_ja(ja, m.name)
                end
            end
        end
    end
    -- Convert when MP is very low and HP is healthy.
    -- (not while the job's own "Convert at low MP" action is on: one of the two does it)
    local own_convert = false
    if settings.modules.actions and state.profile then
        for _, a in ipairs(jobs.actions_for(player.main_job)) do
            if a.id == 'convert' and engine.enabled(a, state.profile) then own_convert = true end
        end
    end
    if not own_convert and settings.mana.convert_mpp > 0 and v.mpp < settings.mana.convert_mpp and v.hpp > 80 then
        local conv = util.ability('Convert')
        if conv and util.ability_ready(conv) and not recently('ja:Convert:<me>', 10) then
            log('Convert')
            return use_ja(conv, '<me>')
        end
    end
    return false
end

local function do_trusts(player)
    if not settings.modules.trusts or settings.trusts.list == '' or player.status ~= 0 then return false end
    if party_engaged(player) or silenced(player) or under_attack(player) or state.finish_wait then return false end
    local members = party_members()
    if #members >= settings.trusts.party_size then return false end
    -- only the party leader can call trusts: an alt in someone else's party kept trying (the EasyFarm engine already
    -- knew; found checking the features together, 2026-10-28)
    local pt = windower.ffxi.get_party() or {}
    if pt.party1_leader and pt.party1_leader ~= 0 and pt.party1_leader ~= player.id and #members > 1 then return false end
    local present = {}
    for _, m in ipairs(members) do present[m.name:lower()] = true end
    for _, name in ipairs(util.split(settings.trusts.list, ',')) do
        local short = name:lower():gsub('%s*%(.-%)', ''):gsub('%s+ii$', '')
        if not present[short] and not present[name:lower()] then
            if try_cast(name, '<me>', 'trust', player) then return true end
            -- not sent because he was still moving and is stopping for it: that is this pass's action - farming must
            -- not walk him off again before the trust is called (0.99.2)
            if now() - (state.stand_wait or -9) < 0.1 then return true end
        end
    end
    return false
end

------------------------------------------------------------------------
-- Farming lives in vg_farm.lua (camp / route, give-up list, wait for the party, stop conditions, stats, spots)
------------------------------------------------------------------------
local function record_route()
    if not state.recording then return end
    local me = windower.ffxi.get_mob_by_target('me')
    if not me then return end
    local pts = state.recording_pts
    local last = pts[#pts]
    if not last or math.sqrt((me.x - last.x) ^ 2 + (me.y - last.y) ^ 2) >= 4 then
        pts[#pts + 1] = {x = me.x, y = me.y, z = me.z}
    end
end


------------------------------------------------------------------------
-- Job profiles: automatic per-job setup
------------------------------------------------------------------------
-- Who else already does this action (vg_actions' engine.owner): the Buffs tab keeps the same spell up on the same target
-- (it also has the "recast before it wears off" timers), or one of EasyFarm's lists has it switched on while it farms.
local function action_owner(a)
    -- Afflatus Solace / Misery (1.3.0, audit 2.2): the Job tab's choice (whm.afflatus) wins; the stance not picked is
    -- never used, so the two never replace each other back and forth
    if a.afflatus then
        local pick = util.trim(tostring((settings.whm or {}).afflatus or 'solace')):lower()
        if pick ~= 'misery' then pick = 'solace' end
        if a.afflatus ~= pick then return 'the Afflatus choice' end
    end
    if a.kind ~= 'ma' and a.kind ~= 'ja' then return nil end
    local name = tostring(a.name):lower()
    if settings.modules.buffs and (a.target == '<me>' or a.target == '{leader}') then
        local p = windower.ffxi.get_player()
        local my = p and p.name:lower() or ''
        local want = my
        if a.target == '{leader}' and settings.leader ~= '' then want = settings.leader:lower() end
        for _, entry in ipairs(util.split(settings.buffs.list or '', ',')) do
            local what, who = entry:match('^(.-)%s*>%s*(.+)$')
            what, who = (what or entry):lower(), (who or 'me'):lower()
            if what:sub(1, 3) == 'ja:' then what = util.trim(what:sub(4)) end
            if who == 'me' then who = my end
            if what == name and who == want then return 'the Buffs tab' end
        end
    end
    if easyfarm.active() then
        for _, l in ipairs(blist.LISTS) do
            for _, e in ipairs(blist.get(l)) do
                if tonumber(e.on) == 1 and tostring(e.n):lower() == name then return ("EasyFarm's %s list"):format(l) end
            end
        end
    end
    return nil
end
engine.owner = action_owner

local function make_ctx(player)
    return {
        player = player, settings = settings, state = state,
        cast = cast, use_ja = use_ja, log = log, recently = recently, mark = mark,
        silenced = silenced, amnesia = amnesia, party_members = party_members,
        buffs_of = buffs_of, party_engaged = party_engaged, battle_target = battle_target,
        pld_in_party = function(p) return mages.pld_in_party(p) end,
        roll_in_range = support.roll_in_range, roll_approach = support.roll_approach,
        crooked = function(roll, p)
            local want = settings.cor.crooked or ''
            if want == '' or want:lower() ~= roll:lower() then return false end
            if util.has_buff(p.buffs, 601) or recently('ja:Crooked Cards', 10) then return false end   -- (on already)
            local cc = util.ability('Crooked Cards')
            if not cc or not util.ability_ready(cc) then return false end
            mark('ja:Crooked Cards')
            log('Crooked Cards before ' .. roll)
            return use_ja(cc, '<me>')
        end,
    }
end

local function encode_profile(pr)
    local on, off = {}, {}
    for id, v in pairs(pr.toggles) do
        if v then on[#on + 1] = id else off[#off + 1] = id end
    end
    -- '+' separates ids (commas would be split by Windower's config library).
    return ('role=%s|ws=%s|on=%s|off=%s|o=%s|q=%s'):format(pr.role, pr.ws or '', table.concat(on, '+'), table.concat(off, '+'),
        link.encode_opts(pr.opts), table.concat(pr.order or {}, '+'))
end

local function decode_profile(job, str)
    local pr = { job = job, toggles = {} }
    for k, v in str:gmatch('(%w+)=([^|]*)') do
        if k == 'role' then pr.role = v
        elseif k == 'ws' then pr.ws = v
        elseif k == 'on' then for _, id in ipairs(util.split(v, '+')) do pr.toggles[id] = true end
        elseif k == 'off' then for _, id in ipairs(util.split(v, '+')) do pr.toggles[id] = false end
        elseif k == 'o' then pr.opts = link.decode_opts(v)
        elseif k == 'q' then pr.order = util.split(v, '+')    -- ability priority order
        end
    end
    return pr
end

local function known_ws()
    local list = {}
    local ab = windower.ffxi.get_abilities()
    for _, id in pairs(ab and ab.weapon_skills or {}) do
        local ws = res.weapon_skills[id]
        if ws then list[#list + 1] = ws.en end
    end
    table.sort(list)
    return list
end

local function default_ws(job)
    local known = {}
    for _, n in ipairs(known_ws()) do known[n:lower()] = n end
    for _, n in ipairs((jobs[job] and jobs[job].ws) or {}) do
        if known[n:lower()] then return known[n:lower()] end
    end
    return ''
end

-- Turn the role into module settings.
local function apply_profile(pr)
    local job = pr.job
    local def = jobs[job] or {}
    local mods = jobs.role_modules[pr.role] or jobs.role_modules.melee
    for k in pairs(settings.modules) do settings.modules[k] = mods[k] == true end
    settings.assist.approach = not jobs.ranged_roles[pr.role]
    if settings.assist.approach_mode == 'on' then settings.assist.approach = true
    elseif settings.assist.approach_mode == 'off' then settings.assist.approach = false end
    if def.songs then
        settings.modules.songs = true
        settings.songs.list = def.songs[pr.role] or def.songs.support or ''
    end
    if def.geo then
        local g = def.geo[pr.role] or def.geo.support
        settings.modules.geo = true
        settings.geo.indi, settings.geo.geo, settings.geo.geo_target = g.indi, g.geo, g.geo_target
    end
    if def.debuffs and def.debuffs[pr.role] then
        settings.debuff.list = def.debuffs[pr.role]
        settings.modules.debuff = true
    end
    settings.ws.name = pr.ws or ''
    settings.modules.ws = settings.modules.ws and settings.ws.name ~= ''
    state.profile = pr
end

local function save_profile()
    if not state.profile then return end
    util.job_set(settings.profiles, state.profile.job, encode_profile(state.profile))
    util.job_set(settings.menus, state.profile.job, menu.encode(settings))
    store.save(settings)
end

local function send_profile(player)
    player = player or windower.ffxi.get_player()
    local pr = state.profile
    if not player or not pr then return end
    local roles = {}
    for _, r in ipairs(jobs.roles_for(player.main_job)) do
        roles[#roles + 1] = { id = r, label = jobs.role_labels[r] or r }
    end
    bridge.send({
        type = 'profile', name = player.name,
        job = player.main_job, sub = player.sub_job or '',
        role = pr.role, roles = roles,
        ws = settings.ws.name, ws_list = known_ws(),
        actions = engine.list(pr, player),
        leader = settings.leader,
        menu = menu.catalog(player, status_cures),
        config = (function()
            local c = menu.config(settings)
            c.strat_info = strat.info(player)
            if player.main_job == 'BRD' then c.bard_info = bard.info(player) end
            c.blists = blist.all()
            c.bufftime = bufftime.info()
            c.priority = {}
            for _, k in ipairs(priority_order(player.main_job)) do c.priority[#c.priority + 1] = { k = k, l = PRIORITY_LABEL[k] } end
            c.wschain = { presets = wschain.presets(player), weapon = wschain.weapon_type(), step = wschain.step(),
                          list = wschain.list(), rep = wschain.rep() }
            if player.main_job == 'GEO' then c.geo_info = support.geo_info(player) end
            c.known = quick.known(player)                -- for the app's quick buttons
            c.hotkeys = settings.hotkeys
            return c
        end)(),
        party = menu.party(),
    })
    state.profile_sent = now()
end

-- //vg rolls: switch the Corsair's roll actions to this set.
local function apply_rolls(set)
    if not state.profile then return end
    local on, names = {}, {}
    for _, id in ipairs(set) do on[id] = true end
    for _, a in ipairs(jobs.COR.actions) do
        if a.kind == 'roll' then
            state.profile.toggles[a.id] = on[a.id] == true
            if on[a.id] then names[#names + 1] = a.name end
        end
    end
    save_profile()
    send_profile()
    log('Rolls: ' .. table.concat(names, ' + '))
end

local function load_profile(player, force_default)
    player = player or windower.ffxi.get_player()
    if not player or not player.main_job then return end
    local job = player.main_job
    local saved = util.job_get(settings.profiles, job)
    local pr
    if saved and saved ~= '' and not force_default then
        pr = decode_profile(job, saved)
    end
    if not pr or not pr.role then
        pr = { job = job, role = jobs.roles_for(job)[1], ws = default_ws(job), toggles = {} }
    end
    if not pr.ws or pr.ws == '' then pr.ws = default_ws(job) end
    menu.reset_cache()
    apply_profile(pr)
    local saved_menu = util.job_get(settings.menus, job)
    if saved_menu and saved_menu ~= '' and not force_default then
        menu.apply(settings, saved_menu)
    else
        settings.buffs.list = ''
    end
    log(('%s %s ready (%s%s)'):format(job, player.sub_job and ('/' .. player.sub_job) or '',
        jobs.role_labels[pr.role] or pr.role, pr.ws ~= '' and (', WS ' .. pr.ws) or ''))
    send_profile(player)
end

local function pre_ws_filter(a) return a.tp_min ~= nil end
local function normal_filter(a) return a.tp_min == nil end

------------------------------------------------------------------------
-- Main tick
------------------------------------------------------------------------
party.init(settings, state, {
    log = log, recently = recently, mark = mark, run_toward = run_toward, stop_running = stop_running,
    party_engaged = party_engaged, leader_mob = leader_mob, face = face,
})
hud.init(settings, state, { log = log })
combat.init(settings, state, { log = log, recently = recently, mark = mark, leader_mob = leader_mob, leader_target = leader_target,
    face = face, try_cast = try_cast, farm_has_pull = function() return farm.has_pull() end })
share.init(settings, state, { log = log })
safety.init(settings, state, { log = log, recently = recently, mark = mark, stop_running = stop_running })
team.init(settings, state, {
    log = log, store = store.save, save_profile = save_profile, order = party.order,
    load_profile = function(p) load_profile(p) end,
})
travel.init(settings, state, {
    log = log, recently = recently, mark = mark, try_cast = try_cast, party_engaged = party_engaged,
    ability = util.ability, ability_ready = util.ability_ready,
})
update.init(settings, log, function() store.save(settings) end)
cure.init(settings, state, {})
charm.init(settings, state, { log = log, recently = recently, mark = mark, cast = cast, silenced = silenced, use_ja = use_ja })
sortie.init(settings, state, { log = log, recently = recently, mark = mark, silenced = silenced, battle_target = battle_target })
local function ja_ready(name)
    local ja = util.ability(name)
    if not ja or not util.ability_ready(ja) then return nil end
    local ab = windower.ffxi.get_abilities()
    for _, id in pairs(ab and ab.job_abilities or {}) do if id == ja.id then return ja end end
    return nil
end
quick.init(settings, state, { log = log })
warp.init(settings, state, { log = log })
stats.kill_hook = function(mob) farm.on_kill(mob) trials.on_kill(mob) blist.on_kill(mob) end
trials.init(settings, state, { log = log, save = function() store.save(settings) send_profile() end })
stats.chain_hook = function(n) farm.on_points(n) end
farm.init(settings, state, { log = log, run_toward = run_toward, stop_running = stop_running, face = face,
    party_engaged = party_engaged, recently = recently, mark = mark, save = function() save_profile() store.save(settings) send_profile() end,
    send = bridge.send })
finish.init(settings, state, { log = log, use_ws = use_ws, ws_in_range = ws_in_range, recently = recently, mark = mark,
    save = function() store.save(settings) end })
wschain.init(settings, state, { log = log, recently = recently, mark = mark })
scfollow.init(settings, state, { log = log, recently = recently, mark = mark, use_ws = use_ws, amnesia = amnesia,
    save = function() store.save(settings) end, am_need = am_need,
    -- sc.steps owns the TP of every character listed in it (while the sc module is on): no rules for them
    in_sc_steps = function(player)
        if not settings.modules.sc then return false end
        local me = player.name:lower()
        for _, s in ipairs(sc_steps()) do if s.who == me then return true end end
        return false
    end })
bufftime.init(settings, state, { save = function() store.save(settings) end })
easyfarm.init(settings, state, { stop_running = function() return stop_running() end,
    run_toward = function(...) return run_toward(...) end, face = function(...) return face(...) end,
    recently = function(...) return recently(...) end, mark = function(...) return mark(...) end, log = function(...) return log(...) end,
    try_cast = function(...) return try_cast(...) end, use_ws = function(...) return use_ws(...) end,
    do_ws = function(player)                                         -- (vg_finish: no /attackoff holds under EasyFarm)
        local was = state.ef_gap
        state.ef_gap = true
        local done = do_ws(player)
        state.ef_gap = was
        return done
    end,
    status = function(s) return farm.status(s) end })
blist.init(settings, state, { try_cast = function(...) return try_cast(...) end, use_ja = function(...) return use_ja(...) end,
    use_ws = function(...) return use_ws(...) end, amnesia = function(...) return amnesia(...) end,
    recently = function(...) return recently(...) end, mark = function(...) return mark(...) end, log = function(...) return log(...) end })
jobs.custom_provider = function(job)
    local out = {}
    for _, e in ipairs(util.split(tostring(util.job_get(settings.customs, job) or ''), '+')) do
        local a = jobs.custom(e)
        if a then out[#out + 1] = a end
    end
    return out
end
bard.init(settings, state, {
    log = log, recently = recently, mark = mark, try_cast = try_cast, use_ja = use_ja, amnesia = amnesia,
    party_members = party_members, ja_ready = ja_ready,
    nitro = function(p, due) return support.nitro(p, due) end,
    nitro_wait = function(p) return support.nitro_wait(p) end,
    save = function() store.save(settings) end,
    -- Clarion Call for the songs: only if ticked in the abilities, its "when" holds and it's ready; true = used now
    clarion_ok = function(p)
        -- (not twice in a row: the buff shows a moment after - his log had Clarion Call sent twice 2 s apart)
        if not state.profile or util.has_buff(p.buffs, 499) or amnesia(p) or recently('ja:Clarion Call:<me>', 10) then return false end
        for _, a in ipairs(jobs.actions_for(p.main_job)) do
            if a.id == 'clarion_call' and engine.enabled(a, state.profile) then
                local w = engine.effective(a, state.profile).when
                if w ~= 'always' and not party_engaged(p) then return false end
                local ja = ja_ready('Clarion Call', p)
                return ja and use_ja(ja, '<me>') or false
            end
        end
        return false
    end,
})
strat.init(settings, state, {
    log = log, recently = recently, use_ja = use_ja, cast = cast, party_members = party_members,
    buffs_of = buffs_of, amnesia = amnesia,
})
link.init(settings, state, {
    log = log, store = store.save, save_profile = save_profile, load_profile = function(p) load_profile(p) end,
})
bridge.on_cfg = function(json)
    local player = windower.ffxi.get_player()
    if player then link.on_cfg(player, json) end
end
support.init(settings, state, {
    log = log, recently = recently, mark = mark, cast = cast, use_ja = use_ja, try_cast = try_cast, silenced = silenced,
    amnesia = amnesia, party_members = party_members, buffs_of = buffs_of, battle_target = battle_target,
    party_engaged = party_engaged, leader_mob = leader_mob, run_toward = run_toward, stop_running = stop_running,
    casting = casting, face = face,
})
mages.init(settings, state, {
    log = log, recently = recently, mark = mark, cast = cast, use_ja = use_ja, silenced = silenced,
    amnesia = amnesia, party_members = party_members, buffs_of = buffs_of, battle_target = battle_target,
    party_engaged = party_engaged, leader_mob = leader_mob,
})
planner.init(settings, state, { party_members = party_members, casting = casting, send = bridge.send, silenced = silenced,
    enf_candidates = function(p) return mages.enfeebler_candidates(p) end })
alts.init(settings, state, {
    log = log, bridge_log = function(m) bridge.log(m) end, recently = recently, mark = mark,
    try_cast = try_cast, party_engaged = party_engaged,
})

local function tick()
    local player = windower.ffxi.get_player()
    if not player then state.tick_player = nil return end
    state.tick_player = player
    -- am I moving? (my own position, pass to pass: also when he walks the character himself)
    do
        local me = windower.ffxi.get_mob_by_target('me')
        if me and me.x then
            local lp = state.last_pos
            if lp and (math.abs(me.x - lp.x) > 0.05 or math.abs(me.y - lp.y) > 0.05) then state.moved_at = now() end
            state.last_pos = { x = me.x, y = me.y }
        end
    end
    record_route()
    -- reloaded while running: carry on (farming too: a new run from the same camp), and forget the marker
    if resuming then
        resuming = false
        settings.resume_until = 0
        if settings.modules.farm and settings.enabled then
            farm.start(player, windower.ffxi.get_mob_by_target('me'))
            log('Reloaded: farming carries on')
        end
        store.save(settings)
    end
    -- a rest that ended without us (hit by a mob, moved): stop thinking we're resting
    if state.resting and player.status ~= 33 and not recently('rest', 3) and not recently('farm:rest', 3) then state.resting = false end
    stats.tick(player)
    sortie.tick(player)
    -- what the cures were seen to heal (vg_cure): written to the settings file at most once a minute
    if state.cure_learn_dirty and not recently('cure_learn_save', 60) then
        mark('cure_learn_save')
        state.cure_learn_dirty = nil
        store.save(settings)
    end
    if farm.rezone_due() then windower.send_command('vg farming start') end
    farm.loot_tick()
    farm.kill_watch()
    farm.fight_tick(player)
    farm.check_stop(player)
    warp.tick(player)
    alts.broadcast_mount(player)
    party.hello(player)
    party.send_pos(player)
    hud.send(player)
    hud.draw()
    hud.draw_tp()
    travel.broadcast(player)
    if not settings.enabled then return end
    -- the Job tab's "Walk up to the mob" (assist.approach_mode): always / never, or back to what the role says
    do
        local am = settings.assist.approach_mode
        if am == 'on' then settings.assist.approach = true
        elseif am == 'off' then settings.assist.approach = false
        elseif state.approach_mode_was and state.approach_mode_was ~= am and state.profile then
            settings.assist.approach = not jobs.ranged_roles[state.profile.role]
        end
        state.approach_mode_was = am
    end
    alts.alerts(player)
    if safety.away(player) then return end
    -- farming with EasyFarm's engine (vg_easyfarm): it drives the farming - targets, moving, pulling, its lists,
    -- resting, trusts. When it has nothing to do this pass, the character's own job features (songs, cures, buffs,
    -- abilities, Geo, rolls...) get their turn, minus anything that would move it or fight EasyFarm (his request
    -- 2026-10-28: features checked "when they are being used in conjunction with each other" - a bard or healer
    -- that farmed with the EasyFarm engine stopped singing / curing altogether). farm.ef_jobs false: EasyFarm alone.
    local ef_gap = false
    if easyfarm.active() then
        if not state.ef_started then state.ef_started = true easyfarm.start() end
        -- raising, curing and removing ailments come before EasyFarm's actions: a dying party member can't wait for
        -- a gap in its Battle list
        if settings.farm.ef_jobs ~= false and (player.status == 0 or player.status == 1) and can_act(player)
            and (do_urgent_items(player) or charm.tick(player) or do_raise(player) or do_heal(player) or do_status(player) or do_items(player)) then return end
        if easyfarm.tick(player) or settings.farm.ef_jobs == false then return end
        ef_gap = true
        state.ef_gap = true                                          -- (vg_finish: no /attackoff holds then)
    else
        state.ef_gap = nil
        state.ef_started = nil
    end

    if player.status == 33 then
        if ef_gap then return end                                   -- (EasyFarm's Rest decides when to get up)
        if farm.rest_check(player) then return end                 -- resting at camp: up when a mob shows up
        if farm.rest_called_check(player) then return end          -- the farmer asked me to rest: up when full
        if not travel.rest_stand(player) then do_rest(player) end
        return
    end
    if player.status ~= 0 and player.status ~= 1 then stop_running() return end
    if not ef_gap then                                              -- (EasyFarm moves this character)
        run_movement(player)
        support.roll_walk_tick(player)
    end
    safety.watch(player)
    safety.auto_defense(player)
    if player.main_job == 'SCH' or player.sub_job == 'SCH' then
        state.strat_now = ('%d/%d'):format(strat.charges(player), strat.max_charges(player))
    end
    if not can_act(player) then return end
    if strat.run_queue() then return end                             -- the spell that waited for its stratagem
    if alts.mount_sync(player) then return end
    -- Retreat: stop fighting first (the movement step then brings us back).
    if state.retreat and player.status == 1 and not recently('attackoff', 3) then
        mark('attackoff')
        windower.send_command('input /attackoff')
        return
    end
    if not ef_gap and travel.tick(player) then return end
    if not ef_gap and combat.tick(player) then return end           -- (assist / self-defense: EasyFarm targets)
    if desync_check(player) then return end                          -- (only re-sends a fight we're already in)
    if not ef_gap and combat.on_engage(player) then return end      -- (once per new mob; a farm pull wins)

    if settings.modules.triggers and triggers.run(settings, player, state) then
        state.busy_until = now() + 1.5
        return
    end

    if not state.profile then load_profile(player) end
    local ctx = make_ctx(player)
    local pr = state.profile

    if state.farm_bringing and not ef_gap then return end           -- running a mob back to camp: nothing else now
    if ef_gap then
        -- (EasyFarm's engine says what it's doing itself)
    elseif settings.modules.farm and player.status == 1 then   -- (abilities run first in a fight, so say it here)
        local t = windower.ffxi.get_mob_by_target('t')
        farm.status('fighting ' .. (t and t.name or 'a mob'))
    elseif settings.modules.farm then
        farm.status('getting ready first (cures, buffs, abilities)')   -- farm.tick says more once it gets its turn
    end
    -- A mob being finished with a set weapon skill (vg_finish): the others leave it alone, the finisher waits for TP.
    -- Only curing, buffing and songs then.
    if not ef_gap and (finish.held(player) or finish.waiting(player)) then
        local _ = do_raise(player) or do_heal(player) or do_status(player) or do_geo(player) or do_songs(player)
            or do_buffs(player)
        return
    end
    -- a bard's songs come right after raise / cures / status removal (Singer's order): behind steps, Elegy and the rest
    -- the Troubadour minute ran out before the songs were done (2026-10-18)
    local function bard_first() return player.main_job == 'BRD' and (do_songs(player) or support.pianissimo(player)) end
    -- (with EasyFarm's engine in charge, ef_gap: no assist / pull / rest / farming of our own; the weapon skill and
    -- trusts only when its Weaponskill / Trusts lists are empty)
    local function vg_only(f) return function(...) if ef_gap then return false end return f(...) end end
    local function unless_list(list, f)
        return function(...)
            if ef_gap and blist.any(list) then return false end
            -- (AutoSkillchain picked in Battles: EasyFarm's Weaponskill state sends it, not twice)
            if ef_gap and list == 'ws' and wschain.in_charge(windower.ffxi.get_mob_by_target('t')) then return false end
            return f(...)
        end
    end
    local do_assist, do_rest, do_ws, do_trusts = vg_only(do_assist), vg_only(do_rest), unless_list('ws', do_ws), unless_list('trusts', do_trusts)
    local farm_pull, farm_tick, blist_tick = vg_only(farm.pull), vg_only(farm.tick), vg_only(blist.tick)
    -- the twelve groups, in the order picked for this job (the Job tab's Priority box)
    local groups = {
        raise = function() return do_raise(player) end,
        cures = function() return do_heal(player) end,
        ailments = function() return do_status(player) or do_items(player) end,
        songs = function() return bard_first() or do_songs(player) or support.pianissimo(player) end,
        -- (support.hate_spell first: once per new mob, the healer's hate spell; 1.3.0 audit 2.8)
        fighting = function() return support.hate_spell(player) or blist_tick(player) or strat.arts(player) or mages.crowd(player) or do_assist(player) or farm_pull(player) end,
        abilities = function() return support.double_up(ctx, engine) or support.quick_draw(player, pr) or mages.bar(player) or engine.run(ctx, pr, pre_ws_filter) end,
        -- weapon skill owners in order: sc.steps (do_skillchain), then a reactive follow-up (vg_scfollow), then do_ws
        ws = function() return do_skillchain(player) or scfollow.tick(player) or do_ws(player) end,
        bursts = function() return sortie.proc(player) or do_burst(player) or mages.finisher(player) or mages.storm(player) or mages.sch(player) end,
        -- (do_temp_mp after do_mana: the free MP - Sublimation: Complete, Convert, Devotion - before a scarce item)
        abilities2 = function() return engine.run(ctx, pr, normal_filter) or do_mana(player) or do_temp_mp(player) end,
        -- enfeebling owners: the enfeebler (mages.enfeebler, when enfeebler.on) else do_debuff - never both
        enfeebles = function() return do_dispel(player) or mages.enfeebler(player) or do_debuff(player) end,
        geo = function() return support.radial(player) or do_geo(player) end,
        buffs = function() return do_buffs(player) end,
    }
    if do_urgent_items(player) then return end                     -- my own Doom / Silence: before everything
    if charm.tick(player) then return end                           -- a charmed party member: asleep before he hurts anyone
    for _, k in ipairs(priority_order(player.main_job)) do
        if groups[k]() then return end
    end
    local _ = alts.upkeep(player) or do_rest(player) or do_trusts(player) or farm_tick(player)
end

local guarded_move = crash.guard('movement', move_step)
windower.register_event('prerender', function()
    local t = now()
    if state.hover then support.hover_tick() end     -- (Hover Shot step: stopped on time, not up to a tick late)
    -- an extra pass asked for by an event (wake, 1.3): due, and at least wake.gap after the last pass
    local woken = settings.wake.on and state.wake and t >= state.wake and t - state.last_tick >= (tonumber(settings.wake.gap) or 0.05)
    if t - state.last_tick < settings.tick and not woken then
        -- between decision passes: movement / steering only, every follow.move_tick (0.1 s)
        local mt = move_interval()
        if mt and t - (state.last_move or 0) >= mt - 0.005 then   -- (a frame's rounding: not a whole frame late)
            state.last_move = t
            guarded_move()
            in_move, fast_pass = false, false              -- (even if that pass failed half-way)
        end
        return
    end
    state.last_tick = t
    state.last_move = t
    state.move_ran = false
    if state.wake and t >= state.wake then state.wake = nil end        -- (this pass answers it)
    crash.guard('main loop', tick)()
    -- the fast movement passes may carry on what this pass's movement step did (see move_step)
    in_move, fast_pass = false, false
    state.fast_move_ok = state.move_ran and ((state.running and state.run_by == 'move') or (not state.running and not state.move_wanted))
    if state.profile and t - state.profile_sent > 15 then crash.guard('sending the setup to the app', send_profile)() end
    -- talking to the app: a problem here is reported once a minute (crash report), not every second in chat
    crash.guard('talking to Vanguard Control', bridge.poll)(settings, state)
end)

------------------------------------------------------------------------
-- Events: party buffs, actions, chat, zoning
------------------------------------------------------------------------
windower.register_event('incoming chunk', function(id, data)
    -- 0x02D "kill message": "<player> defeats <mob>", "<player> gains N experience / capacity points" (with the chain
    -- number). These never come through the 'action message' event, so kills / XP / CP / chains read 0 in his real game
    -- ("farming run saved (0 kills in 24 min)"). Reading what the game sent us - nothing is sent.
    if id == 0x02D then
        local actor, target = data:unpack('I', 0x04 + 1), data:unpack('I', 0x08 + 1)
        local p1, p2 = data:unpack('I', 0x10 + 1), data:unpack('I', 0x14 + 1)
        local msg = data:unpack('H', 0x18 + 1)
        stats.on_message(actor, target, msg, p1, p2)
        return
    end
    -- 0x037 "character update": our status as the SERVER sees it (byte 0x30, addons/libs/packets/fields.lua), for
    -- the desync check (desync_check). Read only - nothing is sent.
    if id == 0x037 then
        local p = windower.ffxi.get_player()
        if p and data:unpack('I', 0x24 + 1) == p.id then
            local st = data:byte(0x30 + 1)
            if st ~= state.srv_status then state.srv_status, state.srv_status_at = st, now() end
        end
        return
    end
    if id == 0x063 then bard.on_buff_packet(data) return end   -- our buffs with their end times (songs already up)
    if id == 0x0DC then                               -- party invite: inviter's name at 0x0C
        local player = windower.ffxi.get_player()
        local from = data:sub(0x0C + 1, 0x0C + 16):gsub('%z.*$', '')
        if player then party.on_invite(player, from) end
        return
    end
    -- 0x0DD party member update (HP% at 0x1D) / 0x0DF character update (HP% at 0x16), addons/libs/packets/fields.lua:
    -- a member's HP fell under the cure line -> an extra decision pass right away (1.3). Read only, nothing is sent,
    -- and the pass runs in prerender, not here.
    if id == 0x0DD or id == 0x0DF then
        local pid = data:unpack('I', 0x04 + 1)
        local hpp = data:byte((id == 0x0DD and 0x1D or 0x16) + 1)
        if pid and hpp then
            state.hp_seen = state.hp_seen or {}
            local before = state.hp_seen[pid]
            state.hp_seen[pid] = hpp
            if settings.heal.predict then cure.observe(pid, hpp, now()) end   -- (3.2: HP history, read only)
            if settings.enabled and settings.modules.heal and before and hpp > 0 and hpp < before then
                local line = tonumber(settings.heal.cure_at) or 75
                if settings.heal.priority ~= '' then line = math.max(line, tonumber(settings.heal.priority_at) or 0) end
                if before >= line and hpp < line then wake(now()) end
            end
        end
        return
    end
    if id ~= 0x076 then return end
    for k = 0, 4 do
        local pid = data:unpack('I', k * 48 + 5)
        if pid and pid ~= 0 then
            local list = {}
            for i = 1, 32 do
                local low = data:byte(k * 48 + 5 + 16 + i - 1)
                local high = math.floor(data:byte(k * 48 + 5 + 8 + math.floor((i - 1) / 4)) / 4 ^ ((i - 1) % 4)) % 4
                local buff = low + 256 * high
                if buff ~= 255 then list[#list + 1] = buff end
            end
            state.party_buffs[pid] = list
        end
    end
end)

-- The game answered the job ability Vanguard sent last (use_ja): our category 6 action for it arrived, or a refusal
-- message. One owner of the busy lock after a JA: this shortens it to ja.settle (it never lengthens it, and leaves a
-- longer lock set by something else alone); with no answer the 1.5 s from use_ja stands. The queued follow-up
-- (strat.run_queue - the spell waiting for its stratagem -, Divine Seal's Curaga, Accession's Cure...) then goes on the
-- woken pass.
local JA_REFUSED = { [71] = true, [87] = true, [88] = true, [94] = true, [155] = true, [428] = true, [661] = true,
                     [665] = true, [78] = true, [198] = true, [328] = true }
local function ja_answered(id)
    local lj = state.last_ja
    if not lj then return false end
    if now() - lj.at > 3 or (id and id ~= lj.id) then
        if now() - lj.at > 3 then state.last_ja = nil end
        return false
    end
    state.last_ja = nil
    local settle = tonumber(settings.ja.settle) or 1.5
    if settle < 0 then settle = 0 end
    local t = now() + settle
    if t < state.busy_until and state.busy_until <= now() + 1.5 + 0.001 then state.busy_until = t end
    wake(state.busy_until)
    return true
end

local landed_msgs = S{2, 236, 237, 252, 264, 268, 271}
local resist_msgs = S{85, 284, 653, 654, 655, 656}
local buffed_msgs = S{230, 266, 280, 319}
local mob_buff_msgs = { [186] = true, [194] = true }      -- a TP move: "<mob> uses X. <mob> gains the effect of Y"
local no_effect_msgs = { [75] = true, [156] = true, [189] = true, [283] = true, [323] = true }
local song_gone_msgs = { [64] = true, [204] = true, [206] = true, [350] = true, [531] = true }
local ko_msgs = { [6] = true, [20] = true, [97] = true, [113] = true, [406] = true, [605] = true, [646] = true }

-- Our spell was refused because we can't see the member (3.1, see unseen): mark them for UNSEEN_SECS, release the
-- cast's wait (the spell never started) so the next member is tried on the next pass, and say so once per 10 s (chat,
-- the app's log; the app's party board shows it from the snapshot, vg_bridge.unseen). Party members, alliance,
-- watch-list players and trusts only.
-- Our spell was refused before it began ("You must wait longer", "Unable to cast spells at this time", out of range,
-- "X cannot cast Y"...): the cast() wait (cast time + cast.tail) was for a spell that never started. Give it back
-- (1 s) and forget that it was just sent, so the next pass tries again - a spell sent right after a job ability (ja.settle 0.3 s) that the game still
-- refused used to lock the healer for ~5.5 s. Once per 4 s only, so a refusal that keeps coming (silence, amnesia
-- the game knows about and we don't) keeps the full wait after the first retry. Owner: this only shortens the lock
-- cast() set; ja_answered owns the lock after a job ability (cast() clears last_ja, so a message goes to one of them).
local MA_REFUSED = { [17] = true, [18] = true, [47] = true, [48] = true, [49] = true, [94] = true, [313] = true }
local function ma_refused(me)
    local lm = state.last_ma
    if not lm or now() - lm.at > 3 then return end
    state.last_ma = nil
    if recently('ma_refused', 4) then return end
    mark('ma_refused')
    state.attempts[lm.key] = nil           -- (the "just sent it" mark would hold the same spell back 3-6 s more)
    state.casting_until = 0
    if state.busy_until > now() + 1 then state.busy_until = now() + 1 end
    wake(state.busy_until)
end

local function cant_see(target_id, me)
    local mb = target_id ~= me.id and windower.ffxi.get_mob_by_id(target_id)
    if not mb or not mb.name or (mb.is_npc and mb.spawn_type ~= 14) then return end
    local key = mb.name:lower()
    state.unseen[key] = { name = mb.name, untl = now() + UNSEEN_SECS }
    -- the other healers: my "I'm curing him" claim (or my Curaga's) is taken back, and the planner's split doesn't
    -- leave him to me while I can't see him (share.release / share.unseen, plan.cure_elsewhere)
    share.release(me, mb.name)
    share.unseen(me, mb.name, UNSEEN_SECS)
    state.casting_until = 0
    if state.busy_until > now() + 0.5 then state.busy_until = now() + 0.5 end
    wake(state.busy_until)
    if not recently('unseen:' .. key, 10) then
        mark('unseen:' .. key)
        log(("can't see %s (a wall or a ledge?): the others first for %d s"):format(mb.name, UNSEEN_SECS))
    end
end

windower.register_event('action message', function(actor_id, target_id, actor_index, target_index, message_id, p1, p2)
    stats.on_message(actor_id, target_id, message_id, p1, p2)
    local me = windower.ffxi.get_player()
    -- "Unable to use job ability" / "You must wait longer" / too far...: the ability we just sent isn't coming (1.2)
    if me and actor_id == me.id and JA_REFUSED[message_id] then ja_answered(nil) end
    if me and actor_id == me.id and MA_REFUSED[message_id] then ma_refused(me) end
    if me and actor_id == me.id and CANT_SEE_MSGS[message_id] then cant_see(target_id, me) end
    -- one of our songs wore off us / was dispelled (vg_bard keeps its song slots like Singer)
    if me and target_id == me.id and song_gone_msgs[message_id] then bard.on_lost(p1) end
    -- a debuff of ours wore off a mob (Elegy, Dia, Slow...): cast it again. Once landed it used to count as done for
    -- that mob for good, so on a long fight it was never put back (2026-10-19 BARD round)
    local rec = song_gone_msgs[message_id] and state.debuffs[target_id]
    if rec then
        for name, r in pairs(rec) do
            local sp = util.spell(name)
            if sp and sp.status == p1 and r.landed then
                r.landed, r.tries, r.resisted = false, 0, nil
                local mob = windower.ffxi.get_mob_by_id(target_id)
                log(('%s wore off %s - casting it again'):format(sp.en, mob and mob.name or 'the mob'))
            end
        end
    end
    if me and target_id ~= me.id and (song_gone_msgs[message_id] or ko_msgs[message_id]) then
        local mb = windower.ffxi.get_mob_by_id(target_id)
        if mb and (not mb.is_npc or mb.spawn_type == 14) then
            if ko_msgs[message_id] then bard.on_member_ko(mb.name) else bard.on_member_lost(mb.name, p1) end
        end
    end
    local paused = me and engine.on_message(actor_id, message_id, me.id)
    if paused then log(paused) end
    farm.on_message(actor_id, target_id, message_id)
end)

-- After-cast gap (1.4, measuring): our next action after a finished cast was accepted by the game - how long after?
local function note_next_action(what)
    local cd = state.cast_done
    if not cd then return end
    state.cast_done = nil
    local gap = now() - cd.at
    if gap > 10 then return end                                  -- (not back to back: nothing to learn)
    stats.note_gap(gap)
    if settings.cast.log_gap then bridge.log(('gap %.2fs %s>%s'):format(gap, cd.en, what and what.en or '?')) end
end

windower.register_event('action', function(act)
    local player = windower.ffxi.get_player()
    if not player then return end
    local first = act.targets and act.targets[1]
    local first_action = first and first.actions and first.actions[1]
    mages.on_action(act, player, res)
    -- Sortie: Degei / Aita's TP moves, and a proc element landing on them (anyone's spell)
    if act.category == 11 then
        local am, ab = windower.ffxi.get_mob_by_id(act.actor_id), res.monster_abilities[act.param]
        if am and ab then sortie.on_move(am.name, ab.en) end
    elseif act.category == 4 and first then
        sortie.on_hit(first.id, res.spells[act.param])
    end
    support.note_hate(act, player)
    -- COR Quick Draw after a party enfeeble lands (2.1) and the Ranger's Hover Shot step (2.2), both in vg_support
    support.qd_on_action(act, player, act.category == 4 and res.spells[act.param] or nil, landed_msgs)
    support.hover_on_action(act, player, act.category == 3 and res.weapon_skills[act.param] or nil)

    -- Our own action results: release the busy lock, record songs / debuffs.
    if act.actor_id == player.id and act.category == 3 and first then           -- a weapon skill (Magian trials)
        local wsr = res.weapon_skills[act.param]
        if wsr then trials.note_ws(first.id, wsr.en) finish.note_ws(first.id, wsr.en) end
    end
    if act.actor_id == player.id then
        if act.category == 8 then
            -- casting begins (24931): remember which spell; interrupted (28787): say so - a song sung again right after
            -- looked like a bug in his log (Honor March three times in 16 s while his bard was fighting), 2026-10-19
            if act.param == 24931 and first_action then
                state.last_ma = nil                                  -- (the cast began: not refused)
                note_next_action(res.spells[first_action.param])
                state.casting_spell = first_action.param
                local sp = res.spells[first_action.param]
                state.casting_until = now() + ((sp and sp.cast_time) or 3) + 0.5     -- stand still while it's cast
            end
            if act.param == 28787 then
                state.casting_until = 0
                state.busy_until = now() + 1
                wake(state.busy_until)
                local sp = res.spells[(first_action and first_action.param ~= 0 and first_action.param) or state.casting_spell or 0]
                if sp and not recently('interrupted:' .. sp.en, 3) then
                    mark('interrupted:' .. sp.en)
                    log(('%s was interrupted%s'):format(sp.en, sp.type == 'BardSong' and ' - singing it again' or ''))
                end
                state.casting_spell = nil
            end
        elseif act.category == 4 then
            state.casting_until = 0                                 -- cast finished: free to move
            -- the after-finish wait: 2.5 s as before, or cast.tail when that is shorter (audit 1.4 - the setting
            -- used to be undone here for every cast that finished)
            local tail = tonumber(settings.cast.tail) or 3
            state.busy_until = now() + math.max(0, math.min(2.5, tail))
            wake(state.busy_until)                                  -- (the pass right when the wait ends, 1.3)
            local spell = res.spells[act.param]
            state.cast_done = { at = now(), en = spell and spell.en or '?' }   -- (after-cast gap, 1.4)
            -- one of my cures landed: learn how much it heals on this job (vg_cure)
            if spell and cure.DEFAULT[spell.en] then
                local cc = state.cure_cast
                local known = cc and cc.spell == spell.en and now() - cc.at < 15 and cc.missing or {}
                for _, t in ipairs(act.targets or {}) do
                    local a1 = t.actions and t.actions[1]
                    if a1 and a1.param then cure.learn(spell.en, a1.param, known[t.id]) end
                end
                state.cure_cast = nil
            end
            if spell then
                local on_me = false
                for _, t in ipairs(act.targets or {}) do if t.id == player.id then on_me = true end end
                if spell.type == 'BardSong' and on_me then bard.on_song(spell, player) end
                -- a buff of ours landed: its timer on that member starts now (Buffs tab: recast before it wears off)
                if spell.status and spell.type ~= 'BardSong' and not util.targets(spell, 'Enemy') then
                    for _, t in ipairs(act.targets or {}) do
                        local mb = windower.ffxi.get_mob_by_id(t.id)
                        if mb and mb.name then bufftime.on_land(spell, mb.name) end
                    end
                end
                if spell.type == 'BardSong' and spell.status and not util.targets(spell, 'Enemy') then   -- on party members
                    for _, t in ipairs(act.targets or {}) do
                        local mb = t.id ~= player.id and windower.ffxi.get_mob_by_id(t.id)
                        if mb and (not mb.is_npc or mb.spawn_type == 14) then bard.on_member_song(spell, mb.name, player) end
                    end
                end
                if spell.type == 'Geomancy' and spell.en:sub(1, 5) == 'Indi-' and first then   -- which Indi is on whom
                    state.indi_on = state.indi_on or {}
                    if first.id == player.id then state.indi_on.me = spell.en
                    else
                        local mb = windower.ffxi.get_mob_by_id(first.id)
                        if mb then state.indi_on[mb.name:lower()] = spell.en end
                    end
                end
                if spell.type == 'Geomancy' and spell.en:sub(1, 4) == 'Geo-' then          -- where the luopan went down
                    state.geo_last = { name = spell.en, target = first and first.id, at = now() }
                end
                if first and first_action and state.debuffs[first.id] then
                    local rec = state.debuffs[first.id][spell.en]
                    if rec then
                        if landed_msgs:contains(first_action.message) then rec.landed = true share.debuff(first.id, spell.en, 'landed') end
                        if resist_msgs:contains(first_action.message) then log(spell.en .. ' resisted') rec.resisted, rec.other_until = true, nil share.debuff(first.id, spell.en, 'resisted') end
                    end
                end
            end
        elseif act.category == 3 or act.category == 6 or act.category == 5 then
            state.busy_until = now() + 1.5
            local what = act.category == 6 and res.job_abilities[act.param] or act.category == 3 and res.weapon_skills[act.param]
            note_next_action(what or { en = act.category == 5 and 'item' or '?' })
            -- our job ability landed: only the settle wait (1.2) when it's the one Vanguard sent, else the 1.5 s
            if not (act.category == 6 and ja_answered(act.param)) then wake(state.busy_until) end
            if act.category == 6 and first_action then
                local ja = res.job_abilities[act.param]
                if ja and (jobs.lucky[ja.en] or ja.en == 'Double-Up') then
                    engine.note_roll(ja.en, first_action.param)
                end
            end
        end
    end

    -- Weapon skills by anyone: advance our skillchain tracker.
    if act.category == 3 and first then
        local actor = windower.ffxi.get_mob_by_id(act.actor_id)
        local ws = res.weapon_skills[act.param]
        if actor and ws then
            local steps = sc_steps()
            local nxt = steps[state.sc.step + 1]
            if nxt and nxt.who == actor.name:lower() and nxt.ws:lower() == ws.en:lower() then
                state.sc = { target = first.id, step = state.sc.step + 1, time = now() }
                if state.sc.step >= #steps then state.sc = { target = 0, step = 0, time = 0 } end
            end
        end
    end

    scfollow.on_action(act, player)                  -- reactive skillchains + the learned window (vg_scfollow)

    -- Burst window closes when a LATER weapon skill lands on that mob (1.2.0, Silmaril audit 2.3): the skillchain is
    -- over, a burst now would be a plain nuke. The weapon skill that made the skillchain carries the skillchain
    -- add-effect and re-opens the window just below, so it never closes its own window (a 3rd step that chains again
    -- opens a new one). A missed weapon skill (message 188) doesn't count.
    if act.category == 3 and first and state.burst and state.burst.target == first.id and res.weapon_skills[act.param]
        and not (first_action and first_action.message == 188) then
        local makes_sc = first_action and first_action.has_add_effect and util.skillchain_by_msg[first_action.add_effect_message]
        if not makes_sc then
            state.burst = nil
            bridge.log('Burst window closed: another weapon skill landed')
        end
    end

    -- Skillchain detection on any target -> open a burst window.
    if first and first_action and first_action.has_add_effect then
        local chain = util.skillchain_by_msg[first_action.add_effect_message]
        if chain then
            local bt = windower.ffxi.get_mob_by_target('bt')
            if not bt or bt.id == first.id then
                state.burst = { elements = util.burst_elements[chain] or {}, chain = chain,
                                expires = now() + settings.burst.window, target = first.id }
                bridge.log('Skillchain: ' .. chain)
            end
        end
    end

    -- Mob actions: buffs (for dispel) and readies/casts (for triggers).
    local actor = windower.ffxi.get_mob_by_id(act.actor_id)
    if actor and actor.is_npc and actor.spawn_type == 16 then
        local bt = windower.ffxi.get_mob_by_target('bt')
        -- (1.2.0, audit 2.4) which buff it gained: named by the "gains the effect of" message, or by the TP move
        -- (util.MOB_BUFF_MOVES). Buffs Dispel can't take off (Invincible, Perfect Dodge) don't open the dispel window.
        if (act.category == 4 or act.category == 11) and first_action and bt and bt.id == act.actor_id then
            local mv = act.category == 11 and util.mob_move_buff(act.param)
            local gained = buffed_msgs:contains(first_action.message) or (act.category == 11 and mob_buff_msgs[first_action.message])
            if (gained or mv) and not no_effect_msgs[first_action.message] then
                local b = gained and res.buffs[first_action.param]
                local bname = (b and b.en) or (mv and mv.buff) or 'a buff'
                local ok = util.dispellable(bname) and not (mv and not gained and mv.dispel == false)
                state.mob_buff = { id = act.actor_id, name = bname, move = mv and mv.move, at = now() }
                if ok then state.dispel_until = now() + 10 end
                if settings.modules.dispel and not recently('mobbuff:' .. bname, 5) then
                    mark('mobbuff:' .. bname)
                    log(('%s gained %s%s'):format(actor.name, bname, ok and ' - dispelling' or " - it can't be dispelled, skipping"))
                end
            end
        end
        if act.category == 7 and first_action then
            local ab = res.monster_abilities[first_action.param] or res.weapon_skills[first_action.param]
            if ab then triggers.note_mob('readies', ab.en, actor.name) end
        elseif act.category == 8 and act.param == 24931 and first_action then
            local sp = res.spells[first_action.param]
            if sp then triggers.note_mob('casts', sp.en, actor.name) end
        end
    end
end)

windower.register_event('incoming text', function(original, modified, mode)
    -- the app's read-only Game chat tab (1.3.0, CurePlease audit 3.3): kept only while Vanguard Control is there
    pcall(bridge.on_text, original, mode)        -- (never stops the readers below; nothing in it yields)
    if settings.modules.triggers then triggers.note_chat(original) end
    if settings.modules.farm then farm.on_text(original) end
    trials.on_text(original)
    sortie.on_text(original)
    local inviter = original:match('(%a+) invites you to')
    if inviter then
        local player = windower.ffxi.get_player()
        if player then party.on_invite(player, inviter) end
    end
end)

windower.register_event('zone change', function(new_id, old_id)
    local was_running = settings.enabled
    stop_running()
    warp.on_zone()
    farm.on_zone(new_id, old_id)
    sortie.on_zone(new_id)
    state.party_buffs, state.debuffs, state.burst = {}, {}, nil
    bard.on_zone()
    state.sc = { target = 0, step = 0, time = 0 }
    scfollow.on_zone()
    state.qd_no_card = nil                            -- (Quick Draw: "no card" said again once per zone)
    state.busy_until = now() + 5
    state.farm_pulled, state.farm_pull_try, state.route, state.wp, state.resting = {}, {}, nil, 1, false
    state.action_once = {}
    state.zone_push_until, state.zone_push = nil, nil
    if settings.pause_on_zone and was_running then
        settings.enabled = false
        settings.modules.farm = false
        store.save(settings)
        log('Stopped: changed zone (press Start / Run again when you want it)')
    end
end)

windower.register_event('ipc message', function(msg)
    local player = windower.ffxi.get_player()
    if not player then return end
    local to, from, text = msg:match('^vg_alert (%S+) ([^|]+)|(.+)$')
    if to then alts.on_alert(player, to, from, text) return end
    local frest = msg:match('^vg_farmrest (%S+)$')
    if frest then farm.on_rest_call(player, frest) return end
    local fmob, ffrom = msg:match('^vg_finish (%d+) (%S+)$')
    if fmob then finish.on_ipc(fmob, ffrom) return end
    local dmob, dspell, dwhat = msg:match('^vg_debuff (%d+) (.+) (%a+)$')
    if dmob then share.on_debuff(tonumber(dmob), dspell, dwhat) return end
    local cfrom, ctarget, csecs = msg:match('^vg_cure (%S+) (%S+) (%d+)$')
    if cfrom then share.on_cure(player, cfrom, ctarget, csecs) return end
    local ufrom, utarget, usecs = msg:match('^vg_unseen (%S+) (%S+) (%d+)$')
    if ufrom then share.on_unseen(player, ufrom, utarget, usecs) return end
    local gfrom, gwhat, garg = msg:match('^vg_gear (%S+) (%a+) (.+)$')
    if gfrom then safety.on_gear(player, gfrom, gwhat, garg) return end
    local xfrom, xwho, xcmd = msg:match('^vg_send (%S+) (%S+) (.+)$')
    if xfrom then share.on_send(player, xfrom, xwho, xcmd) return end
    local sfrom, ssub, sname = msg:match('^vg_setup (%S+) (%a+) ([%w_]+)$')
    if sfrom then team.on_setup(player, sfrom, ssub, sname) return end
    local mfrom2, mmode, monoff = msg:match('^vg_mode (%S+) (%a+) (%a+)$')
    if mfrom2 then team.on_mode(player, mfrom2, mmode, monoff) return end
    local lfrom, lflags = msg:match('^vg_lstate (%S+) ([01][01][01])$')
    if lfrom then travel.on_lstate(player, lfrom, lflags) return end
    local pfrom, px, py, pz, pzone = msg:match('^vg_pos (%S+) (%-?[%d.]+) (%-?[%d.]+) (%-?[%d.]+) (%d+)$')
    if pfrom then party.on_pos(player, pfrom, tonumber(px), tonumber(py), tonumber(pz), tonumber(pzone)) return end
    local sname, sleader, sjob, shp, smp, stp, sdist, sdo = msg:match('^vg_status (%S+) (%S+) (%S+) (%-?%d+) (%-?%d+) (%-?%d+) (%-?%d+) (%S+)$')
    if sname then hud.on_status(player, sname, sleader, sjob, shp, smp, stp, sdist, sdo) return end
    local rfrom, rarg = msg:match('^vg_rolls (%S+) (%S+)$')
    if rfrom then support.on_rolls(player, rfrom, rarg, apply_rolls) return end
    local bfrom, bel, bst = msg:match('^vg_bar (%S+) (%a+) (%S+)$')
    if bfrom then mages.on_bar(player, bfrom, bel, bst) return end
    local scmob, scfrom, scsecs = msg:match('^vg_scf (%d+) (%S+) ([%d.]+)$')
    if scmob then scfollow.on_ipc(player, scmob, scfrom, scsecs) return end
    local slmob, slsecs = msg:match('^vg_sleep (%d+) (%d+)$')
    if slmob then mages.on_sleep(slmob, slsecs) return end
    local hname, hleader, hjob = msg:match('^vg_hello (%S+) (%S+) ?(%a*)$')
    if hname then
        party.on_hello(hname, hleader)
        if hjob ~= '' then mages.jobs[hname:lower()] = hjob end
        return
    end
    local ofrom, owhat, orest = msg:match('^vg_(%a+) (%S+) (.+)$')
    if owhat and (ofrom == 'hold' or ofrom == 'camp') then party.on_order(player, owhat, ofrom, orest) return end
    local mfrom, onoff = msg:match('^vg_mount (%S+) (%a+)$')
    if mfrom then alts.on_mount(player, mfrom, onoff) return end
    local all = msg:match('^vg_all (.+)$')
    if all then windower.send_command('vg ' .. all) return end
    local who, cmd = msg:match('^vg_to (%S+) (.+)$')
    if who and who:lower() == player.name:lower() then windower.send_command('vg ' .. cmd) end
end)

-- the farming key (picked in the app): starts / stops / resumes farming from the game window
local FARM_KEYS = { ['^f8'] = true, ['^f9'] = true, ['^f10'] = true, ['!f9'] = true }
local function farm_key(on, key)
    key = key or settings.farm.hotkey
    if key and FARM_KEYS[key] then windower.send_command(on and ('bind %s vg farming toggle'):format(key) or ('unbind ' .. key)) end
end

windower.register_event('load', function()
    bridge.start(settings)
    if settings.keys then bind_keys(true) end
    quick.hk_bind_all(true)
    farm_key(true)
    if windower.ffxi.get_info().logged_in then load_profile() bard.read_last_buffs() end
    update.on_load()
end)
windower.register_event('login', function() coroutine.schedule(function() load_profile() end, 5) end)
windower.register_event('job change', function()
    -- his request: stop the bot when the job changes (main or sub)
    if settings.stop_on_job and (settings.enabled or settings.modules.farm) then
        local player = windower.ffxi.get_player()
        if settings.modules.farm then farm.send_run(player, 'changed job') farm.treasure(false) end
        settings.enabled, settings.modules.farm = false, false
        stop_running()
        store.save(settings)
        log('Stopped: changed job (press Start / Run again when you want it)')
        coroutine.schedule(function() load_profile() settings.modules.farm = false end, 2)
        return
    end
    coroutine.schedule(function() load_profile() end, 2)
end)
windower.register_event('unload', function()
    -- running (or farming) when unloaded: carry on if it's loaded again within 90 s (a reload)
    settings.resume_until = settings.enabled and (os.time() + 90) or 0
    pcall(store.save, settings)
    stop_running() bridge.stop() hud.destroy()
    if settings.keys then bind_keys(false) end
    quick.hk_bind_all(false)
    farm_key(false)
end)

------------------------------------------------------------------------
-- Commands
------------------------------------------------------------------------
-- Hotkeys for alt orders on the leader (Byrth's dualboxing guide: one key per order). Windower binds only.
local KEYS = {
    { '^f1', 'vg holdtoggle', 'hold / come' }, { '^f2', 'vg retreat', 'retreat' }, { '^f3', 'vg camptoggle', 'camp here / camp off' },
    { '^f4', 'vg party', 'invite the alts' }, { '^f5', 'vg all toggle', 'start / stop everyone' }, { '^f6', 'vg hud', 'show / hide the alt box' },
    { '^f7', 'vg defensetoggle', 'alts defense set on / off' },
}
local function bind_keys(on)
    for _, k in ipairs(KEYS) do windower.send_command(on and ('bind %s %s'):format(k[1], k[2]) or ('unbind %s'):format(k[1])) end
end

local presets = {
    melee  = {follow = true, assist = true, ws = true},
    healer = {follow = true, heal = true, raise = true, cleanse = true, buffs = true},
    bard   = {follow = true, songs = true, debuff = true},
    geo    = {follow = true, geo = true, buffs = true},
    nuker  = {follow = true, burst = true, debuff = true, buffs = true},
    farmer = {assist = true, ws = true, rest = true, trusts = true, farm = true, triggers = true},
    curer  = {follow = true, heal = true, raise = true, cleanse = true, buffs = true, mana = true, rest = true},
}

local function set_value(path, value)
    local section, key = path:match('^([%w_]+)%.([%w_]+)$')
    local tbl = section and settings[section] or settings
    key = key or path
    if tbl[key] == nil then return false end
    local current = tbl[key]
    if type(current) == 'number' then value = tonumber(value) or current
    elseif type(current) == 'boolean' then value = (value == 'true' or value == 'on')
    end
    tbl[key] = value
    return true
end

local help = [[Vanguard commands (//vg ...):
  Vanguard sets itself up for your job automatically. Usually you only need:
  leader <name> | role <role> | ws <weapon skill> | action <id> on|off | on | off
  reset                             go back to the job's recommended setup
  on | off | status | save
  leader <name>                     who to follow and assist
  <module> on|off|toggle            follow assist heal raise cleanse buffs ws sc burst songs geo
                                    debuff dispel triggers rest mana trusts farm
  preset melee|healer|bard|geo|nuker|farmer|curer|none
  route record | stop | clear | show  record a farming route by walking it
  set <section.key> <value>         e.g. set ws.name Savage Blade | set heal.cure_at 70
  trigger add <rule> | trigger list | trigger clear
  bar <element> [status] | off      keep Bar-element + Bar-status up (leader: on every alt)
  sleep on|off                      sleep extra mobs that attack the party
  enfeebler on|off|count N|mobs <a,b>|pull on|off|stay on|off   keep up to N mobs enfeebled (off by default)
  warp                              warp home (Warp spell, Instant Warp or Warp Ring)
  rolls melee|magic|accuracy|...    Corsair roll set (leader: sent to the Corsair)
  pianissimo <song> > <name>|clear  Bard single-target songs
  chain <skillchain>|off            Scholar Immanence skillchains (liquefaction, fusion, ...)
  scf add <who>|<trigger>|<ws>|<s>  reactive skillchain: when <who|anyone> makes <WS|spell|Light...>, my <ws>
  scf list | clear [n] | on | off   (up to 4 rules per job; off by default)
  scf set <n> <who>|<trigger>|<ws>|<s>  put rule n (1-4) in place (the app's Skillchains tab)
  update [install|on|off]           check for / install a newer Vanguard from its GitHub page
  reload                            reload Vanguard (the panel does this after updating it)
  all <command>                     run a vg command on every character
  to <name> <command>               run a vg command on one character]]

windower.register_event('addon command', function(cmd, ...)
    cmd = cmd and cmd:lower() or 'help'
    local args = {...}
    local rest = table.concat(args, ' ')

    if cmd == 'on' or cmd == 'off' then
        settings.enabled = (cmd == 'on')
        if not settings.enabled then stop_running() end
        log(settings.enabled and 'enabled' or 'disabled')
    elseif cmd == 'toggle' then
        windower.send_command('vg ' .. (settings.enabled and 'off' or 'on'))
    elseif cmd == 'leader' then
        settings.leader = args[1] or ''
        if settings.leader:lower() == 'none' then settings.leader = '' end
        store.save(settings)
        log('leader: ' .. (settings.leader ~= '' and settings.leader or 'none'))
        send_profile()
    -- "ws <weapon skill>" (the app's Weapon skill menu) sets the weapon skill; only "ws on|off|toggle" is the module
    -- switch. (It used to land here and switch weapon skills OFF: "ws Atonement" -> "ws: off".)
    elseif settings.modules[cmd] ~= nil and not (cmd == 'ws'
            and not (args[1] and ({ on = 1, off = 1, toggle = 1, ['true'] = 1, ['false'] = 1 })[args[1]:lower()])) then
        local v = (args[1] or 'toggle'):lower()
        if v == 'toggle' then settings.modules[cmd] = not settings.modules[cmd]
        else settings.modules[cmd] = (v == 'on' or v == 'true') end
        if cmd == 'follow' and not settings.modules.follow then stop_running() end
        log(cmd .. ': ' .. (settings.modules[cmd] and 'on' or 'off'))
        save_profile()
        send_profile()
    elseif cmd == 'alerts' or cmd == 'mountsync' or cmd == 'upkeep' or cmd == 'hud' or cmd == 'stealth' or cmd == 'restsync' then
        local key = (cmd == 'mountsync') and 'mount' or cmd
        local v = (args[1] or 'toggle'):lower()
        if v == 'toggle' then settings.alts[key] = not settings.alts[key] else settings.alts[key] = (v == 'on') end
        store.save(settings)
        log(cmd .. ': ' .. (settings.alts[key] and 'on' or 'off'))
    elseif cmd == 'party' then
        if (args[1] or ''):lower() == 'accept' then
            settings.party.accept = ((args[2] or 'on'):lower() == 'on')
            store.save(settings)
            log('Party: accept invites ' .. (settings.party.accept and 'on' or 'off'))
        else
            party.invite_all(windower.ffxi.get_player())
        end
    elseif cmd == 'formation' then
        local f = (args[1] or ''):lower()
        if f == 'spread' or f == 'line' or f == 'off' then
            settings.follow.formation = f
            store.save(settings)
            log('Formation: ' .. f)
        else log('Formation: ' .. settings.follow.formation .. ' (//vg formation spread|line|off)') end
    elseif cmd == 'defense' or cmd == 'defensetoggle' then
        safety.defense(windower.ffxi.get_player(), cmd == 'defensetoggle' and 'toggle' or args[1])
    elseif cmd == 'gs' then
        safety.gs(windower.ffxi.get_player(), rest)
    elseif cmd == 'update' then
        update.command(args)
    elseif cmd == 'dump' then
        local player = windower.ffxi.get_player()
        if player then bridge.send({ type = 'dump', name = player.name, data = link.dump(player) }) end
    elseif cmd == 'watch' then
        -- //vg watch add <name> | remove <name> | clear : people outside the party the healer cures too
        local sub, name = (args[1] or 'list'):lower(), table.concat(args, ' ', 2)
        local keep = {}
        if sub ~= 'clear' then
            for _, n in ipairs(util.split(settings.heal.watch or '', ',')) do if n:lower() ~= name:lower() then keep[#keep + 1] = n end end
        end
        if sub == 'add' and name:match('^%a+$') then keep[#keep + 1] = name:sub(1, 1):upper() .. name:sub(2):lower() end
        settings.heal.watch = table.concat(keep, ',')
        log('Also curing (outside the party): ' .. (settings.heal.watch ~= '' and settings.heal.watch or 'nobody'))
        store.save(settings) send_profile()
    elseif cmd == 'curetier' or cmd == 'curagatier' then
        local val = table.remove(args)
        local name = table.concat(args, ' ')
        local sp = util.spell(name)
        local family = cmd == 'curetier' and '^Cure' or '^Curaga'
        if sp and cure.is_heal(sp.en) and not sp.en:find('^Cur') then
            -- a Blue Mage's cure (Magic Fruit, White Wind...): on / off for this job, with either command
            if val == 'on' or val == 'off' then
                cure.set_off(sp.en, val == 'off')
                log(('%s: %s for curing on this job'):format(sp.en, val == 'off' and 'not used' or 'used'))
                store.save(settings) send_profile()
            else log('Usage: //vg curetier Magic Fruit on|off') end
        elseif not sp or not sp.en:find(family) or (cmd == 'curetier' and sp.en:find('^Curaga')) then
            log('Usage: //vg curetier Cure IV 650|off   //vg curagatier Curaga III on|off')
        elseif cmd == 'curetier' then
            local DEFAULT = { Cure = 70, ['Cure II'] = 170, ['Cure III'] = 350, ['Cure IV'] = 650, ['Cure V'] = 1000, ['Cure VI'] = 1300 }
            local t, order = {}, { 'Cure VI', 'Cure V', 'Cure IV', 'Cure III', 'Cure II', 'Cure' }
            for _, e in ipairs(util.split(settings.heal.tiers or '', ',')) do
                local n, hp = e:match('^(.-)%s*:%s*(%d+)$')
                if n then t[n] = tonumber(hp) end
            end
            if val == 'on' or val == 'off' then cure.set_off(sp.en, val == 'off') end     -- (auto: off for this job)
            t[sp.en] = (val == 'off') and 0 or (val == 'on' and DEFAULT[sp.en]) or tonumber(val) or t[sp.en] or DEFAULT[sp.en]
            local out = {}
            for _, n in ipairs(order) do out[#out + 1] = ('%s:%d'):format(n, t[n] or DEFAULT[n]) end
            settings.heal.tiers = table.concat(out, ',')
            store.save(settings) send_profile()
        else
            local out = {}
            for _, n in ipairs(util.split(settings.heal.curagas or '', ',')) do
                if n:lower() ~= sp.en:lower() then out[#out + 1] = n end
            end
            if val == 'on' then out[#out + 1] = sp.en end
            cure.set_off(sp.en, val ~= 'on')
            settings.heal.curagas = table.concat(out, ',')
            store.save(settings) send_profile()
        end
    elseif cmd == 'stratspell' then
        -- from the panel's Stratagems tab: //vg stratspell <list> on|off <spell>  |  //vg stratspell <list> clear
        local list, what = (args[1] or ''):lower(), (args[2] or ''):lower()
        local ok, why = strat.toggle(list, what, table.concat(args, ' ', 3))
        if ok then
            store.save(settings)
            send_profile()
        else
            log('Stratagem list: ' .. tostring(why))
        end
    elseif cmd == 'actmove' then
        -- the app's priority arrows: //vg actmove <id> up|down|top|bottom   |   //vg actmove reset
        local pr = state.profile
        local id, how = args[1], (args[2] or ''):lower()
        if id == 'reset' then id, how = '', 'reset' end
        if pr and engine.move(pr.job, pr, id, how) then
            save_profile()
            send_profile()
        end
    elseif cmd == 'actopt' then
        if link.actopt(state.profile, args[1], args[2], args[3]) then
            save_profile()
            send_profile()
        end
    elseif cmd == 'actpre' then
        -- "use these abilities first" (Diffusion before Mighty Guard...): //vg actpre <id> add|del <ability> | clear | default | mode | ub
        local pr, base = state.profile, nil
        for _, a in ipairs(pr and jobs.actions_for(pr.job) or {}) do if a.id == args[1] then base = a.pre end end
        if link.actpre(pr, args[1], args[2], table.concat(args, ' ', 3), base) then
            save_profile()
            send_profile()
        end
    elseif cmd == 'hotkey' then
        -- from the app: //vg hotkey set <key> <who> <kind> <target> [name]  |  //vg hotkey clear <key>
        local sub, key = (args[1] or ''):lower(), args[2]
        local ok = false
        if sub == 'set' then ok = quick.hk_set(key, args[3], args[4], args[5], table.concat(args, ' ', 6))
        elseif sub == 'clear' then ok = quick.hk_clear(key) end
        if ok then store.save(settings) send_profile() log(('Hotkey %s %s'):format(key, sub == 'set' and 'set' or 'cleared'))
        else log('Hotkey: not changed') end
    elseif cmd == 'nearby' then
        -- the app's "Look around": mobs near this character, grouped by name
        local player = windower.ffxi.get_player()
        if player then bridge.send({ type = 'nearby', name = player.name, mobs = quick.nearby(50) }) end
    elseif cmd == 'farmlist' then
        if quick.farmlist((args[1] or ''):lower(), (args[2] or ''):lower(), table.concat(args, ' ', 3)) then
            store.save(settings)
            send_profile()
        end
    elseif cmd == 'hk' then
        quick.hk_press(windower.ffxi.get_player(), args[1])
    elseif cmd == 'warp' then
        -- the app's Go home box: warp home with the best way this character has (vg_warp)
        local player = windower.ffxi.get_player()
        if player then stop_running() warp.go(player) end
    elseif cmd == 'logout' then
        -- the app's stop timer: the normal /logout (the game counts down and can be cancelled by moving)
        stop_running()
        log('Logging out (stop timer)')
        windower.send_command('input /logout')
    elseif cmd == 'act' then
        -- a quick button from the app: //vg act <ma|ja|ws|item|attack|follow|stop> <bt|t|me|leader|Name> [name]
        local player = windower.ffxi.get_player()
        local done, why = quick.act(player, args[1], args[2], table.concat(args, ' ', 3))
        if not done then log('Quick button: ' .. tostring(why)) end
    elseif cmd == 'stats' then
        if (args[1] or ''):lower() == 'reset' then stats.reset() log('Session stats reset') end
        local t = stats.get()
        log(('Session %d min: %d XP, %d CP, %d LP, %d kills, %d deaths'):format(math.floor(t.secs / 60), t.exp, t.cp, t.lp, t.kills, t.deaths))
        local g = stats.cast_gap()
        if g then
            log(('After a cast, the next action went %.2f s later on average (%d times, %.2f-%.2f s; wait setting %s s)')
                :format(g.avg, g.n, g.min, g.max, tostring(settings.cast.tail)))
        end
    elseif cmd == 'reload' then
        log('Reloading Vanguard...')
        windower.send_command('lua reload vanguard')
    elseif cmd == 'rolls' then
        support.rolls(windower.ffxi.get_player(), rest, apply_rolls)
    elseif cmd == 'pianissimo' then
        if (args[1] or ''):lower() == 'set' then
            -- from the panel: //vg pianissimo set <name> <1|2> <song|none>
            if bard.pian_set(args[2], args[3], table.concat(args, ' ', 4)) then store.save(settings) send_profile() end
        elseif support.set_pianissimo(rest) then store.save(settings) send_profile() end
    elseif cmd == 'priority' then
        -- the Job tab's Priority box: //vg priority up|down <group> | reset | set raise,cures,...
        local player = windower.ffxi.get_player()
        local job = player and player.main_job or ''
        local order = priority_order(job)
        local sub, key = (args[1] or ''):lower(), (args[2] or ''):lower()
        if sub == 'reset' then
            order = nil
        elseif (sub == 'up' or sub == 'down') and PRIORITY_LABEL[key] then
            for i, k in ipairs(order) do
                if k == key then
                    local j = sub == 'up' and i - 1 or i + 1
                    if order[j] then order[i], order[j] = order[j], order[i] end
                    break
                end
            end
        elseif sub == 'set' then
            settings.priorities = settings.priorities or {}
            util.job_set(settings.priorities, job, table.concat(args, ',', 2))
            order = priority_order(job)
        end
        settings.priorities = settings.priorities or {}
        util.job_set(settings.priorities, job, order and table.concat(order, ',') or '')
        log('Priority (' .. job .. '): ' .. table.concat(priority_order(job), ' > '))
        store.save(settings)
        send_profile()
    elseif cmd == 'bufftime' then
        -- the Buffs tab: //vg bufftime <spell> <seconds|default>  (seconds before it wears off to cast it again)
        local secs = args[#args]
        local name = table.concat(args, ' ', 1, #args - 1)
        if name ~= '' then
            bufftime.set(name, secs)
            log(('%s: recast %s'):format(name, (secs == 'default') and 'with the general setting' or (secs .. ' s before it wears off')))
            store.save(settings)
            send_profile()
        end
    elseif cmd == 'blist' then
        -- the Farming tab's battle lists (EasyFarm): //vg blist add|del|move|set <list> ...
        local okb, why = blist.command(args)
        if not okb then log('Battle list: ' .. tostring(why)) end
        store.save(settings)
        send_profile()
    elseif cmd == 'custom' then
        -- the app's "Add your own": //vg custom add <ja|ma> <me|mob|leader> <name> | del <id>
        local sub = (args[1] or ''):lower()
        local player = windower.ffxi.get_player()
        local job = player and player.main_job
        local list = util.split(tostring(util.job_get(settings.customs, job) or ''), '+')
        if sub == 'add' then
            local kind, tgt, name = (args[2] or ''):lower(), (args[3] or ''):lower(), table.concat(args, ' ', 4)
            local real = kind == 'ja' and util.ability(name) or kind == 'ma' and util.spell(name)
            if real and (tgt == 'me' or tgt == 'mob' or tgt == 'leader') then
                local entry = kind .. '#' .. tgt .. '#' .. real.en
                local dup = false
                for _, e in ipairs(list) do if e:lower() == entry:lower() then dup = true end end
                if not dup then list[#list + 1] = entry end
                log(('Added %s (%s)'):format(real.en, tgt == 'mob' and 'on my target' or tgt == 'leader' and 'on the leader' or 'on me'))
            else
                log('Usage: //vg custom add ja|ma me|mob|leader <name>')
            end
        elseif sub == 'del' then
            local out = {}
            for _, e in ipairs(list) do
                local a = jobs.custom(e)
                if not (a and a.id == args[2]) then out[#out + 1] = e end
            end
            list = out
        end
        settings.customs = settings.customs or {}
        util.job_set(settings.customs, job, table.concat(list, '+'))
        store.save(settings)
        send_profile()
    elseif cmd == 'respawnforget' then
        farm.forget_respawn()
        log('Respawn times forgotten: learned again from the next kills')
        send_profile()
    elseif cmd == 'scf' then
        -- reactive skillchains (vg_scfollow): //vg scf add <who>|<trigger>|<ws>|<delay> | list | clear [n] | on | off
        local sub = (args[1] or 'list'):lower()
        if sub == 'on' or sub == 'off' then
            settings.scf.on = (sub == 'on')
            log('Skillchain follow: ' .. (settings.scf.on and 'on' or 'off'))
        elseif sub == 'add' then
            local ok, r = scfollow.add(table.concat(args, ' ', 2))
            log(ok and ('Skillchain follow rule added: ' .. scfollow.describe(r)) or ('Skillchain follow: ' .. r))
        elseif sub == 'set' then
            -- the app's rule rows (Control 2.0.0): //vg scf set <n> <who>|<trigger>|<ws>|<delay>
            local ok, r = scfollow.set(args[2], table.concat(args, ' ', 3))
            log(ok and ('Skillchain follow rule ' .. args[2] .. ': ' .. scfollow.describe(r)) or ('Skillchain follow: ' .. r))
        elseif sub == 'clear' then
            scfollow.clear(args[2])
            log(args[2] and ('Skillchain follow: rule ' .. args[2] .. ' removed') or 'Skillchain follow: all rules removed')
        end
        if not ({ on = 1, off = 1, add = 1, set = 1, clear = 1 })[sub] then   -- list (or anything else)
            local rules = scfollow.rules()
            log(('Skillchain follow is %s, %d rule(s)%s'):format(settings.scf.on and 'on' or 'off', #rules,
                #rules > 0 and ':' or ' (//vg scf add <who>|<trigger>|<ws>|<delay>)'))
            for i, r in ipairs(rules) do log(('  %d. %s'):format(i, scfollow.describe(r))) end
            local l = scfollow.learned()
            log(('  learned: %d skillchain(s) seen, %.1f s after the opener on average; window %.1f s, /ws lag %.1f s, latest delay %.1f s')
                :format(l.n, l.avg, l.window, l.lag, l.max_delay))
        end
        store.save(settings)
        send_profile()
    elseif cmd == 'wschain' then
        -- the app's weapon skill chain: //vg wschain slot <1-6> <ws|none> | load <chain name> | clear | save <name> | forget <name>
        local sub = (args[1] or ''):lower()
        local ws, rep = wschain.list(), wschain.rep()
        if sub == 'slot' then
            local i, name = tonumber(args[2]), table.concat(args, ' ', 3)
            local w = util.wskill(name)
            if i and i >= 1 and i <= 6 then
                if name:lower() == 'none' or name == '' then ws[i] = false elseif w then ws[i] = w.en end
                local out = {}
                for j = 1, 6 do if ws[j] then out[#out + 1] = ws[j] end end
                wschain.set(out, rep)
            end
        elseif sub == 'repeat' then
            wschain.set(ws, (args[2] or 'on'):lower() ~= 'off')
        elseif sub == 'load' then
            local p = wschain.load(windower.ffxi.get_player(), table.concat(args, ' ', 2))
            if not p then log('Weapon skill chain: no chain called "' .. table.concat(args, ' ', 2) .. '"') end
        elseif sub == 'clear' then
            wschain.set({}, true)
        elseif sub == 'save' then
            local name = table.concat(args, ' ', 2)
            log(wschain.save(name) and ('Weapon skill chain saved as "' .. name .. '"') or 'Weapon skill chain: nothing to save, or no name')
        elseif sub == 'forget' then
            local name = table.concat(args, ' ', 2)
            log(wschain.forget(name) and ('Weapon skill chain "' .. name .. '" forgotten') or ('Weapon skill chain: no chain of yours called "' .. name .. '"'))
        end
        state.wschain = nil
        local now_ws = wschain.list()
        log('Weapon skill chain: ' .. (#now_ws > 0 and table.concat(now_ws, ' > ') .. (wschain.rep() and ' (repeat)' or '') or 'off'))
        store.save(settings)
        save_profile() send_profile()
    elseif cmd == 'resing' then
        -- //vg resing: sing every song again now (the panel's "Sing all songs again now")
        state.redo_at = now()
        log('Songs: singing them all again')
    elseif cmd == 'dummy' then
        -- //vg dummy <1|2|3> <song|none>  (3 dummies open slots 3-5: Daurdabla + Clarion Call)
        local slot, song = tonumber(args[1]), table.concat(args, ' ', 2)
        local sp = util.spell(song)
        if slot and slot >= 1 and slot <= 3 and (song == 'none' or (sp and sp.type == 'BardSong')) then
            local d = util.split(settings.songs.dummy, ',')
            d[slot] = sp and sp.en or nil
            local out = {}
            for i = 1, 3 do if d[i] then out[#out + 1] = d[i] end end
            settings.songs.dummy = table.concat(out, ',')
            store.save(settings) send_profile()
            log('Dummy songs: ' .. (settings.songs.dummy ~= '' and settings.songs.dummy or 'none'))
        else
            log('Usage: //vg dummy 1|2|3 <song|none>   e.g. //vg dummy 1 Knight\'s Minne')
        end
    elseif cmd == 'songrange' then
        -- //vg songrange <name> on|off : wait for this member to be within 10' before party songs
        local name, v = args[1], (args[2] or 'on'):lower()
        if name then
            local out = {}
            for _, n in ipairs(util.split(settings.songs.aoe_names, ',')) do if n:lower() ~= name:lower() then out[#out + 1] = n end end
            if v == 'on' then out[#out + 1] = name end
            settings.songs.aoe_names = table.concat(out, ',')
            store.save(settings) send_profile()
        end
    elseif cmd == 'bar' then
        if mages.set_bar(windower.ffxi.get_player(), args[1], args[2]) then store.save(settings) end
    elseif cmd == 'sleep' then
        local v = (args[1] or 'toggle'):lower()
        if v == 'toggle' then settings.mages.sleep = not settings.mages.sleep else settings.mages.sleep = (v == 'on' or v == 'true') end
        store.save(settings)
        log('Sleep extra mobs: ' .. (settings.mages.sleep and 'on' or 'off'))
    elseif cmd == 'enfeebler' or cmd == 'enf' then
        if mages.enfeebler_cmd(args) then store.save(settings) send_profile() end
    elseif cmd == 'chain' then
        if mages.set_chain(args[1], args[2]) then store.save(settings) send_profile() end
    elseif cmd == 'sortie' then
        if mages.sortie(args[1]) then store.save(settings) send_profile() end
    elseif cmd == 'send' or cmd == 'sendall' then
        share.send(windower.ffxi.get_player(), cmd == 'send' and '*' or '**', rest)
    elseif cmd == 'sendto' then
        local who = table.remove(args, 1)
        share.send(windower.ffxi.get_player(), who or '?', table.concat(args, ' '))
    elseif cmd == 'setup' then
        team.command(windower.ffxi.get_player(), args[1], args[2])
    elseif cmd == 'exp' or cmd == 'cp' or cmd == 'ep' then
        team.exp(windower.ffxi.get_player(), args)
    elseif cmd == 'keys' then
        local v = (args[1] or 'on'):lower()
        settings.keys = (v == 'on')
        store.save(settings)
        bind_keys(settings.keys)
        if settings.keys then
            log('Hotkeys on:')
            for _, k in ipairs(KEYS) do log(('  Ctrl+%s  %s'):format(k[1]:sub(2):upper(), k[3])) end
        else log('Hotkeys off') end
    elseif cmd == 'holdtoggle' then
        party.order(windower.ffxi.get_player(), state.hold_sent and 'come' or 'hold')
        state.hold_sent = not state.hold_sent
    elseif cmd == 'camptoggle' then
        party.order(windower.ffxi.get_player(), 'camp', state.my_camp and 'off' or '')
    elseif cmd == 'retreat' then
        party.order(windower.ffxi.get_player(), 'retreat')
    elseif cmd == 'hold' or cmd == 'come' then
        party.order(windower.ffxi.get_player(), cmd)
    elseif cmd == 'spellcheck' then
        -- why a spell is or isn't offered: //vg spellcheck Enfire   (//vg spellcheck en = every enspell)
        local p = windower.ffxi.get_player()
        local learned = windower.ffxi.get_spells() or {}
        local names = rest:lower() == 'en' and { 'Enthunder', 'Enstone', 'Enaero', 'Enblizzard', 'Enfire', 'Enwater',
            'Enthunder II', 'Enstone II', 'Enaero II', 'Enblizzard II', 'Enfire II', 'Enwater II' } or { rest }
        for _, n in ipairs(names) do
            local sp = util.spell(n)
            if not sp then log(n .. ': no such spell')
            else
                local lv = sp.levels or {}
                log(('%s: learned %s | %s needs %s, %s needs %s (you: %s%d/%s%d) | castable now: %s'):format(sp.en,
                    learned[sp.id] and 'YES' or 'NO', p.main_job, tostring(lv[p.main_job_id] or '-'), p.sub_job or '-',
                    tostring(lv[p.sub_job_id or 0] or '-'), p.main_job, p.main_job_level or 0, p.sub_job or '-', p.sub_job_level or 0,
                    util.can_cast(sp, p) and 'yes' or 'no'))
            end
        end
    elseif cmd == 'charmsleep' then
        -- the Enfeebles tab: //vg charmsleep on | off | set Sleep II,Repose,... | none | reset
        local sub = (args[1] or ''):lower()
        if sub == 'on' or sub == 'off' then
            settings.charm.on = (sub == 'on')
            log('Sleep a charmed party member: ' .. sub)
        elseif sub == 'set' or sub == 'none' or sub == 'reset' then
            charm.set(sub == 'set' and table.concat(args, ' ', 2) or sub)
            local o = charm.order(windower.ffxi.get_player())
            log('Sleeps for a charmed member: ' .. (#o > 0 and table.concat(o, ' > ') or 'none'))
        else log('Usage: //vg charmsleep on|off   //vg charmsleep set Sleep II,Repose   //vg charmsleep none|reset') end
        store.save(settings) send_profile()
    elseif cmd == 'obey' then
        -- the app's Movement buttons, told to this character directly (the leader's game may be offline):
        -- //vg obey hold | come | retreat | camp off - as if the leader had sent it
        local what = (args[1] or ''):lower()
        local from = settings.leader ~= '' and settings.leader or 'the app'
        local map = { hold = { 'hold', 'hold' }, come = { 'hold', 'come' }, retreat = { 'hold', 'retreat' } }
        if what == 'camp' and (args[2] or ''):lower() == 'off' then map.camp = { 'camp', 'off' } end
        local m = map[what]
        if m then
            local saved = settings.leader
            settings.leader = from                      -- (on_order only listens to the leader)
            party.on_order(windower.ffxi.get_player(), from, m[1], m[2])
            settings.leader = saved
        else log('Usage: //vg obey hold | come | retreat | camp off') end
    elseif cmd == 'camp' then
        party.order(windower.ffxi.get_player(), 'camp', (args[1] or ''):lower())
    elseif cmd == 'food' then
        settings.upkeep.food = (rest:lower() == 'off') and '' or rest
        store.save(settings)
        log(settings.upkeep.food ~= '' and ('Food upkeep: ' .. settings.upkeep.food) or 'Food upkeep off')
        send_profile()
    elseif cmd == 'reraise' then
        settings.upkeep.reraise = (rest:lower() == 'off') and '' or rest
        store.save(settings)
        log(settings.upkeep.reraise ~= '' and ('Reraise upkeep: ' .. settings.upkeep.reraise) or 'Reraise upkeep off')
        send_profile()
    elseif cmd == 'preset' then
        local p = presets[(args[1] or ''):lower()]
        for k in pairs(settings.modules) do settings.modules[k] = p and p[k] or false end
        log('preset: ' .. (args[1] or 'none'))
    elseif cmd == 'set' then
        local path = table.remove(args, 1)
        if path and set_value(path, table.concat(args, ' ')) then
            log(path .. ' = ' .. table.concat(args, ' '))
            save_profile()
            send_profile()
        else
            log('unknown setting: ' .. tostring(path))
        end
    elseif cmd == 'trigger' then
        local sub = (table.remove(args, 1) or 'list'):lower()
        if sub == 'add' then
            local n = 1
            while settings.triggers['t' .. n] and settings.triggers['t' .. n] ~= '' do n = n + 1 end
            settings.triggers['t' .. n] = table.concat(args, ' ')
            log('trigger t' .. n .. ' added')
            store.save(settings) send_profile()
        elseif sub == 'del' then
            -- the app's x on a reaction: //vg trigger del t3
            local key = args[1] or ''
            if key:match('^t%d+$') and settings.triggers[key] then
                settings.triggers[key] = ''
                log('trigger ' .. key .. ' removed')
                store.save(settings) send_profile()
            end
        elseif sub == 'clear' then
            settings.triggers = { t1 = '' }
            log('triggers cleared')
            store.save(settings) send_profile()
        else
            for k, v in pairs(settings.triggers) do
                -- (a removed reaction comes back from settings.xml as an empty table - see vg_trials' decode)
                if type(v) == 'string' and v ~= '' then windower.add_to_chat(207, ('  %s: %s'):format(k, v)) end
            end
        end
    elseif cmd == 'all' then
        windower.send_ipc_message('vg_all ' .. rest)
        windower.send_command('vg ' .. rest)
    elseif cmd == 'to' then
        local who = table.remove(args, 1)
        if who then windower.send_ipc_message('vg_to ' .. who .. ' ' .. table.concat(args, ' ')) end
    elseif cmd == 'role' then
        local r = (args[1] or ''):lower()
        local player = windower.ffxi.get_player()
        local ok = false
        for _, x in ipairs(jobs.roles_for(player.main_job)) do if x == r then ok = true end end
        if ok then
            local pr = { job = player.main_job, role = r, ws = state.profile and state.profile.ws or default_ws(player.main_job), toggles = {} }
            apply_profile(pr)
            save_profile()
            log('Role: ' .. (jobs.role_labels[r] or r))
            send_profile(player)
        else
            log('Roles for ' .. player.main_job .. ': ' .. table.concat(jobs.roles_for(player.main_job), ', '))
        end
    elseif cmd == 'action' then
        local id, v = args[1], (args[2] or 'toggle'):lower()
        if state.profile and id then
            local cur = false
            for _, a in ipairs(jobs.actions_for(state.profile.job)) do
                if a.id == id then cur = engine.enabled(a, state.profile) end
            end
            if v == 'toggle' then state.profile.toggles[id] = not cur
            else state.profile.toggles[id] = (v == 'on' or v == 'true') end
            save_profile()
            send_profile()
        end
    elseif cmd == 'ws' then
        local name = table.concat(args, ' ')
        if name:lower() == 'none' then name = '' end
        local w = name ~= '' and util.wskill(name)
        if w then name = w.en end
        settings.ws.name = name
        if state.profile then state.profile.ws = name end
        settings.modules.ws = name ~= ''
        save_profile()
        log('Weapon skill: ' .. (name ~= '' and name or 'off'))
        send_profile()
    elseif cmd == 'profile' then
        send_profile()
    elseif cmd == 'menu' then
        local msg = menu.command(settings, args, windower.ffxi.get_player())
        if msg then
            log(msg)
            save_profile()
            send_profile()
        else
            log('menu: buff <who> on|off <spell> | song <slot> <song|none> | debuff on|off <spell> | '
                .. 'indi|geo <spell|none> | geotarget bt|me|<name> | entrust <who|none> <spell> | '
                .. 'heal|priority <who> on|off | cleanse on|off <status>')
        end
    elseif cmd == 'autosetup' or cmd == 'reset' then
        load_profile(nil, cmd == 'reset')
        save_profile()
    elseif cmd == 'farming' then
        -- The app's Start / Stop farming: everything farming needs in one click.
        local sub = (args[1] or ''):lower()
        if sub == 'start' then
            for _, m in ipairs({ 'farm', 'ws', 'rest', 'actions' }) do settings.modules[m] = true end
            if settings.trusts.list ~= '' then settings.modules.trusts = true end
            settings.enabled = true
            farm.start(windower.ffxi.get_player(), windower.ffxi.get_mob_by_target('me'))
            farm.share_camp(windower.ffxi.get_player(), true)
            state.ef_started = nil                      -- EasyFarm's engine starts fresh (its StartEngineState)
            if (settings.farm.engine or 'easyfarm') == 'easyfarm' then log("Farming started (EasyFarm's engine)")
            elseif settings.farm.mode == 'list' and #util.split(settings.farm.targets, ',') == 0 then log('Farming on, but no mobs are picked yet: pick what to fight') else log('Farming started') end
        elseif sub == 'stop' then
            farm.forget_rezone()
            farm.send_run(windower.ffxi.get_player(), 'stopped by you')
            farm.treasure(false)
            settings.modules.farm, settings.enabled = false, false
            stop_running()
            if settings.farm.pull_back then farm.share_camp(windower.ffxi.get_player(), false) end
            log('Farming stopped')
        elseif sub == 'toggle' then
            -- the farming key: stop when farming, resume when paused, else start
            local r = state.farm_run
            if settings.modules.farm and settings.enabled then windower.send_command('vg farming stop')
            elseif settings.modules.farm and r and r.paused then windower.send_command('vg farming resume')
            else windower.send_command('vg farming start') end
            return
        elseif sub == 'pause' then
            farm.pause(true) log('Farming paused')
        elseif sub == 'resume' then
            farm.pause(false) log('Farming resumed')
        elseif sub == 'quick' then
            -- "Quick start": farm the most common unclaimed mob within 30 yalms, camp here, go
            local best, ignored = nil, {}
            for _, n in ipairs(util.split(settings.farm.ignore, ',')) do ignored[n:lower()] = true end
            for _, m in ipairs(quick.nearby(30)) do
                local free = m.c - (m.others or 0)
                if free > 0 and not ignored[m.n:lower()] and (not best or free > best.free) then
                    best = { n = m.n, free = free }
                end
            end
            if not best then
                log('Quick start: no unclaimed mobs within 30 yalms')
            else
                local me = windower.ffxi.get_mob_by_target('me')
                settings.farm.mode, settings.farm.area, settings.farm.targets = 'list', 'camp', best.n
                if me then farm.set_camp(me) end
                for _, m in ipairs({ 'farm', 'ws', 'rest', 'actions' }) do settings.modules[m] = true end
                if settings.trusts.list ~= '' then settings.modules.trusts = true end
                settings.enabled = true
                farm.start(windower.ffxi.get_player(), me)
                farm.share_camp(windower.ffxi.get_player(), true)
                log(('Quick start: farming %s (%d around), camp here'):format(best.n, best.free))
            end
        elseif sub == 'report' then
            state.farm_report = {}                                  -- "Clear" on the mob report
            log('Mob report cleared')
        elseif sub == 'camp' then
            -- "Set camp here"
            local me = windower.ffxi.get_mob_by_target('me')
            if me then farm.set_camp(me) settings.farm.area = 'camp' log('Camp set here') if settings.modules.farm then farm.share_camp(windower.ffxi.get_player(), true) end end
        end
        save_profile() send_profile()   -- (the job setup carries the module switches a reload restores)
    elseif cmd == 'trial' then
        -- the Farming tab's Magian trials: //vg trial add <kind>|<goal>|<weapon skill>|<mobs> | del <t1> | reset <t1> | assist <t1>
        local sub, rest = (args[1] or ''):lower(), table.concat(args, ' ', 2)
        if sub == 'add' then
            local k = trials.add(rest)
            log(k and 'Magian trial added' or 'That trial could not be added (pick a weapon skill for a weapon skill trial)')
        elseif sub == 'del' then trials.remove(rest)
        elseif sub == 'reset' then trials.reset(rest)
        elseif sub == 'assist' then trials.assist(rest) end
        save_profile() send_profile()
    elseif cmd == 'farmemergency' then
        -- the Farming tab's emergency menu: //vg farmemergency item <name> | ja <name> | none
        local kind, name = (args[1] or 'none'):lower(), table.concat(args, ' ', 2)
        local cmdline = ''
        if kind == 'ja' and util.ability(name) then cmdline = ('input /ja "%s" <me>'):format(util.ability(name).en)
        elseif kind == 'item' and name ~= '' then
            local n = items.name(items.id(name))
            if n then cmdline = ('input /item "%s" <me>'):format(n) end
        end
        settings.farm.emergency = cmdline
        log(cmdline ~= '' and ('Emergency: ' .. cmdline) or 'No emergency action')
        save_profile() send_profile()
    elseif cmd == 'farmwatch' then
        -- the Farming tab's drop alert: //vg farmwatch add|remove <item> | clear
        local sub, name = (args[1] or ''):lower(), table.concat(args, ' ', 2)
        local keep = {}
        if sub ~= 'clear' then
            for _, n in ipairs(util.split(settings.farm.watch, ',')) do if n:lower() ~= name:lower() then keep[#keep + 1] = n end end
        end
        if sub == 'add' and farm.item_id(name) then keep[#keep + 1] = items.name(farm.item_id(name)) end
        settings.farm.watch = table.concat(keep, ',')
        log('Drop alert for: ' .. (settings.farm.watch ~= '' and settings.farm.watch or 'nothing'))
        save_profile() send_profile()
    elseif cmd == 'farmkey' then
        -- the Farming tab's key menu: //vg farmkey ^f9 | off
        local key = (args[1] or 'off'):lower()
        farm_key(false)
        settings.farm.hotkey = FARM_KEYS[key] and key or ''
        farm_key(true)
        log(settings.farm.hotkey ~= '' and ('Farming key: ' .. settings.farm.hotkey:gsub('%^', 'Ctrl+'):gsub('!', 'Alt+'):upper()) or 'No farming key')
        save_profile() send_profile()
    elseif cmd == 'farmitem' then
        -- the Farming tab's "Farm for": //vg farmitem <item name> | none
        local name = table.concat(args, ' ')
        local id = farm.item_id(name)
        settings.farm.item = id and items.name(id) or ''
        if settings.farm.item == '' then settings.farm.item_goal = 0
        elseif settings.farm.item_goal <= 0 then settings.farm.item_goal = 12 end
        log(settings.farm.item ~= '' and ('Farming for %d %s'):format(settings.farm.item_goal, settings.farm.item) or 'Not farming for an item')
        store.save(settings) send_profile()
    elseif cmd == 'farmpreset' then
        -- the Farming tab's presets: //vg farmpreset party | items | safe | clear
        local name = (args[1] or ''):lower()
        if farm.preset(name) then
            log('Farming preset: ' .. ({ party = 'XP / CP party', items = 'item farming', safe = 'safe and careful', clear = 'clear everything nearby' })[name])
        end
        save_profile() send_profile()   -- (the job setup carries the module switches a reload restores)
    elseif cmd == 'farmstrong' then
        -- the "too strong" list on the Farming tab: //vg farmstrong remove <name> | clear
        local sub, name = (args[1] or ''):lower(), table.concat(args, ' ', 2)
        local keep = {}
        if sub ~= 'clear' then
            for _, n in ipairs(util.split(settings.farm.strong, ',')) do if n:lower() ~= name:lower() then keep[#keep + 1] = n end end
        end
        settings.farm.strong = table.concat(keep, ',')
        log(sub == 'clear' and 'Too strong list cleared' or ('Will fight ' .. name .. ' again'))
        store.save(settings) send_profile()
    elseif cmd == 'farmspot' then
        -- the Farming tab's spots: //vg farmspot save | load <s1> | del <s1>
        local sub, key = (args[1] or ''):lower(), args[2] or ''
        if sub == 'save' then farm.save_spot()
        elseif sub == 'load' then if farm.load_spot(key) then state.farm_spot = key end
        elseif sub == 'del' then farm.delete_spot(key)
        elseif sub == 'import' then farm.import_spot(table.concat(args, ' ', 2)) end
        store.save(settings) send_profile()
    elseif cmd == 'radar' then
        -- the Farming tab is open: send the radar for a few seconds
        state.radar_until = os.clock() + 6
    elseif cmd == 'finish' then
        -- the app's "Finish the mob with" menu: //vg finish <weapon skill> | none
        local name = table.concat(args, ' ')
        local ws = util.wskill(name)
        settings.ws.finish = ws and ws.en or ''
        log(settings.ws.finish ~= '' and ('Finish mobs with %s %s'):format(settings.ws.finish, settings.ws.finish_at > 0 and ('under ' .. settings.ws.finish_at .. '% HP') or 'when one hit would kill them (learned)') or 'No finishing weapon skill')
        store.save(settings) send_profile()
    elseif cmd == 'trustlist' then
        -- the Farming tab's trust picker: //vg trustlist add|remove <trust> | clear
        local sub, name = (args[1] or ''):lower(), table.concat(args, ' ', 2)
        local list = util.split(settings.trusts.list, ',')
        local keep = {}
        for _, n in ipairs(list) do if n:lower() ~= name:lower() then keep[#keep + 1] = n end end
        if sub == 'add' and util.spell(name) and util.spell(name).type == 'Trust' then keep[#keep + 1] = util.spell(name).en end
        if sub == 'clear' then keep = {} end
        settings.trusts.list = table.concat(keep, ',')
        settings.modules.trusts = settings.trusts.list ~= '' and (settings.modules.trusts or settings.modules.farm)
        log('Trusts: ' .. (settings.trusts.list ~= '' and settings.trusts.list or 'none'))
        store.save(settings) send_profile()
    elseif cmd == 'farmpull' then
        -- How to pull, picked from a menu: //vg farmpull none | ra | ja <ability> | ma <spell>
        local kind, name = (args[1] or 'none'):lower(), table.concat(args, ' ', 2)
        if kind == 'ra' then settings.farm.pull_cmd = 'input /ra <t>'
        elseif kind == 'ja' and util.ability(name) then settings.farm.pull_cmd = ('input /ja "%s" <t>'):format(util.ability(name).en)
        elseif kind == 'ma' and util.spell(name) then settings.farm.pull_cmd = ('input /ma "%s" <t>'):format(util.spell(name).en)
        else settings.farm.pull_cmd = '' end
        log('Pull with: ' .. (settings.farm.pull_cmd ~= '' and settings.farm.pull_cmd or 'walk up and attack'))
        store.save(settings) send_profile()
    elseif cmd == 'route' then
        local sub = (args[1] or 'show'):lower()
        if sub == 'record' then
            state.recording, state.recording_pts = true, {}
            log('Recording route: walk the path, then //vg route stop')
        elseif sub == 'stop' then
            state.recording = false
            local parts = {}
            for _, p in ipairs(state.recording_pts or {}) do
                parts[#parts + 1] = ('%.1f:%.1f:%.1f'):format(p.x, p.y, p.z)
            end
            settings.farm.route = table.concat(parts, ';')
            state.route, state.wp = nil, 1
            store.save(settings) send_profile()
            log(('Route saved with %d points'):format(#parts))
        elseif sub == 'clear' then
            settings.farm.route, state.route, state.wp = '', nil, 1
            store.save(settings) send_profile()
            log('Route cleared')
        else
            local n = #util.split(settings.farm.route, ';')
            log(('Route: %d waypoints%s'):format(n, state.recording and ' (recording)' or ''))
        end
    elseif cmd == 'save' then
        store.save(settings)
        log('settings saved')
    elseif cmd == 'status' then
        local on = {}
        for k, v in pairs(settings.modules) do if v then on[#on + 1] = k end end
        table.sort(on)
        log(('%s | leader: %s | modules: %s'):format(settings.enabled and 'ON' or 'OFF',
            settings.leader ~= '' and settings.leader or 'none', #on > 0 and table.concat(on, ', ') or 'none'))
    else
        for line in help:gmatch('[^\n]+') do windower.add_to_chat(207, line) end
    end
end)

-- Expose for the bridge (state snapshots).
_G.vanguard_settings = function() return settings end
_G.vanguard_state = function() return state end      -- (tests)
