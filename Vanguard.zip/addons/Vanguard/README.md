# Vanguard

A multibox party assistant for Final Fantasy XI (Windower 4): your other characters follow, assist, heal, buff,
sing, roll, bubble and enfeeble on their own, and you run them all from one desktop app, **Vanguard Control**.

> Automation tools break Square Enix's terms of service and can get accounts banned. Supervise your characters;
> don't leave them running unattended.

Vanguard is free and always will be: no paid features, subscriptions, keys, ads or donations.

## Download - nothing to install

### [⬇ Download Vanguard (zip)](https://github.com/Daviant123/Vanguard/raw/main/Vanguard.zip)

1. Unzip it straight into your Windower folder (the one with `Windower.exe`). It adds `addons\Vanguard` (the
   addon) and `VanguardControl` (the app). There's no installer.
2. Double-click `VanguardControl\Vanguard Control.exe` (the gold shield). Windows may warn about an unknown app the
   first time: **More info** > **Run anyway**. The app sets Vanguard to load when the game starts. (Unzipped
   somewhere else? Fine too: the app finds your Windower folder, or asks you to pick it, and puts the addon there.)
3. Start the game (or, if it's already running, type `//lua load vanguard` once in each game window). Your characters
   appear in the app: click the one you play, **Set up party**, **Start all**.

Tip: right-click the exe > **Send to** > **Desktop (create shortcut)** for an icon on your desktop.

### Ubuntu / Linux (FFXI in Wine, Lutris, Steam / Proton or Bottles)

### [⬇ Download Vanguard for Linux (tar.gz)](https://github.com/Daviant123/Vanguard/raw/main/Vanguard-linux.tar.gz)

The game, Windower and the Vanguard addon run inside Wine as usual; Vanguard Control runs as a normal Linux app and
talks to them on your own PC (127.0.0.1), the same as on Windows. It gets the same updates as the Windows version.

1. Unpack it, open a terminal in the `Vanguard` folder and run `./install.sh` (it puts the app in
   `~/.local/share/vanguard-control`, adds **Vanguard Control** to your applications menu and starts it).
   Or just run `./vanguard-control-linux` from the folder.
2. The app looks for Windower inside your Wine prefixes (`~/.wine`, Lutris `~/Games`, Steam / Proton `compatdata`,
   Bottles, PlayOnLinux). If it doesn't find it, click **Choose folder** and pick the folder with `Windower.exe`
   (for example `~/.wine/drive_c/Program Files (x86)/Windower4`). The folder picker needs `zenity` (`sudo apt install
   zenity`) - Ubuntu usually has it.
3. Start the game; your characters appear in the app's window (it opens in your browser, or in Chrome / Chromium's
   app window when you have one).

## Updates (automatic)

The app checks this page when it starts and every hour. A newer version downloads by itself, restarts the app,
updates the addon and reloads it on your characters. Your settings are never touched. To turn it off, put an empty
file named `noupdate.txt` next to the exe (you can still use **Check for updates** in the app).
Without the app: copy the **Vanguard** folder into `Windower\addons\`; `//vg update install` updates it.

## What it sends to the game

Only normal commands, the same ones you could type: `/ma`, `/ja`, `/ws`, `/ra`, `/attack`, `/pcmd`, `/mount`,
`/heal` and so on, plus walking (Windower's run, like the follow addons). No packets are injected. The characters
talk to each other and to the app only on your own PC (Windower's IPC and a local UDP port, 127.0.0.1:47000).

---

## Setup (once)

Run **Vanguard Control**; it installs the addon (see Install above).

## Every session: 3 clicks

1. Log in your characters.
2. In Vanguard Control, click the character you play, then **Set up party**.
   That character leads. Everyone else follows, assists, and loads the recommended setup for their job.
3. Press **Start all**.

## How job setup works

Vanguard knows all 22 jobs. When a character logs in or changes job, it picks a **role** for that job
(e.g. WHM → Healer, WAR → Melee DD, PLD → Tank, BRD → Support, BLM → Nuker, BST → Pet) and turns on what that
role needs: modules, weapon skill, songs, geo bubbles, enfeebles, and the job's abilities.

Select a character in the panel to see:

- **Role**: pick another role and the whole setup changes to match (e.g. RDM: Support, Nuker, Melee DD).
- **Weapon skill**: chosen from the weapon skills the character knows right now.
- **Follow / assist**: who this character follows.
- **Abilities**: grouped as Buffs, Offense, Defense, Healing, Support, Debuffs, Pet and Recovery. Only
  abilities the character can use right now appear, including sub-job ones (SAM sub shows Hasso and Meditate).
  Untick anything you don't want; it's remembered per job.
- **Reset to recommended**: back to the default for that job and role.

Abilities are used with sensible rules: buffs only when missing, two-hours and big cooldowns only in a fight,
WAR uses Warrior's Charge before its WS, COR rolls and Double-Ups toward lucky numbers, NIN keeps Utsusemi up,
pet jobs call or summon their pet when it's missing, and so on.

## Point-and-click menus (CurePlease style)

Click a character on the left, then use the tabs. Each tab only appears if that character can use it, and
only lists spells it can cast right now (main job + sub job, highest tier known):

| Tab | What you tick |
|---|---|
| Job & abilities | Role, weapon skill, who to follow, and the job's abilities |
| Healing | Cure / Raise / Remove status effects / Wake sleeping / Use Curaga; sliders for when to cure; per member "Heal & cleanse" and "Priority"; which status effects to remove |
| Buffs | A grid: each buff spell × each party member. Tick who gets Haste, Refresh, Protect, etc. Plus self buffs |
| Enfeebles | Which enfeebles to land on each new mob, retry count, Dispel |
| Songs | Song 1–5 dropdowns, always or only during fights |
| Geomancy | Indi, Geo, where the luopan goes, Entrust spell and member |
| Advanced | Raw module switches, farm route recording, command box |

Everything you tick is saved **per job** and comes back the next time that character is on that job.
**Reset to recommended** clears your ticks for the current job.

The same menus work from chat: `//vg menu buff CharA on Haste II`, `//vg menu song 1 Honor March`,
`//vg menu debuff on Slow II`, `//vg menu indi Indi-Fury`, `//vg menu heal CharA off`,
`//vg menu priority CharA on`, `//vg menu cleanse off poison`.

## Playing alts (new in 0.2.0)

These are on by default and survive presets:

- **Alerts on your main's screen.** Each alt tells the character it follows when it is **KO'd**, **low on HP**
  (under 30%), **out of MP** (under 10%), **stuck far behind** (30+ yalms for 10 s) or **not in your zone**, or
  **standing idle while you fight** (15 s). They show in red in your chat; repeats wait a minute.
  `//vg alerts on|off`, `//vg set alerts.hp 30`, `alerts.mp`, `alerts.far`, `alerts.idle`, `alerts.repeat`,
  and `//vg set alerts.sound C:\path\ding.wav` for a sound.
- **Mount sync.** When your main mounts, the alts mount (Raptor by default); when it dismounts, they do.
  Never during a fight. `//vg mountsync on|off`, `//vg set mount.name Chocobo`.
- **Food & Reraise upkeep.** Between fights, re-eat food and keep Reraise up.
  `//vg food Grape Daifuku` (`off` to stop), `//vg reraise auto` (best Reraise spell the job knows),
  `//vg reraise Instant Reraise` (an item or a named spell), `//vg reraise off`.

## Party, formation, hold and camp (new in 0.3.0)

- **`//vg party`** on your main invites every character running Vanguard that isn't in the party yet. The alts accept
  by themselves when the invite comes from their leader or another Vanguard character (`//vg party accept off` to stop).
- **Formation**: alts stand in a fan behind you (`spread`, the default) instead of on top of you, so they're easy to
  see and take fewer area attacks. `//vg formation line` for single file, `//vg formation off` for plain follow.
- **`//vg hold`** on your main: the alts stop where they are and don't run off to fight. **`//vg come`**: they follow
  and assist again.
- **`//vg camp`** on your main: the alts come back to that spot after every fight (in formation) and wait there; they
  still join your fights. `//vg camp off` to follow again.
- Alerts now also tell you when an alt is **asleep, petrified, terrorized, charmed** or stunned for a while.

## Trail follow, alt overview, pull to camp (new in 0.4.0)

- **Trail & zone follow.** When an alt falls behind, it follows the path you actually walked (around corners instead
  of into the wall), and when you zone it runs the rest of your path and through the zone line after you.
  `//vg set follow.trail false` for straight-line following.
- **Alt overview box** on your main's screen: every alt's job, HP, MP, TP, distance and what it's doing, red when
  something's wrong, grey "(no word)" if an alt goes quiet. Drag it where you like. `//vg hud off` to hide it.
- **Pull to camp.** Farming with a camp: set `//vg camp` where you want to fight and a pull command
  (`//vg set farm.pull_cmd input /ra <t>` or `input /ma "Dia" <t>`). The farmer pulls first (before buffing),
  runs back to camp and fights the mob there; the alts wait at camp.

## Travel, resting and retreat (new in 0.5.0)

- **Sneak & Invisible sync.** When you go sneaked / invisible, each alt does the same on itself: Spectral Jig if it's
  a DNC (main or sub), its own Sneak / Invisible spell if it has one, otherwise a Silent Oil / Prism Powder from its
  inventory (it tells you if it has nothing). `//vg stealth off` to stop.
- **Rest sync.** When you `/heal`, alts that aren't full rest too once they've reached you; when you stand up, the
  ones that sat down with you stand up. `//vg restsync off` to stop.
- **`//vg retreat`** on your main: every alt stops fighting (`/attackoff`), runs back to you (or to camp) and holds.
  `//vg come` when it's safe.

## Fighting with the leader, hotkeys (new in 0.6.0)

- **Disengage with you.** When you stop attacking, alts that were assisting stop 2 seconds later (a quick re-target
  doesn't count), and BST / SMN / PUP call their pets back. If you're KO'd they keep fighting.
  `//vg set assist.disengage false` to turn it off.
- **Self-defense.** A mob attacking an alt while you're not fighting: melee alts fight back; casters tell you
  they're being attacked. `//vg set assist.defend false` to turn it off.
- **Hotkeys** on your main: `//vg keys on`, then
  Ctrl+F1 hold / come, Ctrl+F2 retreat, Ctrl+F3 camp here / camp off, Ctrl+F4 invite the alts,
  Ctrl+F5 start / stop everyone, Ctrl+F6 show / hide the alt box, Ctrl+F7 alts' defense set on / off. `//vg keys off` removes them.

## Team setups, XP party, next target (new in 0.7.0)

- **Team setups.** `//vg setup save Odyssey` on your main: every character saves its current setup (its job's role,
  weapon skill, abilities and menus, plus leader, formation, food, Reraise, mount, farm targets) under that name.
  `//vg setup load Odyssey` puts everyone back. A character on another job gets it when it changes to that job.
  `//vg setup list`, `//vg setup delete <name>`.
- **XP / CP / EP party in one command.** `//vg exp Locus Wivre, Locus Dire Bat` on your main: you pull (with your
  `farm.pull_cmd` if set) to a camp at your spot, the alts assist and fight at camp. `//vg exp off` to stop
  (`//vg cp` / `//vg ep` do the same).
- **Next target.** After a kill, if another monster is still attacking someone in the party and you aren't fighting,
  melee alts take it on. `//vg set assist.autotarget false` to turn it off.

## Characters working together, sending commands (new in 0.8.0)

- **Shared enfeebles.** When one character casts an enfeeble on a mob the others wait; once it lands, nobody casts it
  on that mob again; if it's resisted, another may try. No more two characters both casting Slow.
- **Healer teamwork.** A healer starting a cure tells the other healers, who leave that member to it for the cast
  time (a Curaga covers everyone), unless the member drops under 35% (`//vg set share.emergency 35`).
- **`//vg send <command>`** runs a command on every other character: `//vg send /ma "Haste" CharA`,
  `//vg send warp`. `//vg sendall` includes this character, `//vg sendto CharB <command>` just one.
  Commands starting with `/` are typed into the game; anything else is a Windower / addon command.

## Gear modes, getting unstuck, away safety (new in 0.9.0)

- **GearSwap sync.** `//vg defense physical|magical|off` on your main switches every alt's GearSwap defense mode
  (standard Mote files; `//vg set gear.physical <gs command>` if a file uses other names). Ctrl+F7 toggles it with
  `//vg keys on`. `//vg gs <command>` sends any GearSwap command, e.g. `//vg gs cycle OffenseMode`.
  `//vg set gear.auto true`: an alt under 40% HP in a fight puts its defense set on until it's back over 75%.
- **Stuck recovery.** An alt running but not moving for 2 seconds steps sideways for a moment and tries again; after
  3 tries it tells you it's stuck.
- **Away safety.** If you haven't moved or fought for 20 minutes, the alts pause themselves and tell you; they carry
  on as soon as you move. `//vg set away.minutes 30` to change it, `0` to turn it off.

Settings are now saved safely with several characters running (one character's save no longer undoes another's).

## White Mage, Red Mage, Scholar (new in 0.10.0, from the community job guides)

- **One -na for the party.** When 2+ members have the same ailment, a White Mage uses Divine Seal (a Scholar in
  Light Arts: Accession) first, so one Poisona / Paralyna / ... clears everyone.
- **Bar spells.** `//vg bar fire` (ice, wind, earth, thunder, water) on your main: every alt that can keeps the
  Bar-element and its matching Bar-status up (fire + amnesia, ice + paralyze, wind + silence, earth + petrify,
  water + poison). Name another status if you like: `//vg bar wind sleep`. `//vg bar off` to stop.
  White Mages cast the party versions (Barfira ...), Red Mages / Scholars their own.
- **Paladin in the party:** the White Mage skips Protectra (Majesty is better).
- **Red Mage:** Saboteur right before the first Dia / Distract / Frazzle on a new mob; when Frazzle or Distract is
  resisted, Stymie so the next one lands.
- **Sleep extra mobs.** `//vg sleep on`: a second mob attacking the party (not the one you're fighting) gets
  Sleep II / Sleep / Foe Lullaby / Sleepga. It's slept again when it wakes up; undead and mobs it doesn't work on
  are left alone, and two characters never sleep the same mob.
- **Scholar stratagems.** As healer: Accession + Regen when 3+ members nearby have no Regen, Perpetuance + Regen V
  on you, and Aurorastorm II on itself. As nuker: makes its own skillchain with Immanence (Stone then Fire II =
  Liquefaction) and the burst module bursts on it. `//vg chain fusion` (liquefaction, scission, reverberation,
  detonation) to pick another, `//vg chain off` to stop.
- Settings: `//vg set mages.<name> <value>` (aoe_na, saboteur, stymie, accession, perpetuance, chain_every,
  strat_secs = seconds per stratagem charge, 33 with 550 Job Points).

## Corsair, Geomancer, Bard (new in 0.11.0, from the community job guides)

- **Smarter Double-Up.** The Corsair stops on the lucky number or 11. It uses Snake Eye at 10 (for 11), one short of
  lucky, or to get off the unlucky number, and Folds a bust. Otherwise it only Doubles-Up when it can't bust
  (5 or less). For more risk: `//vg set cor.risk 17` (also Double-Up on 6), `33` (on 7) ...
  (Fixed: the old Double-Up mistook each roll's unlucky number for a lucky one.)
- **Roll range.** Rolls only reach people within 8 yalms, so the Corsair walks over to you before rolling.
  With Luzaf's Ring: `//vg set cor.range 16`.
- **Roll sets.** `//vg rolls melee` (Samurai + Chaos), `magic` (Wizard's + Warlock's), `accuracy`, `tank`, `crit`,
  `refresh`, `exp`, `fastcast`, or name two: `//vg rolls chaos,rogue's`. Typed on CharA it goes to the Corsair alt.
- **Geomancer.** Casts Dia II first so Geo-Frailty / Malaise work (the guide: the GEO must be on the mob's hate list).
  `//vg set geo.entrust auto` entrusts Indi-Haste (or Indi-Fury) to you. Radial Arcana also when 2+ party members are
  under 40% MP (`geo.party_mp`).
- **AutoSkillchain while farming.** Farming > Battles > AutoSkillchain: pick "AutoSkillchain" instead of the Weaponskill
  list, load a preset or fill in your own weapon skills, and save your own chains by name.
- **Weapon skills at a set MP.** On Job & abilities or in AutoSkillchain: weapon skills only at this MP % and / or MP number.
- **Weapon skill chain (one character).** On Job & abilities: up to 6 weapon skills used in turn (each at 1000+ TP,
  4 s or more apart, in range), repeating or stopping at the end; a new mob or a 20 s break starts it over. Chains saved
  in the AutoSkillchain addon (its data folder) can be loaded with one click. Saved per job.
- **Bard NiTro.** In a fight, as soon as Nightingale + Troubadour are ready and your songs weren't sung under them:
  NiTro + Marcato, then all songs fresh (they last twice as long; it knows). Songs due with NiTro only seconds away:
  it waits for NiTro. `//vg set songs.nitro false` to save them for yourself.
- **How songs are kept up** (after Ivaar's Singer): the bard knows which of its songs are on - a new song with every
  slot full replaces the one with the least time left (a dummy first), a song that wears off is sung again (a dummy
  first if its harp slot closed), a refresh with all songs on sings each over itself (no dummies). Songs come right
  after raises / cures / status removal. Nightingale, Troubadour and Marcato are used by the songs while Songs is on.
- **Songs already on.** Songs that are up when Vanguard starts (sung by hand, another addon, a reload) are picked up
  with the time the game says they have left; a song dispelled or worn off early is sung again right away. Song
  lengths come from the game's own timers, so refreshes land just before songs really end.
- **Pianissimo songs.** `//vg pianissimo Mage's Ballad III > CharB|CharC` sings Ballad to just those two;
  add more lines (e.g. `Sentinel's Scherzo > CharA`). `//vg pianissimo` shows them, `//vg pianissimo clear` empties.
  Got a Terpander / Daurdabla? Just put 3 or 4 songs in the song list.
- **Horde Lullaby.** With `//vg sleep on`, two or more extra mobs get Horde Lullaby (or Sleepga) at once.

## Keep MP for cures (new in 0.31.0 / Vanguard Control 1.20.0)

Healing & MP (or Recovery) tab: **Keep MP for cures**. Below that MP the character stops casting buffs, songs,
enfeebles and nukes and saves the rest for Cures, Raise and status removal. 0 = off.

## Cooldowns (new in 0.35.0 / Vanguard Control 1.25.0)

Team tab > Cooldowns: every character's job abilities in one place. Green = ready (click it and that character uses it,
on its target or itself), grey = time left. "Only the long ones" shows the 1-hour abilities and the ones with long
recasts, so the list stays short.

## Go home (new in 0.33.0 / Vanguard Control 1.23.0)

Team tab > Go home: shows how each character gets home (Warp spell, Instant Warp scroll or Warp Ring) and warps one
character, everyone, or just the alts (click twice). A Warp Ring is put on, used when it's ready, and GearSwap is kept
off the ring until the character zones. `//vg warp` does the same in game.

## Farming: avoiding packs (new in 0.37.0 / Vanguard Control 1.27.0)

Farming tab > How to fight: **Pick mobs on their own first** (on) - a mob with others standing within 8 yalms can bring
them along, so lone mobs are pulled first. **Never pull one with others next to it** waits until one is alone (purple
on the radar). Mobs attacking you are always fought.

## Farming (Farming tab)

**EasyFarm's engine (new in 0.90.0 / Vanguard Control 1.86.0).** Farming runs EasyFarm's own logic, rebuilt from its
source (the same steps, order, mob filter and action rules) on normal game commands - no EasyFarm DLL, no EliteAPI.
Vanguard's own farming engine (camp, pull back to camp, wait for the party) is still there: Vanguard extras > Farming
engine.

**EasyFarm layout (new in 0.89.0 / Vanguard Control 1.85.0).** Sub-tabs across the top like EasyFarm: **Targets**
(what to fight + Aggro / Party / Unclaimed / Claimed filters), **Battle** (seven lists: Start, Trusts, Pull, Battle,
End, Healing, Weaponskill - add abilities, magic, weapon skills, items or trusts from the menu, order them with the
arrows, **Edit** for the conditions: distance, recast, your HP %, target HP %, MP and TP ranges, a status effect on or
not on you, only on one mob, uses per mob), **Rest**, **Routes**, **Follow**, **Settings** (detection / wander distance,
height, melee distance, global cooldown, Approach, Engage), **Log**, and **Extras** for everything else below. Lists
are saved per job. Not included: home point on death, tab targeting, object avoidance (they need memory reading or
key presses).

**The fastest way:** stand where you want to farm and click **⚡ Quick start: farm what's here**. It farms the most
common unclaimed mob within 30 yalms, with the camp where you stand. Or:

1. **Quick setups** - one click for an *XP / CP party*, *item farming*, *safe and careful* or *clear everything*.
2. **What to fight** - *Mobs I pick* (Look around, then **Fight these**; or click a mob on the radar), *Only what
   attacks us*, or *Anything nearby*. Mobs that nearly KO the farmer are set aside as **too strong** (↺ to fight them
   again). Optionally **/check** each new kind and skip *Too Weak* (no XP) or *Incredibly Tough* / NMs.
3. **Where** - *Stay around a camp* (it walks back after each kill; **bring each mob back to camp** and the team waits
   there) or *Walk a route* you record by walking it. Save several **farm spots** and tick "move on to the next saved
   spot" to rotate when one runs dry, or let it **look further when it's quiet** (10 yalms more every 30 s up to a
   limit you pick, back to normal once mobs are close).
   It learns each spot's **respawn time** from its kills and shows "next <mob> in ~N s" while it waits.
4. **Start farming.**

**On the dashboard:** what it's doing right now, time, kills, kills / hour, XP and CP / hour, bag space, the XP / CP
chain, loot this run, a kills-per-5-minutes chart and a live **radar** (zoom Fit / 30 / 60 / 120 yalms). The
**checklist** shows with green ticks and red crosses why it is or isn't pulling (mobs picked, camp set, mobs nearby,
party ready, resting, bag space, Reraise, food). **Pause** stops for a moment without ending the run.

**All settings:** pull with Provoke / Flash / a ranged attack (used as soon as the mob is in reach, so it's yours
sooner), walk up or let it come, rest levels, rest at camp while idle, Treasure Hunter (GearSwap TreasureMode), save TP
on nearly dead mobs; **The team** - others follow and help in one click, wait for everyone's HP / MP before each pull
(whoever is low is told to rest), keep the XP / CP chain going, sleep extra mobs; **Finish mobs with a weapon skill**;
**Stop when** - inventory full, after N kills or minutes, when you have N of an item, at a level (for levelling a job); **when done** - stay, everyone
warps home or everyone logs out; **Trusts**, sorted by role.

**Safety nets:** it never chases a mob it can't reach (skipped for a while), lets go of a mob someone else claims or one
it can't hurt, helps a party member who is attacked (the healer first), doesn't sit down to rest while something is
hitting the party, and stops if it is KO'd or changes zone. The Alarms ring when farming stops or has had nothing to
fight for 5 minutes. **Past runs** keeps the history of every run.

## Finish mobs with a weapon skill (new in 0.34.0)

Job & abilities (or Farming) > **Finish with** a weapon skill **when its HP is at or under** a %. The character saves TP
for it and lands it as the killing blow (weapon skill trials, e.g. Atonement). The other characters stop attacking that
mob when it gets low; **stop attacking until TP is 1000** helps a tank that's short on TP.

## Alarms (new in Vanguard Control 1.22.0)

App & updates > Alarms: the app plays a sound, shows a red banner and flashes the character's card when a character is
KO'd, asleep / petrified / charmed, goes offline, is stuck or not fighting, or (if you tick them) is low on HP or MP.
It works while the app is minimized. **Keep ringing until I click OK** if you step away from the screen.

## Enemy watch (new in 0.32.0 / Vanguard Control 1.21.0)

Team tab > Enemy: what your characters are fighting, its HP and distance, its TP move as it readies it, and each
enfeeble: green landed, yellow being cast, red resisted, grey not tried yet.

## Skillchain builder (new in 0.30.0 / Vanguard Control 1.19.0)

Team tab > Skillchain: pick each step's character and weapon skill from menus. The app shows the properties, what each
step makes (or "no skillchain") and which magic bursts the result opens. **Use this skillchain** sets it on everyone.

## Crash reports (new in 0.29.0 / Vanguard Control 1.18.0)

Errors in the addon (on any character) and in the app are caught instead of breaking things. A "problem" badge shows
at the top; App & updates > Problems > **Send report** opens a ready-made report on the Vanguard GitHub page in your
browser - click Submit and it reaches the developer. Character names and your Windows user name are replaced first,
and nothing is sent without your click. **Report a problem** is for things that go wrong without an error.

## Upkeep menus (new in 0.28.0 / Vanguard Control 1.17.0)

Team tab > Upkeep: for every character, the food to keep up, how to keep Reraise up and which mount to ride, chosen
from menus of what that character really has (food in its bags, Reraise spells / items, owned mounts).

## Sharing profiles (new in 0.27.0 / Vanguard Control 1.16.0)

On the profile bar, **Export...** saves the chosen profile as a file (normal Windows Save window) to send a friend;
**Import...** adds a profile file you were sent. Exported files leave out which character they came from and the
leader's name; an import never overwrites one of yours.

## Reactions (new in 0.26.0 / Vanguard Control 1.15.0)

Advanced tab > Reactions: pick **When** (my HP / MP below, TP at least, someone's HP below, the enemy's HP below, the
enemy readies or casts something it was seen using, I have / don't have a buff, fighting or not), **Do** (a spell,
ability, weapon skill or item, on whom) and **How often**. Each reaction is listed in plain words with an x.

## Farm mob lists by clicking (new in 0.25.0 / Vanguard Control 1.14.0)

Advanced tab > Farming > **Look around** lists the mobs near the selected character (how many, how close, who
claimed them). Click **Fight these** or **Leave alone**; the lists show as tags with an x to remove. "Which mobs"
picks unclaimed only, unclaimed or ours, or any.

## Quick-button hotkeys (new in 0.24.0 / Vanguard Control 1.13.0)

Give any quick button a hotkey (Ctrl or Alt + a number) from its menu on the Team tab. Press it in the game window you
play (the leader's, or pick another) and the button's character acts - no need to click the app.

## Unbridled spells and "use these abilities first" (new in 0.95.0 / Vanguard Control 1.92.0)

- **Unbridled spells** (Mighty Guard, Carcharian Verve, Harden Shell, Pyric Bulwark, Thunderbolt, Gates of Hades...): turn the
  action on (or add one with Add your own > Blue magic) and Vanguard uses **Unbridled Learning** right before it. Each one has a
  choice: Unbridled Learning, "Learning, else Wisdom" (Wisdom only while Learning is on recast), or Unbridled Wisdom. Main-job
  BLU only, like the game.
- **first:** on every ability row of the Job tab: pick job abilities to use on yourself right before it, e.g. Diffusion before
  Mighty Guard, Burst Affinity before a blue nuke, Composure before a Red Mage buff, Accession or Manifestation before a Scholar
  spell, Elemental Seal before a debuff. Each is used only when it's ready and not already up, one at a time. If one is on recast:
  "go without it" (default) or "wait for it". Saved per job and in profiles. Chat: `//vg actpre <id> add Diffusion`,
  `del <name>`, `clear`, `default`, `mode go|wait`, `ub learning|wisdom|either`.

## Ability priority (new in 0.23.0 / Vanguard Control 1.12.0)

The Job tab lists a character's abilities in the order they're tried, top first (like MMOMinion's Skill Manager).
Use the arrows to move one up, down or to the top; **Reset order** goes back to the job's order. Saved per job and in
profiles.

## Stop timer (new in 0.22.0 / Vanguard Control 1.11.0)

On the Team tab: stop **after** a time (30 minutes to 10 hours) or **at** a clock time, then **stop** or **stop and log
out** (the normal /logout), for **everyone** or **only the alts**. A countdown shows at the top; Cancel any time.

## Party board (new in 0.21.0 / Vanguard Control 1.10.0)

The Team tab shows every character's HP, MP, TP, what it's doing and all its buffs in one table. Ailments are red
(also on the character cards); click one and a character who can cure it casts the right spell.

## Quick buttons (new in 0.20.0 / Vanguard Control 1.9.0)

On the Team tab, build a button from menus: **who** (a character or everyone), **does** (a spell, ability, weapon
skill, item, attack, follow or stop), **which** one (only what that character can use) and **on** whom. Buttons sit
in a bar under the top buttons on every tab; one click makes that character do it.

## Session stats and What's new (new in 0.19.0 / Vanguard Control 1.8.0)

- **Session** box on the Team tab: for every character, experience, Capacity Points and limit points per hour,
  kills, deaths and time, counted from its own game messages. **Reset** starts a new session (`//vg stats reset`).
- **What's new** tab: what each update added or fixed, in plain words.

## Scholar stratagems, main job and /SCH (new in 0.15.0 / Vanguard Control 1.4.0)

The **Stratagems** tab appears for any character with Scholar as main or sub job.
- **Charges** are worked out from the Scholar level: SCH 99 has 5 (one back every 48 s, 33 s with the 550 Job Point
  gift), /SCH at 49 has 2 (one every 2 minutes). The tab shows how many are ready.
- **Keep Arts up:** Light Arts (Dark Arts for nukers), or pick one; stratagems need it.
- **Which spells get which stratagem:** a list per stratagem, plus thresholds:
  Perpetuance (enhancing buffs that should last longer), Accession (party buffs when enough members need them, and a
  Scholar's Curaga: Accession + Cure when several are hurt), Celerity (Raise spells, emergency cures), Penury (when
  MP is low), Rapture (emergency cures), and on the Dark side Parsimony, Alacrity, Manifestation, Ebullience and the
  merit ones. The stratagem is used right before the spell, whichever part of Vanguard casts it.
- **Keep for emergencies:** charges only spent on Raise (Celerity) and emergency cures.

## Profiles and thresholds, CurePlease-style (new in 0.14.0 / Vanguard Control 1.3.0)

Everything is chosen in Vanguard Control and kept there; the addon only carries it out.
- **Profiles.** The bar above the tabs: **Save as...** keeps the character's whole setup for its job (role, weapon
  skill, abilities and their thresholds, cure tiers, buffs, songs, Geo, enfeebles, modules, recovery and the other
  settings) as a file in `VanguardControl\profiles`. **Load** puts any profile onto any character (a WHM profile on a
  character that's on another job waits until it's on WHM). **Load by itself on <job>** loads it whenever that
  character logs in or changes to that job.
- **Ability thresholds.** Next to every ability on the Job tab: party HP / my HP / MP / TP limits, how often, and
  when (always, party fighting, I'm fighting, out of combat). Changed values are outlined; the tooltip shows the
  recommended one; clear a box to go back to it.
- **Cure tiers** (Healing & MP tab): how much HP must be missing before each Cure tier is used; 0 = never.
- **Recovery:** rest HP / MP limits, Convert and Sublimation thresholds, for every job with MP.

## The app does the work (new in 0.13.0 / Vanguard Control 1.2.0)

- **Installs Vanguard for you.** Vanguard Control finds the Windower folder (or asks you to pick it), installs the
  addon that's built into the app into `Windower\addons\Vanguard`, and adds `lua load vanguard` to `scripts\init.txt`.
  Settings are never touched.
- **Keeps it up to date.** A newer app carries a newer addon: it installs it and reloads Vanguard on characters still
  running the old one. A yellow bar at the top says if anything needs you (pick a folder, start the game, ...).
- **Team tab.** Everything for the whole party in one place: set up / invite, hold / come / camp / retreat,
  formation, GearSwap defense, fighting rules, bar spells, Corsair rolls, sleeping extra mobs, XP party, team setups,
  and the helpers (alerts, mount, food / Reraise, sneak, rest, overview box, away pause).
- **Job extras** on the Job tab: Scholar skillchains, Corsair roll set / risk / reach, Bard NiTro and Pianissimo
  songs, Geomancer hate list / Entrust / Radial Arcana, Red Mage Saboteur / Stymie, -na for the party.
- **App & updates tab:** versions, Windower folder, check for updates, reinstall, reload everyone.

## Updates and sharing (new in 0.12.0)

Vanguard has its own GitHub page: github.com/Daviant123/Vanguard (the addon is in the **Vanguard** folder, the panel
in **VanguardControl**). Friends who install it from there get told when there's a new version, and
`//vg update install` fetches it (only Vanguard's own files, never settings), then `//lua r vanguard`.
`//vg update` checks now, `//vg update off` stops the check when it loads.
Vanguard Control 1.1.0+ updates itself the same way when it starts (and every 6 hours): it downloads the new panel
and restarts. An empty `noupdate.txt` next to the exe turns that off.

## Commands (same as the panel)

```
//vg on | off | status | save | help
//vg role <role>              e.g. healer, support, nuker, melee, tank, ranged, pet
//vg ws <weapon skill>        empty = off
//vg action <id> on|off|toggle
//vg reset                    recommended setup for this job
//vg autosetup                reload this job's saved setup
//vg leader <name> | none
//vg <module> on|off|toggle
//vg preset melee|healer|curer|bard|geo|nuker|farmer|none
//vg route record | stop | clear | show
//vg set <section.key> <value>
//vg trigger add <rule> | list | clear
//vg all <command>            run on every character
//vg alerts | mountsync | upkeep on|off
//vg party [accept on|off]    //vg formation spread|line|off
//vg hold | come | camp [off]  (on the leader)
//vg hud on|off    //vg stealth on|off    //vg restsync on|off
//vg retreat                  (on the leader)
//vg keys on|off              Ctrl+F1..F6 hotkeys for alt orders
//vg setup save|load|list|delete <name>    //vg exp <mobs> | off
//vg send | sendall <command>  //vg sendto <name> <command>
//vg defense physical|magical|off    //vg gs <GearSwap command>
//vg food <item> | off        //vg reraise auto | <spell or item> | off
//vg to <name> <command>      run on one character
```

## Modules

| Module | What it does | Key settings |
|---|---|---|
| follow | Follows the leader | `follow.distance` |
| assist | Engages what the leader fights, closes to melee range | `assist.approach` (off for casters) |
| actions | Job abilities from the Abilities list | per-job toggles in the panel |
| heal | Cure/Curaga by missing HP; priority members first; wakes sleeping members | `heal.cure_at`, `heal.curaga_at`, `heal.priority`, `heal.wake_sleep` |
| raise | Raises KO'd party members | |
| cleanse | -na spells, Esuna, and Erase for ~30 debuffs | |
| mana | Sublimation upkeep and release, Convert at low MP | `mana.sublimation_mpp`, `mana.convert_mpp` |
| rest | `/heal` when idle and low, stands at full | `rest.hp_low`, `rest.mp_low` |
| buffs | Extra buffs you list | `buffs.list` e.g. `Haste>CharA,Refresh>me` |
| ws | Weapon skill at a TP threshold | `ws.tp` |
| sc | Coordinated skillchains | `sc.steps` e.g. `CharA:Savage Blade,CharC:Chant du Cygne` |
| burst | Magic bursts on detected skillchains | `burst.spells` |
| songs | Keeps songs up (set by BRD role) | `songs.list` |
| geo | Indi, luopan, Entrust, Full Circle (set by GEO role) | `geo.indi`, `geo.geo`, `geo.entrust` |
| debuff | Lands enfeebles once per mob (set by job) | `debuff.list` |
| dispel | Dispels when the battle target buffs itself | best-effort |
| triggers | If-this-then-that rules | see below |
| trusts | Summons trusts until the party is full | `trusts.list` |
| farm | Finds, claims and fights listed mobs; walks a recorded route | `farm.targets`, `farm.claim` |

## Farming (EasyFarm-style)

```
//vg preset farmer
//vg set farm.targets Locus Dire Bat, Locus Wivre
//vg set trusts.list Valaineral,Selh'teus,Koru-Moru,Qultada
//vg route record      (walk your loop)
//vg route stop
//vg on
```

## Triggers

```
//vg trigger add hpp<35 and engaged -> input /ja "Sentinel" <me> | 60
//vg trigger add readies:Hurricane Wing -> input /ma "Stoneskin" <me> | 30
```
Conditions: `hpp`, `mpp`, `tp` (with `< <= > >= ==`), `hpp:Name<50`, `party_hpp<50`, `mob_hpp<25`,
`buff:Name`, `!buff:Name`, `engaged`, `idle`, `resting`, `mob:Name`, `readies:Ability`, `casts:Spell`, `chat:text`.
Join with `and`. Optional `| seconds` cooldown (default 10), or `| once` for once per mob.

## Notes

- The addon runs on a 0.25 s timer and only watches a few packet types, so it is light on FFXI.
- The desktop app talks to the addons over UDP on 127.0.0.1 only. Nothing leaves the PC.
- Test in easy content first.
